<?php

namespace App\Http\Controllers;

use App\DataTables\FasilitasDataTable;
use App\Http\Requests;
use App\Http\Requests\CreateFasilitasRequest;
use App\Http\Requests\UpdateFasilitasRequest;
use App\Repositories\FasilitasRepository;
use Flash;
use App\Http\Controllers\AppBaseController;
use App\Models\FasilitasFile;
use Illuminate\Validation\ValidationException;
use Response;
use Str;

class FasilitasController extends AppBaseController
{
    /** @var  FasilitasRepository */
    private $fasilitasRepository;

    public function __construct(FasilitasRepository $fasilitasRepo)
    {
        $this->fasilitasRepository = $fasilitasRepo;
    }

    /**
     * Display a listing of the Fasilitas.
     *
     * @param FasilitasDataTable $fasilitasDataTable
     * @return Response
     */
    public function index(FasilitasDataTable $fasilitasDataTable)
    {
        return $fasilitasDataTable->render('fasilitas.index');
    }

    /**
     * Show the form for creating a new Fasilitas.
     *
     * @return Response
     */
    public function create()
    {
        // return view('fasilitas.create');
    }

    /**
     * Store a newly created Fasilitas in storage.
     *
     * @param CreateFasilitasRequest $request
     *
     * @return Response
     */
    public function store(CreateFasilitasRequest $request)
    {
        // $input = $request->all();
        // $input['slug']=Str::slug($input['title']);
        // $fasilitas = $this->fasilitasRepository->create($input);
        // // try {
        //     foreach ($request->images as $key => $image) {
        //         $imageName = Str::slug($request->title) . '-' . ($key + 1) . '.' . $image->getClientOriginalExtension();
        //         $image->move(public_path('/storage/fasilitas'), $imageName);
        //         $src = '/storage/fasilitas/' . $imageName;

        //         $fasilitas_files = new \App\Models\FasilitasFile();
        //         $fasilitas_files->src = $src;
        //         $fasilitas_files->fasilitas_id = $fasilitas->id;
        //         $fasilitas_files->save();
        //     }
        // // } catch (\Throwable $th) {
        // //     throw ValidationException::withMessages([$th]);
        // // }
        // Flash::success('Fasilitas saved successfully.');

        // return redirect(route('fasilitas.index'));
    }

    /**
     * Display the specified Fasilitas.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function show($id)
    {
        $fasilitas = $this->fasilitasRepository->find($id);

        if (empty($fasilitas)) {
            Flash::error('Fasilitas not found');

            return redirect(route('fasilitas.index'));
        }

        return view('fasilitas.show')->with('fasilitas', $fasilitas);
    }

    /**
     * Show the form for editing the specified Fasilitas.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        $fasilitas = $this->fasilitasRepository->find($id);

        if (empty($fasilitas)) {
            Flash::error('Fasilitas not found');

            return redirect(route('fasilitas.index'));
        }

        return view('fasilitas.edit')->with('fasilitas', $fasilitas);
    }

    /**
     * Update the specified Fasilitas in storage.
     *
     * @param  int              $id
     * @param UpdateFasilitasRequest $request
     *
     * @return Response
     */
    public function update($id, UpdateFasilitasRequest $request)
    {
        $fasilitas = $this->fasilitasRepository->find($id);
        if (empty($fasilitas)) {
            Flash::error('Fasilitas not found');

            return redirect(route('fasilitas.index'));
        }

        $input = $request->all();
        $input['slug']=Str::slug($input['title']);
        $fasilitas = $this->fasilitasRepository->update($input, $id);
        if($request->preloaded==null && $request->images==null){
            throw ValidationException::withMessages(['Please upload at least one image']);
        }
       //old image,check old image, delete when ID not exist
        if(isset($request->preloaded) && count($request->preloaded)>0){
            // foreach($request->preloaded as $_id ){
                $details = FasilitasFile::where('fasilitas_id',$id)->whereNotIn('id',$request->preloaded)->delete();
            // }
        }else{
            //delete old image
            $details = FasilitasFile::where('fasilitas_id',$id)->delete();
        }
        //if add new image

        if(isset($request->images) && count($request->images) > 0){
            $index = \App\Models\FasilitasFile::where('fasilitas_id',$id)->get();
            $last_index= count($index);
            foreach ($request->images as $key => $image) {
                $imageName = Str::slug($request->title) . '-' . ($last_index+1) . '.' . $image->getClientOriginalExtension();
                $image->move(public_path('/storage/fasilitas'), $imageName);
                $src = 'storage/fasilitas/' . $imageName;

                $fasilitas_files = new \App\Models\FasilitasFile();
                $fasilitas_files->src = $src;
                $fasilitas_files->fasilitas_id = $fasilitas->id;
                $fasilitas_files->save();
                $last_index++;
            }
        // }else{
        //     throw ValidationException::withMessages(['Please upload at least one image']);
        }
        Flash::success('Fasilitas updated successfully.');

        return redirect(route('fasilitas.index'));
    }

    /**
     * Remove the specified Fasilitas from storage.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function destroy($id)
    {
        // $fasilitas = $this->fasilitasRepository->find($id);

        // if (empty($fasilitas)) {
        //     Flash::error('Fasilitas not found');

        //     return redirect(route('fasilitas.index'));
        // }
        // $this->fasilitasRepository->delete($id);


        // Flash::success('Fasilitas deleted successfully.');

        // return redirect(route('fasilitas.index'));
    }
}
