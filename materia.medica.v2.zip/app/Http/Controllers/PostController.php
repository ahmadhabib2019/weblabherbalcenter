<?php

namespace App\Http\Controllers;

use App\DataTables\PostDataTable;
use App\Http\Requests;
use App\Http\Requests\CreatePostRequest;
use App\Http\Requests\UpdatePostRequest;
use App\Repositories\PostRepository;
use Flash;
use App\Http\Controllers\AppBaseController;
use Response;
use Illuminate\Support\Str;
use Intervention\Image\ImageManagerStatic as Image;
use App\Models\Menu;
use App\Models\Fasilitas;
use Illuminate\Validation\ValidationException;

class PostController extends AppBaseController
{
    /** @var  PostRepository */
    private $postRepository;
    protected $categories;
    public function __construct(PostRepository $postRepo)
    {
        $this->categories = ['page' => 'Page', 'artikel' => 'Artikel', 'berita' => 'Berita','penelitian'=>'Penelitian','fasilitas'=>'Fasilitas'];
        $this->postRepository = $postRepo;
    }

    /**
     * Display a listing of the Post.
     *
     * @param PostDataTable $postDataTable
     * @return Response
     */
    public function index(PostDataTable $postDataTable)
    {
        return $postDataTable->render('posts.index');
    }

    /**
     * Show the form for creating a new Post.
     *
     * @return Response
     */
    public function create()
    {
        return view('posts.create')->with('categories', $this->categories);
    }

    /**
     * Store a newly created Post in storage.
     *
     * @param CreatePostRequest $request
     *
     * @return Response
     */
    public function store(CreatePostRequest $request)
    {
        $input = $request->all();

        $input['slug'] = Str::slug($request->title);
         if($request->hasFile('featured_image')){
            $filename = time().$input['slug'].'-'.Str::random(3).'.'.$request->featured_image->extension();
            $image_resize = Image::make($request->featured_image);              
            $image_resize->resize(485, 288);
            $destinationPath = public_path('storage/post/featured_image/');
            $image_resize->save($destinationPath. $filename);
            $input['featured_image']='storage/post/featured_image/'.$filename;
        }
        $image = $request->content;  // your base64 encoded
        $image = str_replace('data:image/png;base64,', '', $image);
        $image = str_replace(' ', '+', $image);
        $imageName = $input['slug'].'.'.'png';
        \File::put(public_path(). '/storage/post/featured_image/' . $imageName, base64_decode($image));

        $this->postRepository->create($input);
        Flash::success('Post saved successfully.');

        return redirect(route('posts.category',['category'=>$request->category]));
    }

    /**
     * Display the specified Post.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function show($id)
    {
        $post = $this->postRepository->find($id);

        if (empty($post)) {
            Flash::error('Post not found');

            return redirect(route('posts.index'));
        }

        return view('posts.show')->with('post', $post);
    }

    /**
     * Show the form for editing the specified Post.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        $post = $this->postRepository->find($id);
        if (empty($post)) {
            Flash::error('Post not found');

            return redirect(route('posts.index'));
        }

        return view('posts.edit')
        ->with('post', $post)
        ->with('categories', $this->categories);
    }

    /**
     * Update the specified Post in storage.
     *
     * @param  int              $id
     * @param UpdatePostRequest $request
     *
     * @return Response
     */
    public function update($id, UpdatePostRequest $request)
    {
        $post = $this->postRepository->find($id);

        if (empty($post)) {
            Flash::error('Post not found');

            return redirect(route('posts.index'));
        }
        $input = $request->all();
        $input['slug'] = Str::slug($request->title);
        
        $image = $request->content;  // your base64 encoded
        $image = str_replace('data:image/png;base64,', '', $image);
        $image = str_replace(' ', '+', $image);
        $imageName = $input['slug'].'.'.'png';
        \File::put(public_path(). '/storage/post/featured_image/' . $imageName, base64_decode($image));
        
         if($request->hasFile('featured_image')){
            $filename = time().$input['slug'].'-'.$post->id.'.'.$request->featured_image->extension();
            $image_resize = Image::make($request->featured_image);              
            $image_resize->resize(485, 288);
            $destinationPath = public_path('storage/post/featured_image/');
            $image_resize->save($destinationPath. $filename);
            $input['featured_image']='storage/post/featured_image/'.$filename;
        }
        $this->postRepository->update($input, $id);
        Flash::success('Post updated successfully.');
        return redirect(route('posts.category',['category'=>$request->category]));
    }

    /**
     * Remove the specified Post from storage.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function destroy($id)
    {
        $post = $this->postRepository->find($id);

        if (empty($post)) {
            Flash::error('Post not found');

            return redirect(route('posts.index'));
        }

        $this->postRepository->delete($id);

        Flash::success('Post deleted successfully.');

        return back();
    }

    public function post_cat(PostDataTable $postDataTable){
        return $postDataTable->with('category','page')->render('posts.index');
    }
}
