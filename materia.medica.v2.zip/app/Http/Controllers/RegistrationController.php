<?php

namespace App\Http\Controllers;

use App\DataTables\RegistrationDataTable;
use Illuminate\Http\Request;
use App\Http\Requests\CreateRegistrationRequest;
use App\Http\Requests\UpdateRegistrationRequest;
use App\Repositories\RegistrationRepository;
use Flash;
use App\Http\Controllers\AppBaseController;
use Response;
use App\Models\RegistrationValue;
use App\Models\Registration;

class RegistrationController extends AppBaseController
{
    /** @var  RegistrationRepository */
    private $registrationRepository;

    public function __construct(RegistrationRepository $registrationRepo)
    {
        $this->registrationRepository = $registrationRepo;
    }

    /**
     * Display a listing of the Registration.
     *
     * @param RegistrationDataTable $registrationDataTable
     * @return Response
     */
    public function index(RegistrationDataTable $registrationDataTable)
    {
        return $registrationDataTable->render('registrations.index');
    }

    /**
     * Show the form for creating a new Registration.
     *
     * @return Response
     */
    public function create()
    {
        return view('registrations.create');
    }

    /**
     * Store a newly created Registration in storage.
     *
     * @param CreateRegistrationRequest $request
     *
     * @return Response
     */
    public function store(CreateRegistrationRequest $request)
    {
        $input = $request->all();

        $registration = $this->registrationRepository->create($input);

        Flash::success('Registration saved successfully.');

        return redirect(route('registrations.index'));
    }

    /**
     * Display the specified Registration.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function show($id)
    {
        $registration = $this->registrationRepository->find($id);

        if (empty($registration)) {
            Flash::error('Registration not found');

            return redirect(route('registrations.index'));
        }

        return view('registrations.show')->with('registration', $registration);
    }

    /**
     * Show the form for editing the specified Registration.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        //disable edit form backend
    //     $registration = $this->registrationRepository->find($id);

    //     if (empty($registration)) {
    //         Flash::error('Registration not found');

    //         return redirect(route('registrations.index'));
    //     }

    //     return view('registrations.edit')->with('registration', $registration);
    }

    /**
     * Update the specified Registration in storage.
     *
     * @param  int              $id
     * @param UpdateRegistrationRequest $request
     *
     * @return Response
     */
    public function update($id, UpdateRegistrationRequest $request)
    {
        //disable edit from backend
        // $registration = $this->registrationRepository->find($id);

        // if (empty($registration)) {
        //     Flash::error('Registration not found');

        //     return redirect(route('registrations.index'));
        // }

        // $registration = $this->registrationRepository->update($request->all(), $id);

        // Flash::success('Registration updated successfully.');

        // return redirect(route('registrations.index'));
    }

    /**
     * Remove the specified Registration from storage.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function destroy($id)
    {
        $registration = $this->registrationRepository->find($id);

        if (empty($registration)) {
            Flash::error('Registration not found');

            return redirect(route('registrations.index'));
        }

        $this->registrationRepository->delete($id);

        Flash::success('Registration deleted successfully.');

        return redirect(route('registrations.index'));
    }

    public function unduhFile($id){
        $file = RegistrationValue::where('id',$id)->first();
        if(is_null($file->values)){
            return back();
        }

        return response()->download($file->values);
    }

    public function agreement($id,Request $request){
        $registration = $this->registrationRepository->find($id);

        $registration->agreement = $request->status;
        $registration->save();
        
        return back();
        
    }
}
