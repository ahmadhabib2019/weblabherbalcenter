<?php

namespace App\Http\Controllers;

use App\DataTables\CalendarEventDataTable;
use App\Http\Requests;
use App\Http\Requests\CreateCalendarEventRequest;
use App\Http\Requests\UpdateCalendarEventRequest;
use App\Repositories\CalendarEventRepository;
use Flash;
use App\Http\Controllers\AppBaseController;
use Response;

class CalendarEventController extends AppBaseController
{
    /** @var  CalendarEventRepository */
    private $calendarEventRepository;

    public function __construct(CalendarEventRepository $calendarEventRepo)
    {
        $this->calendarEventRepository = $calendarEventRepo;
    }

    /**
     * Display a listing of the CalendarEvent.
     *
     * @param CalendarEventDataTable $calendarEventDataTable
     * @return Response
     */
    public function index(CalendarEventDataTable $calendarEventDataTable)
    {
        return $calendarEventDataTable->render('calendar_events.index');
    }

    /**
     * Show the form for creating a new CalendarEvent.
     *
     * @return Response
     */
    public function create()
    {
        return view('calendar_events.create');
    }

    /**
     * Store a newly created CalendarEvent in storage.
     *
     * @param CreateCalendarEventRequest $request
     *
     * @return Response
     */
    public function store(CreateCalendarEventRequest $request)
    {
        $input = $request->all();

        $calendarEvent = $this->calendarEventRepository->create($input);

        Flash::success('Calendar Event saved successfully.');

        return redirect(route('calendarEvents.index'));
    }

    /**
     * Display the specified CalendarEvent.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function show($id)
    {
        $calendarEvent = $this->calendarEventRepository->find($id);

        if (empty($calendarEvent)) {
            Flash::error('Calendar Event not found');

            return redirect(route('calendarEvents.index'));
        }

        return view('calendar_events.show')->with('calendarEvent', $calendarEvent);
    }

    /**
     * Show the form for editing the specified CalendarEvent.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        $calendarEvent = $this->calendarEventRepository->find($id);

        if (empty($calendarEvent)) {
            Flash::error('Calendar Event not found');

            return redirect(route('calendarEvents.index'));
        }

        return view('calendar_events.edit')->with('calendarEvent', $calendarEvent);
    }

    /**
     * Update the specified CalendarEvent in storage.
     *
     * @param  int              $id
     * @param UpdateCalendarEventRequest $request
     *
     * @return Response
     */
    public function update($id, UpdateCalendarEventRequest $request)
    {
        $calendarEvent = $this->calendarEventRepository->find($id);

        if (empty($calendarEvent)) {
            Flash::error('Calendar Event not found');

            return redirect(route('calendarEvents.index'));
        }

        $calendarEvent = $this->calendarEventRepository->update($request->all(), $id);

        Flash::success('Calendar Event updated successfully.');

        return redirect(route('calendarEvents.index'));
    }

    /**
     * Remove the specified CalendarEvent from storage.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function destroy($id)
    {
        $calendarEvent = $this->calendarEventRepository->find($id);

        if (empty($calendarEvent)) {
            Flash::error('Calendar Event not found');

            return redirect(route('calendarEvents.index'));
        }

        $this->calendarEventRepository->delete($id);

        Flash::success('Calendar Event deleted successfully.');

        return redirect(route('calendarEvents.index'));
    }
}
