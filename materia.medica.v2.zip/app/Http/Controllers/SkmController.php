<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ViewSkm;

class SkmController extends Controller
{
    public function index(){
        $formskm = ViewSkm::all();
         return view('skm.index');
    }
    public function show(Request $request){
        if(isset($request->start)){
            $tgl = $request->start;
            $data = ViewSkm::whereMonth('tgl',$tgl)->get();
            return view('skm.index',compact('data'));
        }
    }
}