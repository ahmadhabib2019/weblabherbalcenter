<?php

namespace App\Http\Controllers;

use App\DataTables\ProdukOrderDataTable;
use App\Http\Requests;
use App\Http\Requests\CreateProdukOrderRequest;
use App\Http\Requests\UpdateProdukOrderRequest;
use App\Repositories\ProdukOrderRepository;
use Flash;
use App\Http\Controllers\AppBaseController;
use Response;
use App\Models\ProdukOrderDetail;

class ProdukOrderController extends AppBaseController
{
    /** @var  ProdukOrderRepository */
    private $produkOrderRepository;

    public function __construct(ProdukOrderRepository $produkOrderRepo)
    {
        $this->produkOrderRepository = $produkOrderRepo;
    }

    /**
     * Display a listing of the ProdukOrder.
     *
     * @param ProdukOrderDataTable $produkOrderDataTable
     * @return Response
     */
    public function index(ProdukOrderDataTable $produkOrderDataTable)
    {
        return $produkOrderDataTable->render('produk_orders.index');
    }

    /**
     * Show the form for creating a new ProdukOrder.
     *
     * @return Response
     */
    public function create()
    {
        return view('produk_orders.create');
    }

    /**
     * Store a newly created ProdukOrder in storage.
     *
     * @param CreateProdukOrderRequest $request
     *
     * @return Response
     */
    public function store(CreateProdukOrderRequest $request)
    {
        $input = $request->all();

        $produkOrder = $this->produkOrderRepository->create($input);

        Flash::success('Produk Order saved successfully.');

        return redirect(route('produkOrders.index'));
    }

    /**
     * Display the specified ProdukOrder.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function show($id)
    {
        $produkOrder = $this->produkOrderRepository->find($id);
        $produkOrderDetail = ProdukOrderDetail::where('order_id',$id)->get();

        if (empty($produkOrder)) {
            Flash::error('Produk Order not found');

            return redirect(route('produkOrders.index'));
        }

        return view('produk_orders.show')->with('produkOrder', $produkOrder)->with('produkOrderDetail', $produkOrderDetail);
    }

    /**
     * Show the form for editing the specified ProdukOrder.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        $produkOrder = $this->produkOrderRepository->find($id);

        if (empty($produkOrder)) {
            Flash::error('Produk Order not found');

            return redirect(route('produkOrders.index'));
        }

        return view('produk_orders.edit')->with('produkOrder', $produkOrder);
    }

    /**
     * Update the specified ProdukOrder in storage.
     *
     * @param  int              $id
     * @param UpdateProdukOrderRequest $request
     *
     * @return Response
     */
    public function update($id, UpdateProdukOrderRequest $request)
    {
        $produkOrder = $this->produkOrderRepository->find($id);

        if (empty($produkOrder)) {
            Flash::error('Produk Order not found');

            return redirect(route('produkOrders.index'));
        }

        $produkOrder = $this->produkOrderRepository->update($request->all(), $id);

        Flash::success('Produk Order updated successfully.');

        return redirect(route('produkOrders.index'));
    }

    /**
     * Remove the specified ProdukOrder from storage.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function destroy($id)
    {
        $produkOrder = $this->produkOrderRepository->find($id);

        if (empty($produkOrder)) {
            Flash::error('Produk Order not found');

            return redirect(route('produkOrders.index'));
        }

        $this->produkOrderRepository->delete($id);

        Flash::success('Produk Order deleted successfully.');

        return redirect(route('produkOrders.index'));
    }
}
