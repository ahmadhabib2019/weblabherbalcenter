<?php

namespace App\Http\Controllers;

use App\DataTables\PenelitianDataTable;
use App\Http\Requests;
use App\Http\Requests\CreatePenelitianRequest;
use App\Http\Requests\UpdatePenelitianRequest;
use App\Repositories\PenelitianRepository;
use Flash;
use App\Http\Controllers\AppBaseController;
use Illuminate\Validation\ValidationException;
use Response;
use Str;
use File;

class PenelitianController extends AppBaseController
{
    /** @var  PenelitianRepository */
    private $penelitianRepository;

    public function __construct(PenelitianRepository $penelitianRepo)
    {
        $this->penelitianRepository = $penelitianRepo;
    }

    /**
     * Display a listing of the Penelitian.
     *
     * @param PenelitianDataTable $penelitianDataTable
     * @return Response
     */
    public function index(PenelitianDataTable $penelitianDataTable)
    {
        return $penelitianDataTable->render('penelitians.index');
    }

    /**
     * Show the form for creating a new Penelitian.
     *
     * @return Response
     */
    public function create()
    {
        return view('penelitians.create');
    }

    /**
     * Store a newly created Penelitian in storage.
     *
     * @param CreatePenelitianRequest $request
     *
     * @return Response
     */
    public function store(CreatePenelitianRequest $request)
    {
        $input = $request->all();

            $imageName = Str::slug($request->title) .  '.' . $input['images']->getClientOriginalExtension();
            $destinationPathImg = public_path('/storage/penelitian/image');
            $input['images']->move($destinationPathImg, $imageName);
            
            $destinationPathPdf = public_path('storage/penelitian/pdf');
            $pdfName = $input['file']->getClientOriginalName();
            $input['file']->move($destinationPathPdf, $pdfName);
            
            $srcimage = 'storage/penelitian/image/' . $imageName;
            $srcpdf = 'storage/penelitian/pdf/' . $pdfName;
            
            $input['file'] = $srcpdf;
            $input['images'] = $srcimage;
            $input['category'] = 'penelitian';

            $penelitian = $this->penelitianRepository->create($input);
        Flash::success('Penelitian saved successfully.');

        return redirect(route('penelitians.index'));
    }

    /**
     * Display the specified Penelitian.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function show($id)
    {
        $penelitian = $this->penelitianRepository->find($id);

        if (empty($penelitian)) {
            Flash::error('Penelitian not found');

            return redirect(route('penelitians.index'));
        }

        return view('penelitians.show')->with('penelitian', $penelitian);
    }

    /**
     * Show the form for editing the specified Penelitian.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        $penelitian = $this->penelitianRepository->find($id);

        if (empty($penelitian)) {
            Flash::error('Penelitian not found');

            return redirect(route('penelitians.index'));
        }

        return view('penelitians.edit')->with('penelitian', $penelitian);
    }

    /**
     * Update the specified Penelitian in storage.
     *
     * @param  int              $id
     * @param UpdatePenelitianRequest $request
     *
     * @return Response
     */
    public function update($id, UpdatePenelitianRequest $request)
    {
        $penelitian = $this->penelitianRepository->find($id);
        $input = $request->all();
        if (empty($penelitian)) {
            Flash::error('Penelitian not found');

            return redirect(route('penelitians.index'));
        }
            if(isset($input['images']) && isset($input['file'])){
                $imageName = Str::slug($input['title']) . '.' . $input['images']->getClientOriginalExtension();
                $destinationPathImg = public_path('storage/penelitian/image');
                $input['images']->move($destinationPathImg, $imageName);
                File::delete($input['image']);
            
                $destinationPathPdf = public_path('storage/penelitian/pdf');
                $pdfName = $input['file']->getClientOriginalName();
                $input['file']->move($destinationPathPdf, $pdfName);
                
                $srcimage = 'storage/penelitian/image/' . $imageName;
                $srcpdf = 'storage/penelitian/pdf/' . $pdfName;
                
                $input['file'] = $srcpdf;
                $input['images'] = $srcimage;

            }elseif( isset($input['images'])){
                $imageName = Str::slug($input['title']) . '.' . $input['images']->getClientOriginalExtension();
                $destinationPathImg = public_path('storage/penelitian/image');
                $input['images']->move($destinationPathImg, $imageName);
                File::delete($input['image']);
            
                $srcimage = 'storage/penelitian/image/' . $imageName;
                $input['images'] = $srcimage;
                $input['file'] = $input['files'];

            }elseif(isset($input['file'])){

                $destinationPathPdf = public_path('storage/penelitian/pdf');
                $pdfName = $input['files']->getClientOriginalName();
                $input['files']->move($destinationPathPdf, $pdfName);
                
                $srcpdf = 'storage/penelitian/pdf/' . $pdfName;
                
                $input['file'] = $srcpdf;
                $input['images'] = $input['image'];
            }else{
                $input['images'] = $input['image'];
                $input['file'] = $input['files'];
            }
        $penelitian = $this->penelitianRepository->update($input, $id);

        Flash::success('Penelitian updated successfully.');

        return redirect(route('penelitians.index'));
    }

    /**
     * Remove the specified Penelitian from storage.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function destroy($id)
    {
        $penelitian = $this->penelitianRepository->find($id);

        if (empty($penelitian)) {
            Flash::error('Penelitian not found');

            return redirect(route('penelitians.index'));
        }

        $this->penelitianRepository->delete($id);

        Flash::success('Penelitian deleted successfully.');

        return redirect(route('penelitians.index'));
    }
}
