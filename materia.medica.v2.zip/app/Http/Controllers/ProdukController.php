<?php

namespace App\Http\Controllers;

use App\DataTables\ProdukDataTable;
use App\Http\Requests;
use App\Http\Requests\CreateProdukRequest;
use App\Http\Requests\UpdateProdukRequest;
use App\Repositories\ProdukRepository;
use Flash;
use App\Http\Controllers\AppBaseController;
use Response;
use App\Models\ProdukKategori;
use App\Models\ProdukDetail;
use App\Models\ProdukImage;
use Illuminate\Validation\ValidationException;
use Illuminate\Support\Str;

class ProdukController extends AppBaseController
{
    /** @var  ProdukRepository */
    private $produkRepository;

    public function __construct(ProdukRepository $produkRepo)
    {
        $this->produkRepository = $produkRepo;
    }

    /**
     * Display a listing of the Produk.
     *
     * @param ProdukDataTable $produkDataTable
     * @return Response
     */
    public function index(ProdukDataTable $produkDataTable)
    {
        return $produkDataTable->render('produks.index');
    }

    /**
     * Show the form for creating a new Produk.
     *
     * @return Response
     */
    public function create()
    {
        $kategori = ProdukKategori::pluck('name','id');
        return view('produks.create')->with('kategori',$kategori);
    }

    /**
     * Store a newly created Produk in storage.
     *
     * @param CreateProdukRequest $request
     *
     * @return Response
     */
    public function store(CreateProdukRequest $request)
    {
        $input = $request->all();
        $produk = $this->produkRepository->create($input);
        if ($request->images != null) {
                try {
                    foreach ($request->images as $key => $image) {
                        $imageName = time().Str::slug($request->nama) . '-' . ($key+1) . '.' . $image->getClientOriginalExtension();
                        $destinationPath = public_path('storage/produk');
                        $image->move($destinationPath, $imageName);
                        $src = 'storage/produk/' . $imageName;
                        $produk_file = new ProdukImage();
                        $produk_file->src = $src;
                        $produk_file->produk_id = $produk->id;

                        $produk_file->save();
                    }
                } catch (\Throwable $th) {
                    throw ValidationException::withMessages(['Please upload at least one image']);
                }
        }
        $produk->produkDetails()->create([
            'kandungan'=>$input['kandungan'],
            'morfologi'=>$input['morfologi'],
            'nama_latin'=>$input['nama_latin'],
            'berat'=>$input['berat'],
            // 'pemerian'=>$input['pemerian'],
            'keunggulan'=>$input['keunggulan'],
            'isipaket'=>$input['isipaket'],
            'deskripsipaket'=>$input['deskripsipaket'],
            'nama_daerah'=>$input['nama_daerah'],
            'bagian_tanaman'=>$input['bagian_tanaman'],
            'organoleptis'=>$input['organoleptis'],
            'manfaat'=>$input['manfaat'],
            'cara_penggunaan'=>$input['cara_penggunaan'],
            'famili'=>$input['famili'],
        ]);

        Flash::success('Produk saved successfully.');

        return redirect(route('produks.index'));
    }

    /**
     * Display the specified Produk.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function show($id)
    {
        $produk = $this->produkRepository->find($id);

        if (empty($produk)) {
            Flash::error('Produk not found');

            return redirect(route('produks.index'));
        }

        return view('produks.show')->with('produk', $produk);
    }

    /**
     * Show the form for editing the specified Produk.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        $produk = $this->produkRepository->find($id);
        $kategori = ProdukKategori::pluck('name','id');
        if (empty($produk)) {
            Flash::error('Produk not found');

            return redirect(route('produks.index'));
        }

        return view('produks.edit')
        ->with('kategori', $kategori)
        ->with('produk', $produk);
    }

    /**
     * Update the specified Produk in storage.
     *
     * @param  int              $id
     * @param UpdateProdukRequest $request
     *
     * @return Response
     */
    public function update($id, UpdateProdukRequest $request)
    {
        $produk = $this->produkRepository->find($id);
        if (empty($produk)) {
            Flash::error('Produk not found');

            return redirect(route('produks.index'));
        }
        $produk = $this->produkRepository->update($request->all(), $id);
        if($request->preloaded==null && $request->images==null){
            throw ValidationException::withMessages(['Please upload at least one image']);
        }
       //old image,check old image, delete when ID not existdd  

       if($request->preloaded != null && $request->preloaded > 0){
           // foreach($request->preloaded as $_id ){
                $details = ProdukImage::where('produk_id',$id)->whereNotIn('id',$request->preloaded)->delete();
            // }
        }else{
           //delete old image
                $details = ProdukImage::where('produk_id',$id)->delete();
        }
        //if add new image

        if(isset($request->images) && count($request->images) > 0){ 
            $index = ProdukImage::where('produk_id',$id)->get();
            $last_index= count($index);
            foreach ($request->images as $key => $image) {
                $imageName = time().Str::slug($request->title) . '-' . ($last_index+1) . '.' . $image->getClientOriginalExtension();
                $destinationPath = public_path('storage/produk');
                $image->move($destinationPath, $imageName);
                $src = 'storage/produk/' . $imageName;

                $produk_images = new ProdukImage();
                $produk_images->src = $src;
                $produk_images->produk_id = $produk->id;
                $produk_images->save();
                $last_index++;
            }
        // }else{
        //     throw ValidationException::withMessages(['Please upload at least one image']);
        }

        $produk->produkDetails()->update([
            'nama_latin'=>$request->nama_latin,
            'berat'=>$request->berat,
            // 'pemerian'=>$request->pemerian,
            'keunggulan'=>$request->keunggulan,
            'isipaket'=>$request->isipaket,
            'deskripsipaket'=>$request->deskripsipaket,
            'nama_daerah'=>$request->nama_daerah,
            'bagian_tanaman'=>$request->bagian_tanaman,
            'organoleptis'=>$request->organoleptis,
            'manfaat'=>$request->manfaat,
            'cara_penggunaan'=>$request->cara_penggunaan,
            'famili'=>$request->famili,
            'kandungan'=>$request->kandungan,
            'morfologi'=>$request->morfologi,
        ]);


        Flash::success('Produk updated successfully.');

        return redirect(route('produks.index'));
    }

    /**
     * Remove the specified Produk from storage.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function destroy($id)
    {
        $produk = $this->produkRepository->find($id);

        if (empty($produk)) {
            Flash::error('Produk not found');

            return redirect(route('produks.index'));
        }

        $this->produkRepository->delete($id);

        Flash::success('Produk deleted successfully.');

        return redirect(route('produks.index'));
    }
    
}
