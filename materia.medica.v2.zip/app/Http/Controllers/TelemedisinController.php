<?php

namespace App\Http\Controllers;

use App\DataTables\TelemedisinDataTable;
use App\Http\Requests;
use App\Http\Requests\CreateTelemedisinRequest;
use App\Http\Requests\UpdateTelemedisinRequest;
use App\Repositories\TelemedisinRepository;
use Flash;
use App\Http\Controllers\AppBaseController;
use Response;
use App\Models\User;

class TelemedisinController extends AppBaseController
{
    /** @var  TelemedisinRepository */
    private $telemedisinRepository;

    public function __construct(TelemedisinRepository $telemedisinRepo)
    {
        $this->telemedisinRepository = $telemedisinRepo;
    }

    /**
     * Display a listing of the Telemedisin.
     *
     * @param TelemedisinDataTable $telemedisinDataTable
     * @return Response
     */
    public function index(TelemedisinDataTable $telemedisinDataTable)
    {
        return $telemedisinDataTable->render('telemedisins.index');
    }

    /**
     * Show the form for creating a new Telemedisin.
     *
     * @return Response
     */
    public function create()
    {
        return view('telemedisins.create');
    }

    /**
     * Store a newly created Telemedisin in storage.
     *
     * @param CreateTelemedisinRequest $request
     *
     * @return Response
     */
    public function store(CreateTelemedisinRequest $request)
    {
        $input = $request->all();

        $telemedisin = $this->telemedisinRepository->create($input);

        Flash::success('Telemedisin saved successfully.');

        return redirect(route('telemedisins.index'));
    }

    /**
     * Display the specified Telemedisin.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function show($id)
    {
        $telemedisin = $this->telemedisinRepository->find($id);

        if (empty($telemedisin)) {
            Flash::error('Telemedisin not found');

            return redirect(route('telemedisins.index'));
        }

        return view('telemedisins.show')->with('telemedisin', $telemedisin);
    }

    /**
     * Show the form for editing the specified Telemedisin.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        $telemedisin = $this->telemedisinRepository->find($id);
        $user = User::pluck('name','id');


        if (empty($telemedisin)) {
            Flash::error('Telemedisin not found');

            return redirect(route('telemedisins.index'));
        }

        return view('telemedisins.edit')->with('telemedisin', $telemedisin)->with('user',$user);
    }

    /**
     * Update the specified Telemedisin in storage.
     *
     * @param  int              $id
     * @param UpdateTelemedisinRequest $request
     *
     * @return Response
     */
    public function update($id, UpdateTelemedisinRequest $request)
    {
        $telemedisin = $this->telemedisinRepository->find($id);

        if (empty($telemedisin)) {
            Flash::error('Telemedisin not found');

            return redirect(route('telemedisins.index'));
        }

        $telemedisin = $this->telemedisinRepository->update($request->all(), $id);

        Flash::success('Telemedisin updated successfully.');

        return redirect(route('telemedisins.index'));
    }

    /**
     * Remove the specified Telemedisin from storage.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function destroy($id)
    {
        $telemedisin = $this->telemedisinRepository->find($id);

        if (empty($telemedisin)) {
            Flash::error('Telemedisin not found');

            return redirect(route('telemedisins.index'));
        }

        $this->telemedisinRepository->delete($id);

        Flash::success('Telemedisin deleted successfully.');

        return redirect(route('telemedisins.index'));
    }
}
