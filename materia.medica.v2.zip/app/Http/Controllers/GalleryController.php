<?php

namespace App\Http\Controllers;

use App\DataTables\GalleryDataTable;
use App\Http\Requests;
use App\Http\Requests\CreateGalleryRequest;
use App\Http\Requests\UpdateGalleryRequest;
use App\Repositories\GalleryRepository;
use Flash;
use App\Http\Controllers\AppBaseController;
use App\Models\GalleryDetail;
use Response;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;
use Intervention\Image\ImageManagerStatic as Image;

class GalleryController extends AppBaseController
{
    /** @var  GalleryRepository */
    private $galleryRepository;
    protected $categories;

    public function __construct(GalleryRepository $galleryRepo)
    {
        $this->categories = ['kegiatan' => 'Kegiatan', 'tanaman-obat' => 'Tanaman Obat'];
        $this->galleryRepository = $galleryRepo;
    }

    /**
     * Display a listing of the Gallery.
     *
     * @param GalleryDataTable $galleryDataTable
     * @return Response
     */
    public function index(GalleryDataTable $galleryDataTable)
    {
        return $galleryDataTable->render('galleries.index');
    }

    /**
     * Show the form for creating a new Gallery.
     *
     * @return Response
     */
    public function create()
    {
        return view('galleries.create')->with('categories', $this->categories);
    }

    /**
     * Store a newly created Gallery in storage.
     *
     * @param CreateGalleryRequest $request
     *
     * @return Response
     */
    public function store(CreateGalleryRequest $request)
    {
        $input = $request->all();
        $gallery = $this->galleryRepository->create($input);
        try {
            foreach ($request->images as $key => $image) {
                $imageName = time().Str::slug($request->title) . '-' . ($key+1) . '.' . $image->getClientOriginalExtension();
                $destinationPath = public_path('storage/gallery');
                //resize image
                $image_resize = Image::make($image->getRealPath());     

                $image_resize->resize(1280, 720, function ($constraint) {
                    $constraint->aspectRatio();
                })->save($destinationPath.'/'. $imageName);
                //save image
                $image->move($destinationPath. $imageName);
                $src = 'storage/gallery/' . $imageName;

                $gallery_details = new \App\Models\GalleryDetail();
                $gallery_details->src = $src;
                $gallery_details->gallery_id = $gallery->id;
                $gallery_details->save();
            }
        } catch (\Throwable $th) {
            throw ValidationException::withMessages(['Please upload at least one image']);
        }

        Flash::success('Gallery saved successfully.');
        return redirect(route('galleries.index'));
    }

    /**
     * Display the specified Gallery.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function show($id)
    {
        $gallery = $this->galleryRepository->find($id);
        if (empty($gallery)) {
            Flash::error('Gallery not found');

            return redirect(route('galleries.index'));
        }

        return view('galleries.show')->with('gallery', $gallery);
    }

    /**
     * Show the form for editing the specified Gallery.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        $gallery = $this->galleryRepository->find($id);

        if (empty($gallery)) {
            Flash::error('Gallery not found');

            return redirect(route('galleries.index'));
        }

        return view('galleries.edit')->with('gallery', $gallery)->with('categories', $this->categories);
    }

    /**
     * Update the specified Gallery in storage.
     *
     * @param  int              $id
     * @param UpdateGalleryRequest $request
     *
     * @return Response
     */
    public function update($id, UpdateGalleryRequest $request)
    {

        $gallery = $this->galleryRepository->find($id);
        if (empty($gallery)) {
            Flash::error('Gallery not found');

            return redirect(route('galleries.index'));
        }

        $gallery = $this->galleryRepository->update($request->all(), $id);
        if($request->preloaded==null && $request->images==null){
            throw ValidationException::withMessages(['Please upload at least one image']);
        }
       //old image,check old image, delete when ID not exist
       if($request->preloaded != null && $request->preloaded > 0){
        // foreach($request->preloaded as $_id ){
                $details = GalleryDetail::where('gallery_id',$id)->whereNotIn('id',$request->preloaded)->delete();
            // }
        }else{
            //delete old image
            $details = GalleryDetail::where('gallery_id',$id)->delete();
        }
        //if add new image

        if(isset($request->images) && count($request->images) > 0){ 
            $index = \App\Models\GalleryDetail::where('gallery_id',$id)->get();
            $last_index= count($index);
            foreach ($request->images as $key => $image) {
                $imageName = time().Str::slug($request->title) . '-' . ($last_index+1) . '.' . $image->getClientOriginalExtension();
                $destinationPath = public_path('storage/gallery');
                $image_resize = Image::make($image->getRealPath());     

                $image_resize->resize(1280, 720, function ($constraint) {
                    $constraint->aspectRatio();
                })->save($destinationPath.'/'. $imageName);
                $image->move($destinationPath. $imageName);
                $src = 'storage/gallery/' . $imageName;

                $gallery_details = new \App\Models\GalleryDetail();
                $gallery_details->src = $src;
                $gallery_details->gallery_id = $gallery->id;
                $gallery_details->save();
                $last_index++;
            }
        // }else{
        //     throw ValidationException::withMessages(['Please upload at least one image']);
        }

        
        
        Flash::success('Gallery updated successfully.');

        return redirect(route('galleries.index'));
    }

    /**
     * Remove the specified Gallery from storage.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function destroy($id)
    {
        $gallery = $this->galleryRepository->find($id);

        if (empty($gallery)) {
            Flash::error('Gallery not found');

            return redirect(route('galleries.index'));
        }

        $this->galleryRepository->delete($id);

        Flash::success('Gallery deleted successfully.');

        return redirect(route('galleries.index'));
    }
}
