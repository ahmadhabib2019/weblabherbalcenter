<?php

namespace App\Http\Controllers;

use App\DataTables\UnduhDataTable;
use App\Http\Requests;
use App\Http\Requests\CreateUnduhRequest;
use App\Http\Requests\UpdateUnduhRequest;
use App\Repositories\UnduhRepository;
use Flash;
use App\Http\Controllers\AppBaseController;
use Response;
use Str;

class UnduhController extends AppBaseController
{
    /** @var  UnduhRepository */
    private $unduhRepository;

    public function __construct(UnduhRepository $unduhRepo)
    {
        $this->category = ['bulletin'=>'Bulletin','ebook'=>'E-Book','peraturan'=>'Peraturan'];
        $this->unduhRepository = $unduhRepo;
    }

    /**
     * Display a listing of the Unduh.
     *
     * @param UnduhDataTable $unduhDataTable
     * @return Response
     */
    public function index(UnduhDataTable $unduhDataTable)
    {
        return $unduhDataTable->render('unduhs.index');
    }

    /**
     * Show the form for creating a new Unduh.
     *
     * @return Response
     */
    public function create()
    {
        $category = $this->category;
        return view('unduhs.create')->with('category',$category);
    }

    /**
     * Store a newly created Unduh in storage.
     *
     * @param CreateUnduhRequest $request
     *
     * @return Response
     */
    public function store(CreateUnduhRequest $request)
    {
        $input = $request->all();
        $file = $request->file();
            if(isset($file)){
                // foreach($input['image'] as $image) {
                    $imageName = Str::slug($request->title) . '.' . $request->image->getClientOriginalExtension();
                    $destinationPathImg = public_path('storage/unduh/image');
                    $request->image->move($destinationPathImg, $imageName);
                
                    $destinationPathPdf = public_path('storage/unduh/pdf');
                    $pdfName = $request->file->getClientOriginalName();
                    $request->file->move($destinationPathPdf, $pdfName);
                    
                    $srcimage = 'storage/unduh/image/' . $imageName;
                    $srcpdf = 'storage/unduh/pdf/' . $pdfName;
                    
                    $input['file'] = $srcpdf;
                    $input['image'] = $srcimage;
                    // }
            }
               
            $unduh = $this->unduhRepository->create($input);
        Flash::success('Unduh saved successfully.');

        return redirect(route('unduhs.index'));
    }

    /**
     * Display the specified Unduh.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function show($id)
    {
        $unduh = $this->unduhRepository->find($id);

        if (empty($unduh)) {
            Flash::error('Unduh not found');

            return redirect(route('unduhs.index'));
        }

        return view('unduhs.show')->with('unduh', $unduh);
    }

    /**
     * Show the form for editing the specified Unduh.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        $unduh = $this->unduhRepository->find($id);

        if (empty($unduh)) {
            Flash::error('Unduh not found');

            return redirect(route('unduhs.index'));
        }
        $category = $this->category;

        return view('unduhs.edit')->with('unduh', $unduh)->with('category',$category);
    }

    /**
     * Update the specified Unduh in storage.
     *
     * @param  int              $id
     * @param UpdateUnduhRequest $request
     *
     * @return Response
     */
    public function update($id, UpdateUnduhRequest $request)
    {
        $unduh = $this->unduhRepository->find($id);
        $input = $request->all();
        if (empty($unduh)) {
            Flash::error('Unduh not found');

            return redirect(route('unduhs.index'));
        }

                if(isset($input['image']) && isset($input['file'])){
                    $imageName = Str::slug($input['title']) . '.' . $input['image']->getClientOriginalExtension();
                    $destinationPathImg = public_path('storage/unduh/image');
                    $input['image']->move($destinationPathImg, $imageName);
                
                    $destinationPathPdf = public_path('storage/unduh/pdf');
                    $pdfName = $input['file']->getClientOriginalName();
                    $input['file']->move($destinationPathPdf, $pdfName);
                    
                    $srcimage = 'storage/unduh/image/' . $imageName;
                    $srcpdf = 'storage/unduh/pdf/' . $pdfName;
                    
                    $input['file'] = $srcpdf;
                    $input['image'] = $srcimage;

                }elseif( isset($input['image'])){

                    $imageName = Str::slug($input['title']) . '.' . $input['image']->getClientOriginalExtension();
                    $destinationPathImg = public_path('storage/unduh/image');
                    $input['image']->move($destinationPathImg, $imageName);
                
                    $srcimage = 'storage/unduh/image/' . $imageName;
                    
                    $input['image'] = $srcimage;
                    $input['file'] = $input['files'];

                }elseif(isset($input['file'])){

                    $destinationPathPdf = public_path('storage/unduh/pdf');
                    $pdfName = $input['file']->getClientOriginalName();
                    $input['file']->move($destinationPathPdf, $pdfName);
                    
                    $srcpdf = 'storage/unduh/pdf/' . $pdfName;
                    
                    $input['file'] = $srcpdf;
                    $input['image'] = $input['images'];
                }else{
                    
                    $input['image'] = $input['images'];
                    $input['file'] = $input['files'];
                }
        $unduh = $this->unduhRepository->update($input, $id);

        Flash::success('Unduh updated successfully.');

        return redirect(route('unduhs.index'));
    }

    /**
     * Remove the specified Unduh from storage.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function destroy($id)
    {
        $unduh = $this->unduhRepository->find($id);

        if (empty($unduh)) {
            Flash::error('Unduh not found');

            return redirect(route('unduhs.index'));
        }

        $this->unduhRepository->delete($id);

        Flash::success('Unduh deleted successfully.');

        return redirect(route('unduhs.index'));
    }
}
