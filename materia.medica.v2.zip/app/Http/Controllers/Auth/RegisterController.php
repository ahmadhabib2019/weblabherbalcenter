<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use App\Models\User;
use App\Models\UserData;
use Illuminate\Foundation\Auth\RegistersUsers;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use App\Repositories\UserRepository;
use App\Http\Requests\CreateUserRequest;
use Laravolt\Indonesia\Models\City;
use Laravolt\Indonesia\Models\Province;
use Illuminate\Http\Request;
use Illuminate\Auth\Events\Registered;
class RegisterController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Register Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users as well as their
    | validation and creation. By default this controller uses a trait to
    | provide this functionality without requiring any additional code.
    |
    */

    use RegistersUsers;

    /**
     * Where to redirect users after registration.
     *
     * @var string
     */
    protected $redirectTo = RouteServiceProvider::HOME;
    private $userRepository;
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function showRegistrationForm($id = 0)
    {
        if (isset($id)) {
            $service_id = $id;
        } else {
            $service_id = '';
        }
        $pendidikan = ['sd' => 'SD', 'smp' => 'SLTP/SMP', 'sma' => 'SLTA/SMA/SMK', 'diploma' => 'D1/D2/D3', 's1' => 'S1', 's2/3' => 'S2', 's2/3' => 'S2/S3'];
        $pekerjaan = ['sipil' => 'PNS/TNI/POLRI', 'swasta' => 'Pegawai Swasta', 'wiraswasta' => 'Wiraswasta/Wirausaha', 'pelajar' => 'Pelajar/Mahasiswa', 'guru' => 'Guru/Dosen', 'lainya..'];
        $gender = ['L' => 'Laki-laki', 'P' => 'Perempuan'];
        $provinces = Province::pluck('name', 'id');
        return view('auth.register')
            ->with('provinces', $provinces)
            ->with('pendidikan', $pendidikan)
            ->with('gender', $gender)
            ->with('service_id', $service_id)
            ->with('pekerjaan', $pekerjaan);
    }
    public function store(Request $request)
    {
        $cities = City::where('province_id', $request->get('id'))
            ->pluck('name', 'id');
        return response()->json($cities);
    }

    public function __construct(UserRepository $userRepo)
    {
        $this->userRepository = $userRepo;
        $this->middleware('guest');
    }

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {
        return Validator::make($data, [
            'nik' => ['required', 'string', 'unique:user_data', 'max:255'],
            'nip' => ['string', 'max:255'],
            'name' => ['required', 'string', 'max:255'],
            'username' => ['required', 'string', 'max:255', 'unique:users'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'password' => ['required', 'string', 'min:8', 'confirmed'],
        ]);
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return \App\Models\User
     */
    protected function create(array $data)
    {
        try {
        $role = ['0' => 'Pengunjung'];
        $input = [
            'name' => $data['name'],
            'username' => $data['username'],
            'email' => $data['email'],
            'password' => $data['password'],
        ];
        $user = $this->userRepository->create($input);
        $user->assignRole($role);
        $user->userData()->create([
            'nik' => $data['nik'],
            'nip' => $data['nip'],
            'gender' => 'L',
            'tempat_lahir' => $data['tempat_lahir'],
            'tgl_lahir' => $data['tanngal_lahir'],
            'alamat' => $data['alamat'],
            'provinsi' => $data['provinsi'],
            'kota' => $data['kota'],
            'phone' => $data['phone'],
            'pendidikan_akhir' => $data['pendidikan_akhir'],
            'pekerjaan' => $data['pekerjaan'],
            'jurusan' => $data['jurusan'],
            'fakultas' => $data['fakultas'],
            'instansi' => $data['instansi'],
            'alamat_instansi' => $data['alamat_instansi'],
            'pekerjaan' => $data['pekerjaan'],
        ]);
        $user['service'] = $data['serviceId'];
        return $user;
        } catch (\Throwable $e) {
            echo $e;

        }
    }


    protected function registered(Request $request, $user)
    {
        return redirect()->intended($this->redirectTo);
    }

    public function handle($user)
    {
        //

        event(new Registered($user));
    }
}
