<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\Menu;
use App\Models\Gallery;
use App\Models\GalleryDetail;
use Illuminate\Http\Request;

class GalleriesController extends Controller
{
    public function index(Request $request){
        $menu = Menu::where('param', $request->category)->first();
        
        $titles = $menu->title;

        $galleries = Gallery::where('category',$request->category)->orderBy('title','asc')->paginate(12);

        if ($request->category == "tanaman-obat") {
            $judul = "Galeri Tanaman Obat";
        } else {
            $judul = "Galeri Kegiatan";
        }

        return view('frontend.gallery')->with('galleries',$galleries)->with('judul',$judul)->with('titles', $titles);
    }

    public function show(Request $request){
        $gallery=GalleryDetail::where('gallery_id',$request->gallery_id)->get();
        
        $galleries = Gallery::where('id', $request->gallery_id)->first();

        if ($galleries->category == "tanaman-obat") {
            $judul = "Galeri Tanaman Obat";
        } else {
            $judul = "Galeri Kegiatan";
        }

        return view('frontend.gallery-details')->with('gallery',$gallery)
                                                ->with('judul',$judul)
                                                ->with('galleries',$galleries);
    }
}
