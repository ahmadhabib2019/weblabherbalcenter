<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\CalendarEvent;
use App\Models\Carousel;
use App\Models\Post;
use App\Models\WebSetting;
use App\Models\FormRegistration;
use App\Models\Service;
use App\Models\Telemedisin;
use Carbon\Carbon;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function __invoke(){
        $carousels = Carousel::where('is_active',1)->get();
        $artikel = Post::where('category','artikel')->orderBy('created_at', 'desc')->paginate(3);
        $berita = Post::where('category','berita')->orderBy('created_at', 'desc')->paginate(3);
        $calendar = CalendarEvent::orderBy('created_at','desc')->paginate(3);
        $openClass = FormRegistration::where('service_id',2)->orderBy('created_at','desc')->get();
        $service = Service::whereIn('slug',['homecare','herbalmart','bibit-tanaman-obat'])->get();
        $telemedisin = Telemedisin::paginate(5);
        return view('frontend.home')
            ->with('artikel',$artikel)
            ->with('berita',$berita)
            ->with('calendar',$calendar)
            ->with('openClass',$openClass)
            ->with('service',$service)
            ->with('telemedisin',$telemedisin)
            ->with('carousels',$carousels);
    }
}
