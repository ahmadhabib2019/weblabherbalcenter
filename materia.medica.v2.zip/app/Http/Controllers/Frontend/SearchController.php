<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\Fasilitas;
use App\Models\Gallery;
use App\Models\Inovasi;
use App\Models\Penelitian;
use App\Models\Post;
use App\Models\Produk;
use App\Models\Service;
use Illuminate\Http\Request;

class SearchController extends Controller
{
    public function __invoke(Request $request)
    {
       $param  = $request->get('param');
       $posts = Post::where('title','like','%'.$param.'%')->orWhere('content','like','%'.$param.'%')->simplePaginate(5)->appends(['param' => $param]);
       $fasilitas = Fasilitas::where('title','like','%'.$param.'%')->orWhere('description','like','%'.$param.'%')->simplePaginate(5)->appends(['param' => $param]);
       $inovasi = Inovasi::where('title','like','%'.$param.'%')->orWhere('description','like','%'.$param.'%')->simplePaginate(5)->appends(['param' => $param]);
       $penelitian = Penelitian::where('title','like','%'.$param.'%')->orWhere('description','like','%'.$param.'%')->simplePaginate(5)->appends(['param' => $param]);
       $products = Produk::where('nama','like','%'.$param.'%')
       ->whereHas('produkDetails',function($q) use ($param) {
            $q->orWhere('nama_latin','like','%'.$param."%")
                ->orWhere('pemerian','like','%'.$param."%")
                ->orWhere('keunggulan','like','%'.$param."%")
                ->orWhere('isipaket','like','%'.$param."%")
                ->orWhere('deskripsipaket','like','%'.$param."%");
       })->simplePaginate(5)->appends(['param' => $param]);
       $services = Service::where('title','like','%'.$param.'%')->orWhere('description','like','%'.$param.'%')->simplePaginate(5)->appends(['param' => $param]);
       $galleries = Gallery::where('title','like','%'.$param.'%')->orWhere('category','like','%'.$param.'%')->simplePaginate(5)->appends(['param' => $param]);
       return view('frontend.search')
                ->with('posts', $posts)
                ->with('fasilitas', $fasilitas)
                ->with('inovasi', $inovasi)
                ->with('penelitian', $penelitian)
                ->with('products', $products)
                ->with('services', $services)
                ->with('galleries', $galleries)
                ->with('title', 'Search '.$param);
    }
}
