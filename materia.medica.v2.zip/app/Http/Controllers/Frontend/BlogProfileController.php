<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\Post;
use Illuminate\Http\Request;

class BlogProfileController extends Controller
{

    public function show($slug){
        $blogprofile = Post::select(['title','content','slug'])->where('slug',$slug)->first();
        return view('frontend.article')
            ->with('blogprofile', $blogprofile);
    }
}
