<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\Registration;
use Illuminate\Http\Request;

class HistoryController extends Controller
{

    public function index()
    {
        $id = auth()->user()->id;
        // $user = Registration::where('user_id', $id)->first();
        $tableData = Registration::where('user_id',$id)->simplePaginate(5);
        return view('frontend.history')
                    // ->with('user', $user)
                    ->with('tableData', $tableData);
    }

    public function detail($id)
    {
        $registration = Registration::where('id', $id)->where('user_id', auth()->user()->id)->first();

        return view('frontend.service')->with('registration', $registration);
    }
}
