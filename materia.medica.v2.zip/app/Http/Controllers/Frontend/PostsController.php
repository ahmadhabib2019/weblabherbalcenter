<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\Post;
use App\Models\Menu;
use App\Models\Visitor;
use Illuminate\Http\Request;

class PostsController extends Controller
{
    //artikel
    public function index(Request $request)
    {
        $menu = Menu::where('param', $request->category)->first();

        $title = $menu->title;

        $posts = Post::where('category', $request->category)->orderBy('created_at', 'desc')->simplePaginate(5);
        return view('frontend.article')
            ->with('posts', $posts)
            ->with('title', $title);
    }

    public function show(Request $request)
    {
        $ip = hash('sha512', $request->ip());
        $cek = Visitor::where([['date', today()->format('Y-m-d')],['ip',$ip],['page_id',$request->id],['slug',$request->segment(1)]])->count();
        if ($cek < 1)
        {
            Visitor::create([
                'date' => today(),
                'ip' => $ip,
                'page_id' => $request->id,
                'slug' => $request->segment(1),
                'created_at' => $ip,
            ]);
        }
        // if (isset($request->id)) {
            $postDetail = Post::where('slug', $request->slug)->where('id', $request->id)->first();
        // } else {
        //     $post = Post::where('slug', $request->slug)->first();
        // }
        
        if ($postDetail) {
            $menu = Menu::where('param', $postDetail->category)->first();
            $title = $menu->title;
        } else {
            $title = 'Not found!';
        }
        return view('frontend.article-details')->with('postDetail', $postDetail)->with('title', $title);
    }
}
