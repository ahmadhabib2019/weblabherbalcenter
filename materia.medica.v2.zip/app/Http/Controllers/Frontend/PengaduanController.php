<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Http\Requests\CreatePengaduanRequest;
use App\Repositories\PengaduanRepository;
use Illuminate\Http\Request;

class PengaduanController extends Controller
{
    public function __construct(PengaduanRepository $pengaduanRepo)
    {
        $this->pengaduanRepository = $pengaduanRepo;
    }

    public function index(){
        return view('frontend.pengaduan');
    }

    public function store(CreatePengaduanRequest $request)
    {
        $input = $request->all();
            $destinationPath = public_path('storage/Pengaduan/');
            $Name = $input['file']->getClientOriginalName();
            $input['file']->move($destinationPath, $Name);
            
            $src = 'storage/Pengaduan/' . $Name;
            $input['file'] = $src;

        $pengaduan = $this->pengaduanRepository->create($input);

        return back()->with('info','Pengaduan berhasil dikirim');
    }
}
