<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\Penelitian;
use App\Models\Visitor;
use Illuminate\Http\Request;

class PenelitianController extends Controller
{

    public function index($category){
        $penelitians = Penelitian::where('category',$category)->orderBy('id', 'desc')->simplePaginate(5);
         return view('frontend.penelitian')
            ->with('penelitians', $penelitians)
            ->with('title','Penelitian Tanaman');
    }

    public function show($id, Request $request){
        $ip = hash('sha512', $request->ip());
        $cek = Visitor::where('date', today())->where('ip',$ip)->where('page_id',$request->id)->where('slug',$request->segment(1))->count();
        if ($cek < 1)
        {
            Visitor::create([
                'date' => today(),
                'ip' => $ip,
                'page_id' => $id,
                'slug' => $request->segment(1),
                'created_at' => $ip,
            ]);
        }
        $detailPenelitian = Penelitian::where('id',$id)->first();
         return view('frontend.penelitian')
            ->with('detailPenelitian', $detailPenelitian);
    }
    public function unduh($id){
        $file = Penelitian::where('id',$id)->first();
        $file->download = $file->download+1;
        $file->save();
         return response()->download($file->file);
    }
}
