<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\FormSkm;
use App\Models\Skm;
use App\Models\ViewSkm;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SkmController extends Controller
{

    public function index(){
        $formskm = FormSkm::all();
         return view('frontend.formskm')
            ->with('formskm', $formskm);
    }

    public function formskm($id){
        $detailSkm = FormSkm::where('id',$id)->first();
         return view('frontend.formskm')
            ->with('detailSkm', $detailSkm);
    }
    public function store(Request $request){
        DB::beginTransaction();
        try {
            $input = $request->all();
                    $skm = new Skm();
                    $data_skm = [
                        'user_id'=> $input['user_id'],
                        'service_id'=> $input['service_id'],
                        'q1'=>$input['question'][1],
                        'q2'=>$input['question'][2],
                        'q3'=>$input['question'][3],
                        'q4'=>$input['question'][4],
                        'q5'=>$input['question'][5],
                        'q6'=>$input['question'][6],
                        'q7'=>$input['question'][7],
                        'q8'=>$input['question'][8],
                        'q9'=>$input['question'][9],
                        'q10'=>$input['question'][10],
                        'q11'=>$input['question'][11],
                        'q12'=>$input['question'][12],
                        'q13'=>$input['question'][13],
                        'q14'=>$input['question'][14],
                    ];
                    $skm->create($data_skm);
                    
                    DB::commit();
                    return back()->with('info','Survey telah terkirim, silahkan mengisi survey layanan berikutnya');
            
            }
            catch (\Exception $e) {
                print_r($e);
            }
    }
    public function show(Request $request){
        if(isset($request->tgl)){
            $data = DB::table('viewskm')
            ->select('*')->where('tgl',$request->tgl)->get();
            $skm0 = ViewSkm::whereMonth('tgl',$request->tgl)->where('service_id',1)->first();
            $skm1 = ViewSkm::whereMonth('tgl',$request->tgl)->where('service_id',2)->first();
            $skm2 = ViewSkm::whereMonth('tgl',$request->tgl)->where('service_id',5)->first();
            $skm3 = ViewSkm::whereMonth('tgl',$request->tgl)->where('service_id',6)->first();
            $skm4 = ViewSkm::whereMonth('tgl',$request->tgl)->where('service_id',7)->first();
            $skm5 = ViewSkm::whereMonth('tgl',$request->tgl)->where('service_id',8)->first();
            $skm6 = ViewSkm::whereMonth('tgl',$request->tgl)->where('service_id',10)->first();
            $skm7 = ViewSkm::whereMonth('tgl',$request->tgl)->where('service_id',11)->first();
            $skm8 = ViewSkm::whereMonth('tgl',$request->tgl)->where('service_id',9)->first();
            $skm9 = ViewSkm::whereMonth('tgl',$request->tgl)->where('service_id',12)->first();
            $skm10 = ViewSkm::whereMonth('tgl',$request->tgl)->where('service_id',13)->first();
            $skm11 = ViewSkm::whereMonth('tgl',$request->tgl)->where('service_id',14)->first();
            $skm12 = ViewSkm::whereMonth('tgl',$request->tgl)->where('service_id',15)->first();
            $skm13 = ViewSkm::whereMonth('tgl',$request->tgl)->where('service_id',16)->first();
            $skm14 = ViewSkm::whereMonth('tgl',$request->tgl)->where('service_id',17)->first();
            $skm15 = ViewSkm::whereMonth('tgl',$request->tgl)->where('service_id',18)->first();
        }else{
            $skm0 = ViewSkm::where('tgl',date('y-m-d'))->where('service_id',1)->first();
            $skm1 = ViewSkm::where('tgl',date('y-m-d'))->where('service_id',2)->first();
            $skm2 = ViewSkm::where('tgl',date('y-m-d'))->where('service_id',5)->first();
            $skm3 = ViewSkm::where('tgl',date('y-m-d'))->where('service_id',6)->first();
            $skm4 = ViewSkm::where('tgl',date('y-m-d'))->where('service_id',7)->first();
            $skm5 = ViewSkm::where('tgl',date('y-m-d'))->where('service_id',8)->first();
            $skm6 = ViewSkm::where('tgl',date('y-m-d'))->where('service_id',10)->first();
            $skm7 = ViewSkm::where('tgl',date('y-m-d'))->where('service_id',11)->first();
            $skm8 = ViewSkm::where('tgl',date('y-m-d'))->where('service_id',9)->first();
            $skm9 = ViewSkm::where('tgl',date('y-m-d'))->where('service_id',12)->first();
            $skm10 = ViewSkm::where('tgl',date('y-m-d'))->where('service_id',13)->first();
            $skm11 = ViewSkm::where('tgl',date('y-m-d'))->where('service_id',14)->first();
            $skm12 = ViewSkm::where('tgl',date('y-m-d'))->where('service_id',15)->first();
            $skm13 = ViewSkm::where('tgl',date('y-m-d'))->where('service_id',16)->first();
            $skm14 = ViewSkm::where('tgl',date('y-m-d'))->where('service_id',17)->first();
            $skm15 = ViewSkm::where('tgl',date('y-m-d'))->where('service_id',18)->first();
            $data = DB::table('viewskm')
            ->select('*')->where('tgl',date('y-m-d'))->orderBy('service_id')->get()->toArray();
        }

        if($skm0 == null){
            $skm0 = 0;
        }else{
            $skm0 = $skm0->totalakhir;
        }
        if($skm1 == null){
            $skm1 = 0;
        }else{
            $skm1 = $skm1->totalakhir;
        }
        if($skm2 == null){
            $skm2 = 0;
        }else{
            $skm2 = $skm2->totalakhir;
        }
        if($skm3 == null){
            $skm3 = 0;
        }else{
            $skm3 = $skm3->totalakhir;
        }
        if($skm4 == null){
            $skm4 = 0;
        }else{
            $skm4 = $skm4->totalakhir;
        }
        if($skm5 == null){
            $skm5 = 0;
        }else{
            $skm5 = $skm5->totalakhir;
        }
        if($skm6 == null){
            $skm6 = 0;
        }else{
            $skm6 = $skm6->totalakhir;
        }
        if($skm7 == null){
            $skm7 = 0;
        }else{
            $skm7 = $skm7->totalakhir;
        }
        if($skm8 == null){
            $skm8 = 0;
        }else{
            $skm8 = $skm8->totalakhir;
        }
        if($skm9 == null){
            $skm9 = 0;
        }else{
            $skm9 = $skm9->totalakhir;
        }
        if($skm10 == null){
            $skm10 = 0;
        }else{
            $skm10 = $skm10->totalakhir;
        }
        if($skm11 == null){
            $skm11 = 0;
        }else{
            $skm11 = $skm11->totalakhir;
        }
        if($skm12 == null){
            $skm12 = 0;
        }else{
            $skm12 = $skm12->totalakhir;
        }
        if($skm13 == null){
            $skm13 = 0;
        }else{
            $skm13 = $skm13->totalakhir;
        }
        if($skm14 == null){
            $skm14 = 0;
        }else{
            $skm14 = $skm14->totalakhir;
        }
        if($skm15 == null){
            $skm15 = 0;
        }else{
            $skm15 = $skm15->totalakhir;
        }

        return view('frontend.formskm',compact('data','skm0','skm1','skm2','skm3','skm4','skm5','skm6','skm7','skm8','skm9','skm10','skm11','skm12','skm13','skm14','skm15'));
    }
}
