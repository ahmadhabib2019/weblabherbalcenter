<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\CreateTelemedisinRequest;
use App\Repositories\TelemedisinRepository;
use App\Models\Telemedisin;
use Auth;

class TelemedisinController extends Controller
{
    public function __construct(TelemedisinRepository $telemedisinRepo)
    {
        $this->telemedisinRepository = $telemedisinRepo;
    }
    public function index(){
        $tele = Telemedisin::paginate(20);

         return view('frontend.telemedisin')->with('tele',$tele);
    }

    public function show($id){
        $telemedisin = Telemedisin::where('id', $id)->get();
        return view('frontend.telemedisin')->with('telemedisin',$telemedisin);
   }

    public function store(Request $request){
        // dd('tes');
        $input = $request->all();
        if(is_null(Auth::user())){
            return redirect('login');
        }else{
            $input['user_id'] = Auth::user()->id;
        }
        $telemedisin = $this->telemedisinRepository->create($input);

        return back()->with('info','Pertanyaan Telah Terkirim..');
    }
}
