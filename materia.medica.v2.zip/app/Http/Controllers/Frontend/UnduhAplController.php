<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class UnduhAplController extends Controller
{
    public function unduh(){
        $file = public_path(). "/frontend/apl/APLIKASI_STATPLANET.rar";
        return response()->download($file);
    }
}