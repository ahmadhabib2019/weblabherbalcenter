<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\Service;
use App\Models\Produk;
use App\Models\ProdukImage;
use App\Models\ProdukOrder;
use App\Models\ProdukOrderDetail;
use App\Models\FormRegistration;
use App\Models\FormRegistrationContent;
use App\Models\Question;
use App\Models\Registration;
use App\Models\RegistrationValue;
use Illuminate\Http\Request;
use App\Repositories\ProdukOrderRepository;
use Illuminate\Support\Facades\DB;
use Flash;
use Illuminate\Support\Facades\Mail;

class ServiceController extends Controller
{
    private $produkOrderRepository;

    public function __construct(ProdukOrderRepository $produkOrderRepo)
    {
        $this->produkOrderRepository = $produkOrderRepo;
    }

    public function index(Request $request){
        if(isset($request->option)){
            $service = Service::where('slug', $request->category)->where('category', $request->option)->first();
        }else{
            $service = Service::where('slug', $request->category)->first();
        }

        if ($service != null) {
            return view('frontend.service')->with('service', $service);
        } else {
            return redirect(route('welcome'));
        }
    }

    public function register(Request $request)
    {
        if(isset($request->option)){
            $service = Service::where([
                ['slug', $request->slug],
                ['category', $request->option]
                ])->first();
        }else{
            $service = Service::where([
                ['slug', $request->slug],
                ['id', $request->id]
            ])->first();
        }

        //kondisi option jika layanan wisata edukasi toga / workshop
        $options = null;
        switch ($service->id) {
            case 1:
                $options = ['Individu', 'Kelompok'];
                break;
            default:
                $options = null;
                break;
        }
        if ($options != null) {
            return view('frontend.service-kategori')->with('service', $service)->with('options', $options);
        } else {
            return redirect()->route('frontend.service.registerForm', [$request->id]);
        }
    }

    public function showRegistrationForm(Request $request)
    {
        if(isset($request->option)){
            $formRegistration = FormRegistration::where('service_id', $request->id)->where('options', $request->option)->first();
        }else{
            $formRegistration = FormRegistration::where('service_id', $request->id)->orderBy('id','DESC')->first();
            
        }
        if (!empty($formRegistration)) {
            return view('frontend.service-form-register')->with('formRegistration', $formRegistration);
        } else {
            return redirect(route('welcome'));
        }
    }

    public function storeRegistrationForm(Request $request){

        $result = DB::transaction(function () use ($request){
            $input = $request->all();
            $registration = new Registration();
            $regis_data = [
                'user_id'=>$request->user_id,
                'services_id'=>$request->id,
                'options'=>$request->options
            ];
            $regis = $registration->create($regis_data);

            if(isset($request->files)){
                foreach($request->files as $data){
                    foreach($data as $ke =>$a){
                        if($request->options == null){
                            $request->options = 'FilePengunjung';
                        }
                        $destinationPath = public_path('storage/'.$request->options.'/');
                        $fileName = (date('mdhs')+1).$a->getClientOriginalName();
                        $a->move($destinationPath, $fileName);
                        $srcfile = 'storage/'.$request->options.'/' . $fileName;

                        $input['question'][$ke] = $srcfile;
                    }
                }
            }
            foreach ($input['question'] as $key => $value) {
                    $regis_value = new RegistrationValue();
                    $data_value  = is_array($value)? json_encode($value) : $value;
                    $regis_value_data = [
                        'registration_id'=> $regis->id,
                        'question_id'=> $key,
                        'values'=>$data_value
                    ];
                    $regis_value->create($regis_value_data);
            }
            // sending email
            $details = Registration::where('id',$regis->id)->first();           
            Mail::to($details->services->contact_persons->email)->send(new \App\Mail\ServiceMail($details));
            return $regis;
        });

        return redirect(route('service.registerForm.success',$result->id))->with('info','Pengajuan Layanan Telah Berhasil!! Mohon konfirmasi ke nomor yang tertera');
    }
    public function storeRegistrationFormOpenClass(Request $request){

        $result = DB::transaction(function () use ($request){

            $registration = new Registration();
            $regis_data = [
                'user_id'=>$request->userId,
                'services_id'=>$request->serviceId,
                'options'=>'Open Class'
            ];
            $regis = $registration->create($regis_data);
            return $regis;
        });

        return redirect(route('service.registerForm.success',$result->id))->with('info','Pengajuan Layanan Telah Berhasil!! Mohon konfirmasi ke nomor yang tertera');

    }

    public function registrationFormSuccess($registration_id){
        $registration = Registration::where('id',$registration_id)->where('user_id',auth()->user()->id)->first();

        return view('frontend.service')->with('registration', $registration);
    }

    public function unduh($id){
        $file = Question::where('id',$id)->first();
        if(is_null($file->option)){
            return back();
        }

        return response()->download($file->option);
    }

    public function katalogList(Request $request){
        if($request->slug == 'herbalmart'){
            $produk = Produk::where('kategori_id','<',4)->orderBy('nama','asc')->paginate(18);
        }else{
            $produk = Produk::where('kategori_id',4)->orderBy('nama','asc')->paginate(18);
        }

        return view('frontend.katalog')->with('produk', $produk);
    }

    public function katalogDetail($id){
        $produks = Produk::where('id',$id)->first();
        $images  = ProdukImage::where('produk_id',$id)->get();
        return view('frontend.katalog-detail')->with('produks', $produks)->with('images', $images);
    }

    public function formHerbalmart(Request $request){
        if($request->kategori == 'herbalmart'){

            $produks1 = Produk::where('kategori_id','=',1)->get();
            $produks2 = Produk::where('kategori_id','=',2)->get();
            $produks3 = Produk::where('kategori_id','=',3)->get();

            return view('frontend.katalog-form')
            ->with('produk1', $produks1)
            ->with('produk2', $produks2)
            ->with('produk3', $produks3);

        } elseif($request->kategori == 'bibit-tanaman-obat') {

            $produks = Produk::where('kategori_id','=',4)->get();

            return view('frontend.katalog-form')
            ->with('produk', $produks);
        }

    }

    public function herbalmartStore(Request $request){
        $input = $request->all();
        if(isset($input['kategori'])){
            $kode_trans = date('ymdhis');
            $input['kode_trans'] = $kode_trans+1;
            DB::beginTransaction();
                $produkOrder = $this->produkOrderRepository->create($input);

                foreach($input['produk_id'] as $key => $value){
                    $produk_order = new ProdukOrderDetail();
                    $produk = Produk::where('id',$input['produk_id'][$key])->first();
                    $produk_order->order_id = $produkOrder->id;
                    $produk_order->produk_id = $produk->id;
                    $produk_order->qty = $input['qty'][$key];
                    $produk_order->kategori_id = $input['kategori'][$key];
                    $produk_order->total = $input['subtotal'][$key];
                    $produk_order->save();

                    $new_stok = $produk->stok - $input['qty'][$key];

                    if($new_stok < 0){
                        Flash::error('Produk Kosong');
                        DB::rollBack();
                        return back();
                    }elseif($new_stok >=0){
                        $produk->stok = $new_stok;
                        $produk->save();

                        DB::commit();
                    }
                }
                return redirect(route('herbalmart.detail.order',[$input['url'],$produkOrder->id]))->with('info','Produk Berhasil di pesan!!  Silahkan konfirmasi melalui nomor yang tertera');


        } else {
            $input1 = $request->all();
            $kode_trans1 = date('ymdhi')+1;
            $input1['kode_trans'] = $kode_trans1+1;
            DB::beginTransaction();
            $produkOrder1 = $this->produkOrderRepository->create($input1);

            foreach($input1['produk_id'] as $key1 => $value1){
                    $produk_order1 = new ProdukOrderDetail();
                    $produk1 = Produk::where('id',$input1['produk_id'][$key1])->first();

                    $produk_order1->order_id = $produkOrder1->id;
                    $produk_order1->produk_id = $produk1->id;
                    $produk_order1->qty = $input1['qty'][$key1];
                    $produk_order1->kategori_id = 4;
                    $produk_order1->total = $input1['subtotal'][$key1];
                    $produk_order1->save();

                    $new_stok1 = $produk1->stok - $input1['qty'][$key1];

                    if($new_stok1 < 0){
                        Flash::error('Produk Kosong');
                        DB::rollBack();
                        return back();
                    }elseif($new_stok1 >=0){
                        $produk1->stok = $new_stok1;
                        $produk1->save();
                        DB::commit();

                    }
                }
                return redirect(route('herbalmart.detail.order',[$input['url'],$produkOrder1->id]))->with('info','Produk Berhasil di pesan!!  Silahkan konfirmasi melalui nomor yang tertera');
        }
    }

    public function herbalmartDetailOrder(Request $request){

        $produk_order = ProdukOrder::where('id',$request->id)->where('user_id',auth()->user()->id)->first();
        $service = Service::where('slug',$request->url)->first();//contact person

        return view('frontend.katalog')->with('produkOrder',$produk_order)->with('service',$service);
    }

    //Fungsi store mencari harga
    public function search($id){

        $produk = Produk::where('id',$id)->get();

        return $produk;
    }
}
