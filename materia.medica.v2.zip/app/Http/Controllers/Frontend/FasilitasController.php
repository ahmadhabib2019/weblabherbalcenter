<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\Fasilitas;
use Illuminate\Http\Request;

class FasilitasController extends Controller
{

    public function show($slug){
        $fasilitas = Fasilitas::where('slug',$slug)->first();
        return view('frontend.article')
            ->with('fasilitas', $fasilitas);
    }
}
