<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Http\Requests\CreateSaranKritikRequest;
use App\Repositories\SaranKritikRepository;
use Illuminate\Http\Request;
use App\Models\SaranKritik;

class SaranKritikController extends Controller
{
    public function __construct(SaranKritikRepository $saranKritikRepo)
    {
        $this->saranKritikRepository = $saranKritikRepo;
    }

    public function index(){
        return view('frontend.sarankritik');
    }

    public function store(CreateSaranKritikRequest $request)
    {
        $input = $request->all();

        $saranKritik = $this->saranKritikRepository->create($input);

        return back()->with('info','Saran Kritik berhasil terkirim..');
    }

    public function show(){
        $sarankritik = SaranKritik::orderBy('created_at','desc')->get();
        return view('frontend.sarankritik')->with('sarankritik',$sarankritik);
    }
}
