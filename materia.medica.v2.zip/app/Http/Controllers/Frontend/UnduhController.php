<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\Unduh;
use App\Models\Visitor;
use Illuminate\Http\Request;

class UnduhController extends Controller
{

    public function index($category){
        $unduh = Unduh::where('category',$category)->orderBy('year', 'desc')->Paginate(5);
        
         return view('frontend.unduh')
            ->with('unduh', $unduh);
    }

    public function show($id, Request $request){
        $ip = hash('sha512', $request->ip());
        $cek = Visitor::where('date', today())->where('ip',$ip)->where('page_id',$request->id)->where('slug',$request->segment(1))->count();
        if ($cek < 1)
        {
            Visitor::create([
                'date' => today(),
                'ip' => $ip,
                'page_id' => $request->id,
                'slug' => $request->segment(1),
                'created_at' => $ip,
            ]);
        }
        $unduhDetail = Unduh::where('id',$id)->first();
         return view('frontend.unduh')
            ->with('unduhDetail', $unduhDetail);
    }
    public function unduh($id){
        $file = Unduh::where('id',$id)->first();
        $file->download = $file->download+1;
        $file->save();
         return response()->download($file->file);
    }
}
