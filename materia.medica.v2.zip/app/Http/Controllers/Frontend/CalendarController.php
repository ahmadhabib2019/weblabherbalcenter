<?php

namespace App\Http\Controllers\Frontend;

use Acaronlex\LaravelCalendar\Calendar;
use App\Http\Controllers\Controller;
use App\Models\CalendarEvent;
use Illuminate\Http\Request;

class CalendarController extends Controller
{
    public function __invoke()
    {
        $calendar_events = CalendarEvent::all();
        $events = [];
        foreach ($calendar_events as $event) {
            $color = $event->peserta >= 100 ? 'red' : 'green';
            $events[] = \Calendar::event(
                $event->title, //event title
                $event->full_day, //full day event?
                $event->start, //start time (you can also use Carbon instead of DateTime)
                $event->finish, //end time (you can also use Carbon instead of DateTime)
                $event->id, //optionally, you can specify an event ID
                [
                    'backgroundColor'=> $color
                    //any other full-calendar supported parameters
                ]
            );
        }

        $calendar = new Calendar();
        $calendar->addEvents($events)
            ->setOptions([
                'themeSystem' => 'bootstrap',
                'locale' => 'ID',
                'firstDay' => 1,
                'displayEventTime' => true,
                'selectable' => true,
                'height' => 650,
                'initialView' => 'dayGridMonth',
                'headerToolbar' => [
                    'end' => 'today prev,next listYear'
                ],
                'googleCalendarApiKey' => 'AIzaSyAO2F67gZDh4XZ-Ty0q8UB9hhldQxH8jug',
                'eventSources' => [
                    'googleCalendarId' => 'id.indonesian#holiday@group.v.calendar.google.com',
                    'color' => 'blue'
                ]

            ]);
        $calendar->setId('1');
        $calendar->setCallbacks([
            'eventClick' => 'function(info) {
                alert(\'Event: \' + info.event.title);
            }',
        ]);

        return view('frontend.calendar', compact('calendar'));
    }
}
