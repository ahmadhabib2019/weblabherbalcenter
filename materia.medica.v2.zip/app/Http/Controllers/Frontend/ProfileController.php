<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Requests\UpdateUserRequest;
use Laravolt\Indonesia\Models\Province;
use App\Repositories\UserRepository;
use App\Http\Controllers\Controller;
use Auth;
use Illuminate\Support\Facades\DB;
use Laravolt\Indonesia\Models\City;
use Illuminate\Http\Request;
class ProfileController extends Controller
{
    private $userRepository;
    public function __construct(UserRepository $userRepo)
    {
        $this->userRepository = $userRepo;
    }

    public function edit()
    {
        $id = Auth::user()->id;
        $user = $this->userRepository->find($id);
        $list_provinsi = Province::pluck('name', 'id');
        $list_kota = City::where('province_id', $user->userData->provinsi)->pluck('name', 'id');
        $pendidikan = ['sd' => 'SD', 'smp' => 'SLTP/SMP', 'sma' => 'SLTA/SMA/SMK', 'diploma' => 'D1/D2/D3', 's1' => 'S1', 's2/3' => 'S2', 's2/3' => 'S2/S3'];
        $pekerjaan = ['sipil' => 'PNS/TNI/POLRI', 'swasta' => 'Pegawai Swasta', 'wiraswasta' => 'Wiraswasta/Wirausaha', 'pelajar' => 'Pelajar/Mahasiswa', 'guru' => 'Guru/Dosen', 'lainya..'];
        $gender = ['L' => 'Laki-laki', 'P' => 'Perempuan'];
        return view('frontend.profile')
                    ->with('user', $user)
                    ->with('list_provinsi', $list_provinsi)
                    ->with('list_kota', $list_kota)
                    ->with('pendidikan',$pendidikan)
                    ->with('pekerjaan',$pekerjaan)
                    ->with('gender',$gender);
    }

    public function update($id, UpdateUserRequest $request)
    {
        $user = $this->userRepository->find($id);
        $data = $request->filled('password') ? $request->all() : $request->except('password');
        $user = $this->userRepository->update($data, $id);
        // DB::table('model_has_roles')->where('model_id', $id)->delete();
        // $user->assignRole($request->input('roles'));

        $user->userData()->update([
            'nik' => $request->nik,
            'nip' => $request->nip,
            'gender' => $request->gender,
            'tempat_lahir' => $request->tempat_lahir,
            'tgl_lahir' => $request->tgl_lahir,
            'alamat' => $request->alamat,
            'provinsi' => $request->provinsi,
            'kota' => $request->kota,
            'phone' => $request->phone,
            'pendidikan_akhir' => $request->pendidikan_akhir,
            'pekerjaan' => $request->pekerjaan,
            'jurusan' => $request->jurusan,
            'fakultas' => $request->fakultas,
            'instansi' => $request->instansi,
            'alamat_instansi' => $request->alamat_instansi,
        ]);

        return back()->with('status', 'Data berhasil diperbarui');   ;
    }

    public function get_city(Request $request){
        $city_id = $request->city_id;
         $cities = City::where('province_id', $city_id)
            ->pluck('name', 'id');
        return response()->json($cities);
    }
}
