<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\Service;
use App\Models\FormRegistration;
use Illuminate\Http\Request;

class WorkshopController extends Controller
{
    
    public function categoryIndex(){
        $service = Service::whereNotNull('category')->get();
        return view('frontend.workshop-kategori')->with('service', $service);;
    }


    public function index(){
        $workshop = FormRegistration::where('options', 'Open Class')->get();
        if (!empty($workshop)) {
            return view('frontend.workshop-open')->with('workshop', $workshop);
        } else {
            return redirect(route('welcome'));
        }
    }

    public function show($id){
        $detailworkshop = FormRegistration::where('id',$id)->orderBy('created_at','desc')->first();
         return view('frontend.workshop-open')
            ->with('detailworkshop', $detailworkshop);
    }

    public function showRegistrationForm(Request $request)
    {
        
        $formRegistration = FormRegistration::where('service_id', $request->id)->first();
        if (!empty($formRegistration)) {
            return view('frontend.service-form-register')->with('formRegistration', $formRegistration);
        } else {
            return redirect(route('welcome'));
        }
    }
}
