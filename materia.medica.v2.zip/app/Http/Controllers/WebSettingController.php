<?php

namespace App\Http\Controllers;

use App\Http\Requests\CreateWebSettingRequest;
use App\Http\Requests\UpdateWebSettingRequest;
use App\Repositories\WebSettingRepository;
use App\Http\Controllers\AppBaseController;
use Illuminate\Http\Request;
use Flash;
use Response;

class WebSettingController extends AppBaseController
{
    /** @var  WebSettingRepository */
    private $webSettingRepository;
    protected $settingItems;

    public function __construct(WebSettingRepository $webSettingRepo)
    {
        $this->webSettingRepository = $webSettingRepo;
        $this->middleware('permission:admin-list|admin-create|admin-edit|admin-delete', ['only' => ['index', 'show']]);
        $this->middleware('permission:admin-create', ['only' => ['create', 'store']]);
        $this->middleware('permission:admin-edit', ['only' => ['edit', 'update']]);
        $this->middleware('permission:admin-delete', ['only' => ['destroy']]);
        $this->settingItems = [
                'alamat_1' => 'Alamat',
                'alamat_2' => 'Alamat',
                'alamat_3' => 'Alamat',
                'jadwal_1' => 'Senin - Kamis',
                'jadwal_2' => 'Jumat',
                'phone'     => 'Phone',
                'email'     => 'Email',
                'facebook'     => 'Facebook',
                'instagram'     => 'Instagram',
                'youtube'     => 'Youtube',
        ];
    }

    /**
     * Display a listing of the WebSetting.
     *
     * @param Request $request
     *
     * @return Response
     */
    public function index(Request $request)
    {
        $webSettings = $this->webSettingRepository->all();

        return view('web_settings.index')
            ->with('webSettings', $webSettings);
    }

    /**
     * Show the form for creating a new WebSetting.
     *
     * @return Response
     */
    public function create()
    {
        
        return view('web_settings.create')->with('settingItems',$this->settingItems);
    }

    /**
     * Store a newly created WebSetting in storage.
     *
     * @param CreateWebSettingRequest $request
     *
     * @return Response
     */
    public function store(CreateWebSettingRequest $request)
    {
        $input = $request->all();

        $webSetting = $this->webSettingRepository->create($input);

        Flash::success('Web Setting saved successfully.');

        return redirect(route('webSettings.index'));
    }

    /**
     * Display the specified WebSetting.
     *
     * @param int $id
     *
     * @return Response
     */
    public function show($id)
    {
        $webSetting = $this->webSettingRepository->find($id);

        if (empty($webSetting)) {
            Flash::error('Web Setting not found');

            return redirect(route('webSettings.index'));
        }

        return view('web_settings.show')->with('webSetting', $webSetting);
    }

    /**
     * Show the form for editing the specified WebSetting.
     *
     * @param int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        $webSetting = $this->webSettingRepository->find($id);
        if (empty($webSetting)) {
            Flash::error('Web Setting not found');

            return redirect(route('webSettings.index'));
        }

        return view('web_settings.edit')->with(['webSetting'=>$webSetting, 'settingItems'=>$this->settingItems]);
    }

    /**
     * Update the specified WebSetting in storage.
     *
     * @param int $id
     * @param UpdateWebSettingRequest $request
     *
     * @return Response
     */
    public function update($id, UpdateWebSettingRequest $request)
    {
        $webSetting = $this->webSettingRepository->find($id);

        if (empty($webSetting)) {
            Flash::error('Web Setting not found');

            return redirect(route('webSettings.index'));
        }

        $webSetting = $this->webSettingRepository->update($request->all(), $id);

        Flash::success('Web Setting updated successfully.');

        return redirect(route('webSettings.index'));
    }

    /**
     * Remove the specified WebSetting from storage.
     *
     * @param int $id
     *
     * @throws \Exception
     *
     * @return Response
     */
    public function destroy($id)
    {
        $webSetting = $this->webSettingRepository->find($id);

        if (empty($webSetting)) {
            Flash::error('Web Setting not found');

            return redirect(route('webSettings.index'));
        }

        $this->webSettingRepository->delete($id);

        Flash::success('Web Setting deleted successfully.');

        return redirect(route('webSettings.index'));
    }
}
