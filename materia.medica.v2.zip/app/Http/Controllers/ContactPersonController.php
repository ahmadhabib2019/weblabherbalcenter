<?php

namespace App\Http\Controllers;

use App\DataTables\ContactPersonDataTable;
use App\Http\Requests;
use App\Http\Requests\CreateContactPersonRequest;
use App\Http\Requests\UpdateContactPersonRequest;
use App\Repositories\ContactPersonRepository;
use Flash;
use App\Http\Controllers\AppBaseController;
use Response;

class ContactPersonController extends AppBaseController
{
    /** @var  ContactPersonRepository */
    private $contactPersonRepository;

    public function __construct(ContactPersonRepository $contactPersonRepo)
    {
        $this->contactPersonRepository = $contactPersonRepo;
    }

    /**
     * Display a listing of the ContactPerson.
     *
     * @param ContactPersonDataTable $contactPersonDataTable
     * @return Response
     */
    public function index(ContactPersonDataTable $contactPersonDataTable)
    {
        return $contactPersonDataTable->render('contact_people.index');
    }

    /**
     * Show the form for creating a new ContactPerson.
     *
     * @return Response
     */
    public function create()
    {
        return view('contact_people.create');
    }

    /**
     * Store a newly created ContactPerson in storage.
     *
     * @param CreateContactPersonRequest $request
     *
     * @return Response
     */
    public function store(CreateContactPersonRequest $request)
    {
        $input = $request->all();

        $contactPerson = $this->contactPersonRepository->create($input);

        Flash::success('Contact Person saved successfully.');

        return redirect(route('contact_person.index'));
    }

    /**
     * Display the specified ContactPerson.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function show($id)
    {
        $contactPerson = $this->contactPersonRepository->find($id);

        if (empty($contactPerson)) {
            Flash::error('Contact Person not found');

            return redirect(route('contact_person.index'));
        }

        return view('contact_people.show')->with('contactPerson', $contactPerson);
    }

    /**
     * Show the form for editing the specified ContactPerson.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        $contactPerson = $this->contactPersonRepository->find($id);

        if (empty($contactPerson)) {
            Flash::error('Contact Person not found');

            return redirect(route('contact_person.index'));
        }

        return view('contact_people.edit')->with('contactPerson', $contactPerson);
    }

    /**
     * Update the specified ContactPerson in storage.
     *
     * @param  int              $id
     * @param UpdateContactPersonRequest $request
     *
     * @return Response
     */
    public function update($id, UpdateContactPersonRequest $request)
    {
        $contactPerson = $this->contactPersonRepository->find($id);

        if (empty($contactPerson)) {
            Flash::error('Contact Person not found');

            return redirect(route('contact_person.index'));
        }

        $contactPerson = $this->contactPersonRepository->update($request->all(), $id);

        Flash::success('Contact Person updated successfully.');

        return redirect(route('contact_person.index'));
    }

    /**
     * Remove the specified ContactPerson from storage.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function destroy($id)
    {
        $contactPerson = $this->contactPersonRepository->find($id);

        if (empty($contactPerson)) {
            Flash::error('Contact Person not found');

            return redirect(route('contact_person.index'));
        }

        $this->contactPersonRepository->delete($id);

        Flash::success('Contact Person deleted successfully.');

        return redirect(route('contact_person.index'));
    }
}
