<?php

namespace App\Http\Controllers;

use App\DataTables\FormRegistrationContentDataTable;
use App\Http\Requests;
use App\Http\Requests\CreateFormRegistrationContentRequest;
use App\Http\Requests\UpdateFormRegistrationContentRequest;
use App\Repositories\FormRegistrationContentRepository;
use Flash;
use App\Http\Controllers\AppBaseController;
use Response;
use App\Models\Question;
use App\Models\FormRegistration;
use App\Models\FormRegistrationContent;
use App\Models\Service;
use Illuminate\Support\Facades\DB;
use Str;
use File;

class FormRegistrationContentController extends AppBaseController
{
    /** @var  FormRegistrationContentRepository */
    private $formRegistrationContentRepository;

    public function __construct(FormRegistrationContentRepository $formRegistrationContentRepo)
    {
        $this->option = [
            'Individu' => 'Individu', 'Kelompok' => 'Kelompok','Open Class'=>'Open Class'
        ];
        $this->formRegistrationContentRepository = $formRegistrationContentRepo;
    }

    /**
     * Display a listing of the FormRegistrationContent.
     *
     * @param FormRegistrationContentDataTable $formRegistrationContentDataTable
     * @return Response
     */
    public function index(FormRegistrationContentDataTable $formRegistrationContentDataTable)
    {
        return $formRegistrationContentDataTable->render('form_registration_contents.index');
    }

    /**
     * Show the form for creating a new FormRegistrationContent.
     *
     * @return Response
     */
    public function create()
    {

        $services = Service::all();
        $question = Question::orderBy('question')->pluck('question', 'id');
        return view('form_registration_contents.create')
            ->with('option', $this->option)
            ->with('question', $question)
            ->with('services', $services);
    }

    /**
     * Store a newly created FormRegistrationContent in storage.
     *
     * @param CreateFormRegistrationContentRequest $request
     *
     * @return Response
     */
    public function store(CreateFormRegistrationContentRequest $request)
    {
        $input = $request->all();
        if(isset($input['images'])){
            $imageName = $input['images']->getClientOriginalName();
            $destinationPathImg = public_path('storage/workshopOpenClass/');
            $input['images']->move($destinationPathImg, $imageName);
            $srcimage = 'storage/workshopOpenClass/' . $imageName;
        }else{
            $srcimage = null;
        }if($input['service_id'] == 22){
            $input['options'] = "Open Class";
        }
        $formRegistration = new FormRegistration();
        $data_form_registration = [
            'service_id' => $input['service_id'],
            'name' => $input['name'],
            'options' => $input['options'],
            'description' => $input['description'],
            'date' => $input['date'],
            'jam' => $input['jam'],
            'price' => $input['price'],
            'image' => $srcimage,
        ];
        $data_form = $formRegistration->create($data_form_registration);
        foreach ($input['question_id'] as $question_id) {
            $data_content = [
                'form_registration_id' => $data_form->id,
                'question_id' => $question_id,
            ];
            $formRegistrationContent = $this->formRegistrationContentRepository->create($data_content);
        }

        Flash::success('Form Registration Content saved successfully.');

        return redirect(route('formRegistrationContents.index'));
    }

    /**
     * Display the specified FormRegistrationContent.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function show($id)
    {
        $formRegistrationContent = FormRegistration::find($id);
        // $formRegistrationContent = $this->formRegistrationContentRepository->find($id);

        if (empty($formRegistrationContent)) {
            Flash::error('Form Registration Content not found');

            return redirect(route('formRegistrationContents.index'));
        }

        return view('form_registration_contents.show')->with('formRegistrationContent', $formRegistrationContent);
    }

    /**
     * Show the form for editing the specified FormRegistrationContent.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        $formRegistrationContent = FormRegistration::find($id);
        $question = Question::orderBy('question')->pluck('question', 'id');
        $services = Service::all();
        if (empty($formRegistrationContent)) {
            Flash::error('Form Registration Content not found');

            return redirect(route('formRegistrationContents.index'));
        }

        return view('form_registration_contents.edit')
            ->with('formRegistrationContent', $formRegistrationContent)
            ->with('option', $this->option)
            ->with('services', $services)
            ->with('question', $question);
    }

    /**
     * Update the specified FormRegistrationContent in storage.
     *
     * @param  int              $id
     * @param UpdateFormRegistrationContentRequest $request
     *
     * @return Response
     */
    public function update($id, UpdateFormRegistrationContentRequest $request)
    {

        DB::transaction(function () use ($id, $request) {
            $input = $request->all();
            $formRegistration = FormRegistration::find($id);
            $formRegistrationContent = $formRegistration->formRegistrationContents;
            if (empty($formRegistration)) {
                Flash::error('Form Registration  not found');

                return redirect(route('formRegistrationContents.index'));
            }
            if( isset($input['images'])){
                $imageName = $input['images']->getClientOriginalName();
                $destinationPathImg = public_path('storage/workshopOpenClass/');
                $input['images']->move($destinationPathImg, $imageName);
                $srcimage = 'storage/workshopOpenClass/' . $imageName;
                File::delete($input['image']);
            }else{
                $srcimage = $input['image'];
            }

            $data_form_registration = [
                'name' => $request->name,
                'options' => $request->options,
                'service_id' => $request->service_id,
                'options' => $request->options,
                'description' => $request->description,
                'date' => $request->date,
                'jam' => $request->jam,
                'price' => $request->price,
                'image' => $srcimage,
            ];
            $formRegistration->update($data_form_registration);
            $questions = [];
            foreach ($formRegistrationContent->toArray() as $key => $value) {
                $questions[$value['id']] = "$value[question_id]";
            }
            if (isset($input['old_question_id'])) {
                $data = array_diff_assoc($questions, $input['old_question_id']);
                if (!empty($data)) {
                    $this->formRegistrationContentRepository->deleteQuestions($data);
                }
            }
            if ($request->has('question_id')) {
                foreach ($input['question_id'] as $question_id) {
                    $data_content = [
                        'form_registration_id' => $id,
                        'question_id' => $question_id,
                    ];
                    $formRegistrationContent = $this->formRegistrationContentRepository->create($data_content);
                }
            }
        });
        Flash::success('Form Registration Content updated successfully.');

        return redirect(route('formRegistrationContents.edit', $id));
    }

    /**
     * Remove the specified FormRegistrationContent from storage.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function destroy($id)
    {
        $formRegistration = FormRegistration::find($id);
        $formRegistrationContent = $formRegistration->formRegistrationContents;

        if (empty($formRegistration)) {
            Flash::error('Form Registration Content not found');

            return redirect(route('formRegistrationContents.index'));
        }
        foreach ($formRegistrationContent as $item) {
            $item->delete();
        }
        $formRegistration->delete();
        Flash::success('Form Registration Content deleted successfully.');

        return redirect(route('formRegistrationContents.index'));
    }
}
