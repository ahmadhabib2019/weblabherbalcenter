<?php

namespace App\Http\Controllers;

use App\Http\Requests\UpdateUserRequest;
use App\Repositories\UserRepository;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Laracasts\Flash\Flash;
use Spatie\Permission\Models\Permission;

class HomeController extends Controller
{
     /** @var  UserRepository */
    private $userRepository;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(UserRepository $userRepo)
    {
        $this->middleware('auth');
        $this->userRepository = $userRepo;
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('home');
    }

    public function profile_update($id, UpdateUserRequest $request)
    {

        $user = $this->userRepository->find($id);
        if (empty($user)) {
            Flash::error('User not found');

            return redirect(route('profile'));
        }
        $data = $request->filled('password') ? $request->all() : $request->except('password');

        if($request->hasFile('image')){
            $filename = $data['username'].'.'.$request->image->extension();
            $request->image->storeAs('images',$filename,'profile');
            $data['image']='storage/profile/images/'.$filename;
        }
        $user = $this->userRepository->update($data, $id);

        Flash::success('User updated successfully.');

        return redirect(route('profile'));

    }

}
