<?php

namespace App\Http\Controllers;

use App\DataTables\ProdukKategoriDataTable;
use App\Http\Requests;
use App\Http\Requests\CreateProdukKategoriRequest;
use App\Http\Requests\UpdateProdukKategoriRequest;
use App\Repositories\ProdukKategoriRepository;
use Flash;
use App\Http\Controllers\AppBaseController;
use Response;

class ProdukKategoriController extends AppBaseController
{
    /** @var  ProdukKategoriRepository */
    private $produkKategoriRepository;

    public function __construct(ProdukKategoriRepository $produkKategoriRepo)
    {
        $this->produkKategoriRepository = $produkKategoriRepo;
    }

    /**
     * Display a listing of the ProdukKategori.
     *
     * @param ProdukKategoriDataTable $produkKategoriDataTable
     * @return Response
     */
    public function index(ProdukKategoriDataTable $produkKategoriDataTable)
    {
        return $produkKategoriDataTable->render('produk_kategoris.index');
    }

    /**
     * Show the form for creating a new ProdukKategori.
     *
     * @return Response
     */
    public function create()
    {
        return view('produk_kategoris.create');
    }

    /**
     * Store a newly created ProdukKategori in storage.
     *
     * @param CreateProdukKategoriRequest $request
     *
     * @return Response
     */
    public function store(CreateProdukKategoriRequest $request)
    {
        $input = $request->all();

        $produkKategori = $this->produkKategoriRepository->create($input);

        Flash::success('Produk Kategori saved successfully.');

        return redirect(route('produkKategoris.index'));
    }

    /**
     * Display the specified ProdukKategori.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function show($id)
    {
        $produkKategori = $this->produkKategoriRepository->find($id);

        if (empty($produkKategori)) {
            Flash::error('Produk Kategori not found');

            return redirect(route('produkKategoris.index'));
        }

        return view('produk_kategoris.show')->with('produkKategori', $produkKategori);
    }

    /**
     * Show the form for editing the specified ProdukKategori.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        $produkKategori = $this->produkKategoriRepository->find($id);

        if (empty($produkKategori)) {
            Flash::error('Produk Kategori not found');

            return redirect(route('produkKategoris.index'));
        }

        return view('produk_kategoris.edit')->with('produkKategori', $produkKategori);
    }

    /**
     * Update the specified ProdukKategori in storage.
     *
     * @param  int              $id
     * @param UpdateProdukKategoriRequest $request
     *
     * @return Response
     */
    public function update($id, UpdateProdukKategoriRequest $request)
    {
        $produkKategori = $this->produkKategoriRepository->find($id);

        if (empty($produkKategori)) {
            Flash::error('Produk Kategori not found');

            return redirect(route('produkKategoris.index'));
        }

        $produkKategori = $this->produkKategoriRepository->update($request->all(), $id);

        Flash::success('Produk Kategori updated successfully.');

        return redirect(route('produkKategoris.index'));
    }

    /**
     * Remove the specified ProdukKategori from storage.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function destroy($id)
    {
        $produkKategori = $this->produkKategoriRepository->find($id);

        if (empty($produkKategori)) {
            Flash::error('Produk Kategori not found');

            return redirect(route('produkKategoris.index'));
        }

        $this->produkKategoriRepository->delete($id);

        Flash::success('Produk Kategori deleted successfully.');

        return redirect(route('produkKategoris.index'));
    }
}
