<?php

namespace App\Http\Controllers;

use App\DataTables\QuestionSkmDataTable;
use App\Http\Requests;
use App\Http\Requests\CreateQuestionSkmRequest;
use App\Http\Requests\UpdateQuestionSkmRequest;
use App\Repositories\QuestionSkmRepository;
use Flash;
use App\Http\Controllers\AppBaseController;
use Response;

class QuestionSkmController extends AppBaseController
{
    /** @var  QuestionSkmRepository */
    private $questionSkmRepository;

    public function __construct(QuestionSkmRepository $questionSkmRepo)
    {
        $this->questionSkmRepository = $questionSkmRepo;
    }

    /**
     * Display a listing of the QuestionSkm.
     *
     * @param QuestionSkmDataTable $questionSkmDataTable
     * @return Response
     */
    public function index(QuestionSkmDataTable $questionSkmDataTable)
    {
        return $questionSkmDataTable->render('question_skms.index');
    }

    /**
     * Show the form for creating a new QuestionSkm.
     *
     * @return Response
     */
    public function create()
    {
        return view('question_skms.create');
    }

    /**
     * Store a newly created QuestionSkm in storage.
     *
     * @param CreateQuestionSkmRequest $request
     *
     * @return Response
     */
    public function store(CreateQuestionSkmRequest $request)
    {
        // $input = $request->all();

        // $questionSkm = $this->questionSkmRepository->create($input);

        // Flash::success('Question Skm saved successfully.');

        // return redirect(route('questionSkms.index'));
    }

    /**
     * Display the specified QuestionSkm.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function show($id)
    {
        $questionSkm = $this->questionSkmRepository->find($id);

        if (empty($questionSkm)) {
            Flash::error('Question Skm not found');

            return redirect(route('questionSkms.index'));
        }

        return view('question_skms.show')->with('questionSkm', $questionSkm);
    }

    /**
     * Show the form for editing the specified QuestionSkm.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        $questionSkm = $this->questionSkmRepository->find($id);

        if (empty($questionSkm)) {
            Flash::error('Question Skm not found');

            return redirect(route('questionSkms.index'));
        }

        return view('question_skms.edit')->with('questionSkm', $questionSkm);
    }

    /**
     * Update the specified QuestionSkm in storage.
     *
     * @param  int              $id
     * @param UpdateQuestionSkmRequest $request
     *
     * @return Response
     */
    public function update($id, UpdateQuestionSkmRequest $request)
    {
        $questionSkm = $this->questionSkmRepository->find($id);

        if (empty($questionSkm)) {
            Flash::error('Question Skm not found');

            return redirect(route('questionSkms.index'));
        }

        $questionSkm = $this->questionSkmRepository->update($request->all(), $id);

        Flash::success('Question Skm updated successfully.');

        return redirect(route('questionSkms.index'));
    }

    /**
     * Remove the specified QuestionSkm from storage.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function destroy($id)
    {
        $questionSkm = $this->questionSkmRepository->find($id);

        if (empty($questionSkm)) {
            Flash::error('Question Skm not found');

            return redirect(route('questionSkms.index'));
        }

        $this->questionSkmRepository->delete($id);

        Flash::success('Question Skm deleted successfully.');

        return redirect(route('questionSkms.index'));
    }
}
