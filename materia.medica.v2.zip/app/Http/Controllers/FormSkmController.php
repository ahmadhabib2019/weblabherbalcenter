<?php

namespace App\Http\Controllers;

use App\DataTables\FormSkmDataTable;
use App\Http\Requests;
use App\Http\Requests\CreateFormSkmRequest;
use App\Http\Requests\UpdateFormSkmRequest;
use App\Repositories\FormSkmRepository;
use Flash;
use App\Http\Controllers\AppBaseController;
use Response;
use App\Models\QuestionSkm;
use App\Models\Service;
use App\Models\FormSkmContent;
class FormSkmController extends AppBaseController
{
    /** @var  FormSkmRepository */
    private $formSkmRepository;

    public function __construct(FormSkmRepository $formSkmRepo)
    {
        $this->formSkmRepository = $formSkmRepo;
    }

    /**
     * Display a listing of the FormSkm.
     *
     * @param FormSkmDataTable $formSkmDataTable
     * @return Response
     */
    public function index(FormSkmDataTable $formSkmDataTable)
    {
        return $formSkmDataTable->render('form_skms.index');
    }

    /**
     * Show the form for creating a new FormSkm.
     *
     * @return Response
     */
    public function create()
    {
        $question = QuestionSkm::pluck('question','id');
        $service = Service::pluck('title','id');
        return view('form_skms.create')->with('question',$question)->with('service',$service);
    }

    /**
     * Store a newly created FormSkm in storage.
     *
     * @param CreateFormSkmRequest $request
     *
     * @return Response
     */
    public function store(CreateFormSkmRequest $request)
    {
        $input = $request->all();
        $formSkm = $this->formSkmRepository->create($input);

        foreach ($input['question_skm_id'] as $question_id) {
            $formSkmContent = new FormSkmContent;
            $formSkmContent->form_skm_id = $formSkm->id;
            $formSkmContent->question_skm_id = $question_id;
            $formSkmContent->save();
        }

        Flash::success('Form Skm saved successfully.');

        return redirect(route('formSkms.index'));
    }

    /**
     * Display the specified FormSkm.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function show($id)
    {
        $formSkm = $this->formSkmRepository->find($id);

        if (empty($formSkm)) {
            Flash::error('Form Skm not found');

            return redirect(route('formSkms.index'));
        }

        return view('form_skms.show')->with('formSkm', $formSkm);
    }

    /**
     * Show the form for editing the specified FormSkm.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        $formSkm = $this->formSkmRepository->find($id);
        $question = QuestionSkm::pluck('question','id');
        $service = Service::pluck('title','id');

        if (empty($formSkm)) {
            Flash::error('Form Skm not found');

            return redirect(route('formSkms.index'));
        }

        return view('form_skms.edit')->with('formSkm', $formSkm)->with('service',$service)->with('question',$question);
    }

    /**
     * Update the specified FormSkm in storage.
     *
     * @param  int              $id
     * @param UpdateFormSkmRequest $request
     *
     * @return Response
     */
    public function update($id, UpdateFormSkmRequest $request)
    {
        $formSkm = $this->formSkmRepository->find($id);

        if (empty($formSkm)) {
            Flash::error('Form Skm not found');

            return redirect(route('formSkms.index'));
        }

        $formSkm = $this->formSkmRepository->update($request->all(), $id);

        Flash::success('Form Skm updated successfully.');

        return redirect(route('formSkms.index'));
    }

    /**
     * Remove the specified FormSkm from storage.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function destroy($id)
    {
        $formSkm = $this->formSkmRepository->find($id);

        if (empty($formSkm)) {
            Flash::error('Form Skm not found');

            return redirect(route('formSkms.index'));
        }

        $this->formSkmRepository->delete($id);

        Flash::success('Form Skm deleted successfully.');

        return redirect(route('formSkms.index'));
    }
}
