<?php

namespace App\Http\Controllers;

use App\DataTables\SaranKritikDataTable;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Requests\CreateSaranKritikRequest;
use App\Http\Requests\UpdateSaranKritikRequest;
use App\Repositories\SaranKritikRepository;
use Flash;
use App\Http\Controllers\AppBaseController;
use Response;
use App\Models\SaranKritik;
use App\Exports\SaranExport;
use Maatwebsite\Excel\Facades\Excel;

class SaranKritikController extends AppBaseController
{
    /** @var  SaranKritikRepository */
    private $saranKritikRepository;

    public function __construct(SaranKritikRepository $saranKritikRepo)
    {
        $this->saranKritikRepository = $saranKritikRepo;
    }

    /**
     * Display a listing of the SaranKritik.
     *
     * @param SaranKritikDataTable $saranKritikDataTable
     * @return Response
     */
    public function index(SaranKritikDataTable $saranKritikDataTable)
    {
        $data = SaranKritik::orderby('created_at','desc')->paginate(10);

        return view('saran_kritiks.index',compact('data'))->with('i');
    }

    /**
     * Show the form for creating a new SaranKritik.
     *
     * @return Response
     */
    public function create()
    {
        return view('saran_kritiks.create');
    }

    /**
     * Store a newly created SaranKritik in storage.
     *
     * @param CreateSaranKritikRequest $request
     *
     * @return Response
     */
    public function store(CreateSaranKritikRequest $request)
    {
        $input = $request->all();

        $saranKritik = $this->saranKritikRepository->create($input);

        Flash::success('Saran Kritik saved successfully.');

        return redirect(route('saranKritiks.index'));
    }

    /**
     * Display the specified SaranKritik.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function show($id)
    {
        $saranKritik = $this->saranKritikRepository->find($id);

        if (empty($saranKritik)) {
            Flash::error('Saran Kritik not found');

            return redirect(route('saranKritiks.index'));
        }

        return view('saran_kritiks.show')->with('saranKritik', $saranKritik);
    }

    /**
     * Show the form for editing the specified SaranKritik.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        $saranKritik = $this->saranKritikRepository->find($id);

        if (empty($saranKritik)) {
            Flash::error('Saran Kritik not found');

            return redirect(route('saranKritiks.index'));
        }

        return view('saran_kritiks.edit')->with('saranKritik', $saranKritik);
    }

    /**
     * Update the specified SaranKritik in storage.
     *
     * @param  int              $id
     * @param UpdateSaranKritikRequest $request
     *
     * @return Response
     */
    public function update($id, UpdateSaranKritikRequest $request)
    {
        $saranKritik = $this->saranKritikRepository->find($id);

        if (empty($saranKritik)) {
            Flash::error('Saran Kritik not found');

            return redirect(route('saranKritiks.index'));
        }

        $saranKritik = $this->saranKritikRepository->update($request->all(), $id);

        Flash::success('Saran Kritik updated successfully.');

        return redirect(route('saranKritiks.index'));
    }

    /**
     * Remove the specified SaranKritik from storage.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function destroy($id)
    {
        $saranKritik = $this->saranKritikRepository->find($id);

        if (empty($saranKritik)) {
            Flash::error('Saran Kritik not found');

            return redirect(route('saranKritiks.index'));
        }

        $this->saranKritikRepository->delete($id);

        Flash::success('Saran Kritik deleted successfully.');

        return redirect(route('saranKritiks.index'));
    }

    public function export_excel(Request $request)
    {
        return Excel::download(new SaranExport($request), 'saran_kritik.xls');
    }
}
