<?php

namespace App\Http\Controllers;

use App\DataTables\CarouselDataTable;
use App\Http\Requests;
use App\Http\Requests\CreateCarouselRequest;
use App\Http\Requests\UpdateCarouselRequest;
use App\Repositories\CarouselRepository;
use Intervention\Image\ImageManagerStatic as Image;
use Flash;
use App\Http\Controllers\AppBaseController;
use Response;

class CarouselController extends AppBaseController
{
    /** @var  CarouselRepository */
    private $carouselRepository;

    public function __construct(CarouselRepository $carouselRepo)
    {
        $this->carouselRepository = $carouselRepo;
    }

    /**
     * Display a listing of the Carousel.
     *
     * @param CarouselDataTable $carouselDataTable
     * @return Response
     */
    public function index(CarouselDataTable $carouselDataTable)
    {
        return $carouselDataTable->render('carousels.index');
    }

    /**
     * Show the form for creating a new Carousel.
     *
     * @return Response
     */
    public function create()
    {
        return view('carousels.create');
    }

    /**
     * Store a newly created Carousel in storage.
     *
     * @param CreateCarouselRequest $request
     *
     * @return Response
     */
    public function store(CreateCarouselRequest $request)
    {
        $input = $request->all();
        $request->validate([
            'image_url' => 'image|mimes:jpeg,png,jpg,gif,svg|max:15048',
        ]);
        if($request->image_url){
            $filename = date('is').'-'.$request->image_url->getClientOriginalName();
            $image_resize = Image::make($request->image_url->getRealPath());              
            $image_resize->resize(1280, 720);
            $destinationPath = public_path('storage/carousel/images/');
            $image_resize->save($destinationPath. $filename);
            $input['image_url']='storage/carousel/images/'.$filename;
        }
        $carousel = $this->carouselRepository->create($input);

        Flash::success('Carousel saved successfully.');

        return redirect(route('carousels.index'));
    }

    /**
     * Display the specified Carousel.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function show($id)
    {
        $carousel = $this->carouselRepository->find($id);

        if (empty($carousel)) {
            Flash::error('Carousel not found');

            return redirect(route('carousels.index'));
        }

        return view('carousels.show')->with('carousel', $carousel);
    }

    /**
     * Show the form for editing the specified Carousel.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        $carousel = $this->carouselRepository->find($id);

        if (empty($carousel)) {
            Flash::error('Carousel not found');

            return redirect(route('carousels.index'));
        }

        return view('carousels.edit')->with('carousel', $carousel);
    }

    /**
     * Update the specified Carousel in storage.
     *
     * @param  int              $id
     * @param UpdateCarouselRequest $request
     *
     * @return Response
     */
    public function update($id, UpdateCarouselRequest $request)
    {
        $carousel = $this->carouselRepository->find($id);
        $data =$request->all();
        if (empty($carousel)) {
            Flash::error('Carousel not found');

            return redirect(route('carousels.index'));
        }
        $data = $request->hasFile('image_url') ? $request->all() : $request->except('image_url');
        if($request->hasFile('image_url')){
            $filename = 'carousel-'.$id.'.'.$request->image_url->extension();
            $image_resize = Image::make($request->image_url->getRealPath());              
            $image_resize->resize(1280, 720);
            $destinationPath = public_path('storage/carousel/images/');
            $image_resize->save($destinationPath. $filename);
            $data['image_url']='storage/carousel/images/'.$filename;
        }
        $carousel = $this->carouselRepository->update($data, $id);

        Flash::success('Carousel updated successfully.');

        return redirect(route('carousels.index'));
    }

    /**
     * Remove the specified Carousel from storage.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function destroy($id)
    {
        $carousel = $this->carouselRepository->find($id);

        if (empty($carousel)) {
            Flash::error('Carousel not found');

            return redirect(route('carousels.index'));
        }

        $this->carouselRepository->delete($id);

        Flash::success('Carousel deleted successfully.');

        return redirect(route('carousels.index'));
    }
}
