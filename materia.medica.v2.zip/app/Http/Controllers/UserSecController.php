<?php
namespace App\Http\Controllers;
use App\DataTables\UserDataTableSec;
use App\Http\Requests;
use App\Http\Requests\CreateUserRequest;
use App\Http\Requests\UpdateUserRequest;
use App\Repositories\UserRepository;
use Flash;
use App\Http\Controllers\AppBaseController;
use Illuminate\Support\Facades\DB;
use Response;
use Spatie\Permission\Models\Role;
class UserSecController extends AppBaseController
{
    /** @var  UserRepository */
    private $userRepository;
    public function __construct(UserRepository $userRepo)
    {
        $this->userRepository = $userRepo;
        $this->middleware('permission:admin-list|admin-create|admin-edit|admin-delete', ['only' => ['index', 'show']]);
        $this->middleware('permission:admin-create', ['only' => ['create', 'store']]);
        $this->middleware('permission:admin-edit', ['only' => ['edit', 'update']]);
        $this->middleware('permission:admin-delete', ['only' => ['destroy']]);
    }
    /**
     * Display a listing of the User.
     *
     * @param UserDataTable $userDataTable
     * @return Response
     */
    public function index(UserDataTableSec $userDataTable)
    {
        return $userDataTable->render('users.index');
    }
    /**
     * Show the form for creating a new User.
     *
     * @return Response
     */
    public function create()
    {
        $roles = Role::pluck('name', 'name')->all();
        return view('users.create', compact('roles'));
    }
    /**
     * Store a newly created User in storage.
     *
     * @param CreateUserRequest $request
     *
     * @return Response
     */
    public function store(CreateUserRequest $request)
    {
        $input = $request->all();
        if ($request->hasFile('image')) {
            $filename = $input['username'] . '.' . $request->image->extension();
            $request->image->storeAs('images', $filename, 'profile');
            $input['image'] = 'storage/profile/images/' . $filename;
        }
        $user = $this->userRepository->create($input);

        $user->assignRole($request->input('roles'));
        Flash::success('User saved successfully.');
        return redirect(route('users.index'));
    }
    /**
     * Display the specified User.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function show($id)
    {
        $user = $this->userRepository->find($id);
        if (empty($user)) {
            Flash::error('User not found');
            return redirect(route('users.index'));
        }
        return view('users.show')->with('user', $user);
    }
    /**
     * Show the form for editing the specified User.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        $user = $this->userRepository->find($id);
        $roles = Role::pluck('name', 'name')->all();
        $userRole = $user->roles->pluck('name', 'name')->all();
        if (empty($user)) {
            Flash::error('User not found');
            return redirect(route('users.index'));
        }
        return view('users.edit')->with('user', $user)->with('roles', $roles)->with('userRole', $userRole);
    }
    /**
     * Update the specified User in storage.
     *
     * @param  int              $id
     * @param UpdateUserRequest $request
     *
     * @return Response
     */
    public function update($id, UpdateUserRequest $request)
    {
        $user = $this->userRepository->find($id);
        if (empty($user)) {
            Flash::error('User not found');
            return redirect(route('users.index'));
        }
        $data = $request->filled('password') ? $request->all() : $request->except('password');
        if ($request->hasFile('image')) {
            $filename = $data['username'] . '.' . $request->image->extension();
            $request->image->storeAs('images', $filename, 'profile');
            $data['image'] = 'storage/profile/images/' . $filename;
        }
        $user = $this->userRepository->update($data, $id);
                DB::table('model_has_roles')->where('model_id',$id)->delete();
        $user->assignRole($request->input('roles'));
        Flash::success('User updated successfully.');
        return redirect(route('users.index'));
    }
    /**
     * Remove the specified User from storage.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function destroy($id)
    {
        $user = $this->userRepository->find($id);
        if (empty($user)) {
            Flash::error('User not found');
            return redirect(route('users.index'));
        }
        $this->userRepository->delete($id);
        Flash::success('User deleted successfully.');
        return redirect(route('users.index'));
    }
}
