<?php

namespace App\Http\Controllers;

use App\DataTables\ServiceDataTable;
use App\Http\Requests;
use App\Http\Requests\CreateServiceRequest;
use App\Http\Requests\UpdateServiceRequest;
use App\Repositories\ServiceRepository;
use Flash;
use App\Http\Controllers\AppBaseController;
use App\Models\ContactPerson;
use App\Models\Menu;
use Response;
use App\Models\ServiceFile;
use Str;
use Illuminate\Validation\ValidationException;

class ServiceController extends AppBaseController
{
    /** @var  ServiceRepository */
    private $serviceRepository;

    public function __construct(ServiceRepository $serviceRepo)
    {
        $this->kategori = ['open'=>'Open Class','ofline'=>'Offline Class','online'=>'Online Class'];
        $this->serviceRepository = $serviceRepo;
    }

    /**
     * Display a listing of the Service.
     *
     * @param ServiceDataTable $serviceDataTable
     * @return Response
     */
    public function index(ServiceDataTable $serviceDataTable)
    {
        return $serviceDataTable->render('services.index');
    }

    /**
     * Show the form for creating a new Service.
     *
     * @return Response
     */
    public function create()
    {
        $contact_person = ContactPerson::pluck('name','id');
        return view('services.create')->with('contact_person',$contact_person)->with('category',$this->kategori);
    }

    /**
     * Store a newly created Service in storage.
     *
     * @param CreateServiceRequest $request
     *
     * @return Response
     */
    public function store(CreateServiceRequest $request)
    {
        $input = $request->all();
        $input['slug'] = Str::slug($request->title);
        Menu::where('title',$input['title'])->update(['param'=>$input['slug'],'url'=>'frontend.service']);
        $service = $this->serviceRepository->create($input);
        if(isset($request->images)){
            try {
                foreach ($request->images as $key => $image) {
                    $imageName = Str::slug($request->title) . '-' . ($key+1) . '.' . $image->getClientOriginalExtension();
                    $destinationPath = public_path('storage/service');
                    $image->move($destinationPath, $imageName);
                    $src = 'storage/service/' . $imageName;
    
                    $service_file = new ServiceFile();
                    $service_file->src = $src;
                    $service_file->service_id = $service->id;
                    $service_file->save();
                }
            } catch (\Throwable $th) {
                throw ValidationException::withMessages(['Please upload at least one image']);
            }
        }

        Flash::success('Service saved successfully.');

        return redirect(route('services.index'));
    }

    /**
     * Display the specified Service.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function show($id)
    {
        $service = $this->serviceRepository->find($id);
        
        if (empty($service)) {
            Flash::error('Service not found');

            return redirect(route('services.index'));
        }

        return view('services.show')->with('service', $service);
    }

    /**
     * Show the form for editing the specified Service.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        $service = $this->serviceRepository->find($id);
        $contact_person = ContactPerson::pluck('name','id');
        if (empty($service)) {
            Flash::error('Service not found');

            return redirect(route('services.index'));
        }

        return view('services.edit')->with('service', $service)->with('contact_person',$contact_person)->with('category',$this->kategori);
    }

    /**
     * Update the specified Service in storage.
     *
     * @param  int              $id
     * @param UpdateServiceRequest $request
     *
     * @return Response
     */
    public function update($id, UpdateServiceRequest $request)
    {
        $service = $this->serviceRepository->find($id);
        if (empty($service)) {
            Flash::error('Service not found');

            return redirect(route('services.index'));
        }
        $service = $this->serviceRepository->update($request->all(), $id);

                    if($request->preloaded ==null && $request->images ==null){
                        throw ValidationException::withMessages(['Please upload at least one image']);
                    }
                    //old image,check old image, delete when ID not exist
                    if(isset($request->preloaded)){

                        if(count($request->preloaded)>0){
                        // foreach($request->preloaded as $_id ){
                            $details = ServiceFile::where('service_id',$id)->whereNotIn('id',$request->preloaded)->delete();
                            // }
                        }else{
                            //delete old image
                            $details = ServiceFile::where('service_id',$id)->delete();
                        }
                    }
                    //if add new image
                    if(isset($request->images)){ 
                        $index = ServiceFile::where('service_id',$id)->get();
                        $last_index= count($index);
                        foreach ($request->images as $key => $image) {
                            $imageName = Str::slug($request->title) . '-' . ($last_index+1) . '.' . $image->getClientOriginalExtension();
                            $destinationPath = public_path('storage/service');
                            $image->move($destinationPath, $imageName);
                            $src = 'storage/service/' . $imageName;

                            $service_file = new ServiceFile();
                            $service_file->src = $src;
                            $service_file->service_id = $service->id;
                            $service_file->save();
                            $last_index++;
                        }
                        // }else{
                        //     throw ValidationException::withMessages(['Please upload at least one image']);
                    }

        Flash::success('Service updated successfully.');

        return redirect(route('services.index'));
    }

    /**
     * Remove the specified Service from storage.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function destroy($id)
    {
        $service = $this->serviceRepository->find($id);

        if (empty($service)) {
            Flash::error('Service not found');

            return redirect(route('services.index'));
        }

        $this->serviceRepository->delete($id);

        Flash::success('Service deleted successfully.');

        return redirect(route('services.index'));
    }
}
