<?php

namespace App\Http\Controllers;

use App\DataTables\InovasiDataTable;
use App\Http\Requests;
use App\Http\Requests\CreateInovasiRequest;
use App\Http\Requests\UpdateInovasiRequest;
use App\Repositories\InovasiRepository;
use Flash;
use App\Http\Controllers\AppBaseController;
use Illuminate\Validation\ValidationException;
use Response;
use Str;
use App\Models\InovasiFile;

class InovasiController extends AppBaseController
{
    /** @var  InovasiRepository */
    private $inovasiRepository;

    public function __construct(InovasiRepository $inovasiRepo)
    {
        $this->inovasiRepository = $inovasiRepo;
    }

    /**
     * Display a listing of the Inovasi.
     *
     * @param InovasiDataTable $inovasiDataTable
     * @return Response
     */
    public function index(InovasiDataTable $inovasiDataTable)
    {
        return $inovasiDataTable->render('inovasis.index');
    }

    /**
     * Show the form for creating a new Inovasi.
     *
     * @return Response
     */
    public function create()
    {
        return view('inovasis.create');
    }

    /**
     * Store a newly created Inovasi in storage.
     *
     * @param CreateInovasiRequest $request
     *
     * @return Response
     */
    public function store(CreateInovasiRequest $request)
    {
        $input = $request->all();
        $input['category'] = 'inovasi';
        $inovasi = $this->inovasiRepository->create($input);
            // try {
                foreach ($request->images as $key => $image) {
                    $imageName = Str::slug($request->title) . '-' . ($key + 1) . '.' . $image->getClientOriginalExtension();
                    $destinationPath = public_path('storage/inovasi');
                    $image->move($destinationPath, $imageName);
                    $src = 'storage/inovasi/' . $imageName;
    
                    $inovasi_files = new InovasiFile();
                    $inovasi_files->src = $src;
                    $inovasi_files->inovasi_id = $inovasi->id;
                    $inovasi_files->save();
                }
            // } catch (\Throwable $th) {
            //     throw ValidationException::withMessages([$th]);
            // }
        Flash::success('Inovasi saved successfully.');

        return redirect(route('inovasis.index'));
    }

    /**
     * Display the specified Inovasi.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function show($id)
    {
        $inovasi = $this->inovasiRepository->find($id);

        if (empty($inovasi)) {
            Flash::error('Inovasi not found');

            return redirect(route('inovasis.index'));
        }

        return view('inovasis.show')->with('inovasi', $inovasi);
    }

    /**
     * Show the form for editing the specified Inovasi.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        $inovasi = $this->inovasiRepository->find($id);

        if (empty($inovasi)) {
            Flash::error('Inovasi not found');

            return redirect(route('inovasis.index'));
        }

        return view('inovasis.edit')->with('inovasi', $inovasi);
    }

    /**
     * Update the specified Inovasi in storage.
     *
     * @param  int              $id
     * @param UpdateInovasiRequest $request
     *
     * @return Response
     */
    public function update($id, UpdateInovasiRequest $request)
    {
        $inovasi = $this->inovasiRepository->find($id);

        if (empty($inovasi)) {
            Flash::error('Inovasi not found');

            return redirect(route('inovasis.index'));
        }

        $inovasi = $this->inovasiRepository->update($request->all(), $id);
        if($request->preloaded==null && $request->images==null){
            throw ValidationException::withMessages(['Please upload at least one image']);
        }
       //old image,check old image, delete when ID not exist
       if($request->preloaded != null && $request->preloaded > 0){
        // foreach($request->preloaded as $_id ){
                $details = InovasiFile::where('inovasi_id',$id)->whereNotIn('id',$request->preloaded)->delete();
            // }
        }else{
            //delete old image
            $details = InovasiFile::where('inovasi_id',$id)->delete();
        }
        //if add new image

        if(isset($request->images) && count($request->images) > 0){ 
            $index = InovasiFile::where('inovasi_id',$id)->get();
            $last_index= count($index);
            foreach ($request->images as $key => $image) {
                $imageName = Str::slug($request->title) . '-' . ($last_index+1) . '.' . $image->getClientOriginalExtension();
                $destinationPath = public_path('storage/produk');
                $image->move($destinationPath, $imageName);
                $src = 'storage/produk/' . $imageName;

                $inovasi_images = new InovasiFile();
                $inovasi_images->src = $src;
                $inovasi_images->inovasi_id = $inovasi->id;
                $inovasi_images->save();
                $last_index++;
            }
        // }else{
        //     throw ValidationException::withMessages(['Please upload at least one image']);
        }

        Flash::success('Inovasi updated successfully.');

        return redirect(route('inovasis.index'));
    }

    /**
     * Remove the specified Inovasi from storage.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function destroy($id)
    {
        $inovasi = $this->inovasiRepository->find($id);

        if (empty($inovasi)) {
            Flash::error('Inovasi not found');

            return redirect(route('inovasis.index'));
        }

        $this->inovasiRepository->delete($id);

        Flash::success('Inovasi deleted successfully.');

        return redirect(route('inovasis.index'));
    }
}
