<?php

namespace App\Repositories;

use App\Models\ProdukOrder;
use App\Repositories\BaseRepository;

/**
 * Class ProdukOrderRepository
 * @package App\Repositories
 * @version September 11, 2021, 8:21 am WIB
*/

class ProdukOrderRepository extends BaseRepository
{
    /**
     * @var array
     */
    protected $fieldSearchable = [
        'user_id',
        'produk_id',
        'kategori_id',
        'kode_trans',
        'qty',
        'total'
    ];

    /**
     * Return searchable fields
     *
     * @return array
     */
    public function getFieldsSearchable()
    {
        return $this->fieldSearchable;
    }

    /**
     * Configure the Model
     **/
    public function model()
    {
        return ProdukOrder::class;
    }
}
