<?php

namespace App\Repositories;

use App\Models\Telemedisin;
use App\Repositories\BaseRepository;

/**
 * Class TelemedisinRepository
 * @package App\Repositories
 * @version December 29, 2021, 6:26 pm WIB
*/

class TelemedisinRepository extends BaseRepository
{
    /**
     * @var array
     */
    protected $fieldSearchable = [
        'user_id',
        'pertanyaan',
        'jawaban'
    ];

    /**
     * Return searchable fields
     *
     * @return array
     */
    public function getFieldsSearchable()
    {
        return $this->fieldSearchable;
    }

    /**
     * Configure the Model
     **/
    public function model()
    {
        return Telemedisin::class;
    }
}
