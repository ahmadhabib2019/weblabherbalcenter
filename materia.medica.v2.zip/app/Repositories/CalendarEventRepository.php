<?php

namespace App\Repositories;

use App\Models\CalendarEvent;
use App\Repositories\BaseRepository;

/**
 * Class CalendarEventRepository
 * @package App\Repositories
 * @version September 4, 2021, 8:46 am WIB
*/

class CalendarEventRepository extends BaseRepository
{
    /**
     * @var array
     */
    protected $fieldSearchable = [
        'title',
        'fullday',
        'start',
        'finish',
        'stringEventId'
    ];

    /**
     * Return searchable fields
     *
     * @return array
     */
    public function getFieldsSearchable()
    {
        return $this->fieldSearchable;
    }

    /**
     * Configure the Model
     **/
    public function model()
    {
        return CalendarEvent::class;
    }
}
