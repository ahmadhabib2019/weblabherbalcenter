<?php

namespace App\Repositories;

use App\Models\FormRegistrationContent;
use App\Repositories\BaseRepository;

/**
 * Class FormRegistrationContentRepository
 * @package App\Repositories
 * @version August 30, 2021, 8:11 pm WIB
 */

class FormRegistrationContentRepository extends BaseRepository
{
    /**
     * @var array
     */
    protected $fieldSearchable = [
        'form_registration_id',
        'question_id'
    ];

    /**
     * Return searchable fields
     *
     * @return array
     */
    public function getFieldsSearchable()
    {
        return $this->fieldSearchable;
    }

    /**
     * Configure the Model
     **/
    public function model()
    {
        return FormRegistrationContent::class;
    }

    /**
     * Find question at form registration
     */
    public function findQuestions($form_id, $question_id)
    {
        return FormRegistrationContent::where([
            ['form_registration_id', $form_id],
            ['question_id', $question_id]
        ])->get();
    }


    public function deleteQuestions($params)
    {
        foreach ($params as $key => $value) {
            $data  = FormRegistrationContent::where([
                ['id', $key],
                ['question_id', $value]
            ]);
        }


        $data->delete();
    }
}
