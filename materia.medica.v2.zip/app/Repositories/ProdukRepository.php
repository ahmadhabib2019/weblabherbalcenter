<?php

namespace App\Repositories;

use App\Models\Produk;
use App\Repositories\BaseRepository;

/**
 * Class ProdukRepository
 * @package App\Repositories
 * @version September 4, 2021, 7:02 pm WIB
*/

class ProdukRepository extends BaseRepository
{
    /**
     * @var array
     */
    protected $fieldSearchable = [
        'kategori_id',
        'nama',
        'price',
        'stok'
    ];

    /**
     * Return searchable fields
     *
     * @return array
     */
    public function getFieldsSearchable()
    {
        return $this->fieldSearchable;
    }

    /**
     * Configure the Model
     **/
    public function model()
    {
        return Produk::class;
    }
}
