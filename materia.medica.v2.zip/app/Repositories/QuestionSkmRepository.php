<?php

namespace App\Repositories;

use App\Models\QuestionSkm;
use App\Repositories\BaseRepository;

/**
 * Class QuestionSkmRepository
 * @package App\Repositories
 * @version September 26, 2021, 3:09 pm WIB
*/

class QuestionSkmRepository extends BaseRepository
{
    /**
     * @var array
     */
    protected $fieldSearchable = [
        'question'
    ];

    /**
     * Return searchable fields
     *
     * @return array
     */
    public function getFieldsSearchable()
    {
        return $this->fieldSearchable;
    }

    /**
     * Configure the Model
     **/
    public function model()
    {
        return QuestionSkm::class;
    }
}
