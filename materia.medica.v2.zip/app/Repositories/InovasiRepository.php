<?php

namespace App\Repositories;

use App\Models\Inovasi;
use App\Repositories\BaseRepository;

/**
 * Class InovasiRepository
 * @package App\Repositories
 * @version September 14, 2021, 11:35 am WIB
*/

class InovasiRepository extends BaseRepository
{
    /**
     * @var array
     */
    protected $fieldSearchable = [
        'title',
        'description',
        'year',
        'download'
    ];

    /**
     * Return searchable fields
     *
     * @return array
     */
    public function getFieldsSearchable()
    {
        return $this->fieldSearchable;
    }

    /**
     * Configure the Model
     **/
    public function model()
    {
        return Inovasi::class;
    }
}
