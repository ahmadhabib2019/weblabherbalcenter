<?php

namespace App\Repositories;

use App\Models\FormSkm;
use App\Repositories\BaseRepository;

/**
 * Class FormSkmRepository
 * @package App\Repositories
 * @version September 26, 2021, 3:10 pm WIB
*/

class FormSkmRepository extends BaseRepository
{
    /**
     * @var array
     */
    protected $fieldSearchable = [
        'service_id',
        'question_id'
    ];

    /**
     * Return searchable fields
     *
     * @return array
     */
    public function getFieldsSearchable()
    {
        return $this->fieldSearchable;
    }

    /**
     * Configure the Model
     **/
    public function model()
    {
        return FormSkm::class;
    }
}
