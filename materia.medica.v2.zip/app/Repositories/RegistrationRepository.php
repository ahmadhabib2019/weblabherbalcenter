<?php

namespace App\Repositories;

use App\Models\Registration;
use App\Repositories\BaseRepository;

/**
 * Class RegistrationRepository
 * @package App\Repositories
 * @version September 11, 2021, 4:56 am WIB
*/

class RegistrationRepository extends BaseRepository
{
    /**
     * @var array
     */
    protected $fieldSearchable = [
        'user_id',
        'services_id',
        'options'
    ];

    /**
     * Return searchable fields
     *
     * @return array
     */
    public function getFieldsSearchable()
    {
        return $this->fieldSearchable;
    }

    /**
     * Configure the Model
     **/
    public function model()
    {
        return Registration::class;
    }
}
