<?php

namespace App\Repositories;

use App\Models\Carousel;
use App\Repositories\BaseRepository;

/**
 * Class CarouselRepository
 * @package App\Repositories
 * @version August 13, 2021, 7:54 am UTC
*/

class CarouselRepository extends BaseRepository
{
    /**
     * @var array
     */
    protected $fieldSearchable = [
        'title',
        'description',
        'image_url',
        'link_url',
        'is_active'
    ];

    /**
     * Return searchable fields
     *
     * @return array
     */
    public function getFieldsSearchable()
    {
        return $this->fieldSearchable;
    }

    /**
     * Configure the Model
     **/
    public function model()
    {
        return Carousel::class;
    }
}
