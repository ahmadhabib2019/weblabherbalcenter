<?php

namespace App\Repositories;

use App\Models\Unduh;
use App\Repositories\BaseRepository;

/**
 * Class UnduhRepository
 * @package App\Repositories
 * @version September 15, 2021, 5:34 pm WIB
*/

class UnduhRepository extends BaseRepository
{
    /**
     * @var array
     */
    protected $fieldSearchable = [
        'title',
        'description',
        'url',
        'file',
        'year'
    ];

    /**
     * Return searchable fields
     *
     * @return array
     */
    public function getFieldsSearchable()
    {
        return $this->fieldSearchable;
    }

    /**
     * Configure the Model
     **/
    public function model()
    {
        return Unduh::class;
    }
}
