<?php

namespace App\Repositories;

use App\Models\WebSetting;
use App\Repositories\BaseRepository;

/**
 * Class WebSettingRepository
 * @package App\Repositories
 * @version August 12, 2021, 6:13 am UTC
*/

class WebSettingRepository extends BaseRepository
{
    /**
     * @var array
     */
    protected $fieldSearchable = [
        'name',
        'value',
        'url'
    ];

    /**
     * Return searchable fields
     *
     * @return array
     */
    public function getFieldsSearchable()
    {
        return $this->fieldSearchable;
    }

    /**
     * Configure the Model
     **/
    public function model()
    {
        return WebSetting::class;
    }
}
