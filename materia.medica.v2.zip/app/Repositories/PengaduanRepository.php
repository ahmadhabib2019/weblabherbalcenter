<?php

namespace App\Repositories;

use App\Models\Pengaduan;
use App\Repositories\BaseRepository;

/**
 * Class PengaduanRepository
 * @package App\Repositories
 * @version September 25, 2021, 2:55 pm WIB
*/

class PengaduanRepository extends BaseRepository
{
    /**
     * @var array
     */
    protected $fieldSearchable = [
        'nama',
        'instansi',
        'alamat',
        'kronologi',
        'waktu',
        'file',
        'user_id'
    ];

    /**
     * Return searchable fields
     *
     * @return array
     */
    public function getFieldsSearchable()
    {
        return $this->fieldSearchable;
    }

    /**
     * Configure the Model
     **/
    public function model()
    {
        return Pengaduan::class;
    }
}
