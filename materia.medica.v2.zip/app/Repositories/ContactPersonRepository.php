<?php

namespace App\Repositories;

use App\Models\ContactPerson;
use App\Repositories\BaseRepository;

/**
 * Class ContactPersonRepository
 * @package App\Repositories
 * @version August 20, 2021, 1:32 am UTC
*/

class ContactPersonRepository extends BaseRepository
{
    /**
     * @var array
     */
    protected $fieldSearchable = [
        'name',
        'email',
        'phone'
    ];

    /**
     * Return searchable fields
     *
     * @return array
     */
    public function getFieldsSearchable()
    {
        return $this->fieldSearchable;
    }

    /**
     * Configure the Model
     **/
    public function model()
    {
        return ContactPerson::class;
    }
}
