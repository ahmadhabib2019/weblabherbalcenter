<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Carbon\Carbon;
/**
 * Class Registration
 * @package App\Models
 * @version September 11, 2021, 4:56 am WIB
 *
 * @property \App\Models\Service $services
 * @property \App\Models\User $user
 * @property \Illuminate\Database\Eloquent\Collection $registrationValues
 * @property integer $user_id
 * @property integer $services_id
 * @property string $options
 */
class Registration extends Model
{
    use SoftDeletes;

    use HasFactory;

    public $table = 'registration';

    const CREATED_AT = 'created_at';
    const UPDATED_AT = 'updated_at';


    protected $dates = ['deleted_at'];



    public $fillable = [
        'user_id',
        'agreement',
        'services_id',
        'options'
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'user_id' => 'integer',
        'agreement' => 'string',
        'services_id' => 'integer',
        'options' => 'string'
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'user_id' => 'required',
        'agreement' => 'nullable',
        'services_id' => 'required',
        'deleted_at' => 'nullable',
        'created_at' => 'nullable',
        'updated_at' => 'nullable',
        'options' => 'nullable|string|max:191'
    ];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function services()
    {
        return $this->belongsTo(\App\Models\Service::class, 'services_id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function user()
    {
        return $this->belongsTo(\App\Models\User::class, 'user_id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     **/
    public function registrationValues()
    {
        return $this->hasMany(\App\Models\RegistrationValue::class, 'registration_id');
    }
    public function getCreatedAtAttribute($value)
    {
        return Carbon::parse($value)->setTimezone('Asia/Jakarta')->locale('id')->format('d-F-Y H:i:s');
    }
    public function getUpdatedAtAttribute($value)
    {
        return Carbon::parse($value)->setTimezone('Asia/Jakarta')->locale('id')->format('d-F-Y H:i:s');
    }
    public static function boot()
    {
        parent::boot();
        self::deleting(function ($registration) { // before delete() method call this
            $registration->registrationValues()->each(function ($registration_value) {
                $registration_value->delete(); // <-- direct deletion
            });
            // do the rest of the cleanup...
        });
    }
}
