<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

/**
 * Class Produk
 * @package App\Models
 * @version September 4, 2021, 7:02 pm WIB
 *
 * @property integer $kategori_id
 * @property string $nama
 * @property integer $price
 * @property integer $stok
 */
class Produk extends Model
{
    use SoftDeletes;

    use HasFactory;

    public $table = 'produks';
    

    protected $dates = ['deleted_at'];



    public $fillable = [
        'kategori_id',
        'nama',
        'price',
        'stok'
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'kategori_id' => 'integer',
        'nama' => 'string',
        'price' => 'integer',
        'stok' => 'integer'
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'kategori_id' => 'required',
        'nama' => 'required'
    ];
    
    public function produkDetails()
    {
        return $this->hasMany(\App\Models\ProdukDetail::class);
    }

    public function produkImages()
    {
        return $this->hasMany(\App\Models\ProdukImage::class,'produk_id');
    }

    public function produkOrder()
    {
        return $this->hasMany(\App\Models\ProdukOrder::class);
    }

    public static function boot()
    {
        parent::boot();
        self::deleting(function ($produk) { // before delete() method call this
            $produk->produkImages()->each(function ($produk_images) {
                $produk_images->delete(); // <-- direct deletion
            });
            // do the rest of the cleanup...
        });
    }

    public function kategori()
    {
        return $this->belongsTo(\App\Models\ProdukKategori::class);
    }
    
}
