<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Model;

class ServiceFile extends Model
{
    use HasFactory;
    use SoftDeletes;

    public $table = 'service_file';
    
    const CREATED_AT = 'created_at';
    const UPDATED_AT = 'updated_at';


    protected $dates = ['deleted_at'];



    public $fillable = [
        'service_id',
        'src',
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'src' => 'string',
        'service_id' => 'integer'
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'src' => 'required|string|max:191',
        'service_id' => 'required',
        'created_at' => 'nullable',
        'updated_at' => 'nullable'
    ];
    public function inovasi()
    {
        return $this->belongsTo(\App\Models\Service::class, 'service_id');
    }

    public function getSrcAttribute($value)
    {
        return asset($value);
    }
}
