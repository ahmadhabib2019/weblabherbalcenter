<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

/**
 * Class Inovasi
 * @package App\Models
 * @version September 14, 2021, 11:35 am WIB
 *
 * @property string $title
 * @property string $description
 * @property integer $year
 * @property integer $download
 */
class Inovasi extends Model
{
    use SoftDeletes;

    use HasFactory;

    public $table = 'inovasi';
    

    protected $dates = ['deleted_at'];



    public $fillable = [
        'title',
        'description',
        'year',
        'download',
        'category',
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'title' => 'string',
        'description' => 'string',
        'year' => 'integer',
        'download' => 'integer'
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'title' => 'required',
        'year' => 'required',
        'download' => 'nullable',
    ];

    public function inovasiFile()
    {
        return $this->hasMany(\App\Models\InovasiFile::class,'inovasi_id');
    }
    
    public static function boot()
    {
        parent::boot();
        self::deleting(function ($inovasi) { // before delete() method call this
            $inovasi->inovasiFile()->each(function ($inovasi_file) {
                $inovasi_file->delete(); // <-- direct deletion
            });
            // do the rest of the cleanup...
        });
    }
}
