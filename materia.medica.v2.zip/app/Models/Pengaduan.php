<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

/**
 * Class Pengaduan
 * @package App\Models
 * @version September 25, 2021, 2:55 pm WIB
 *
 * @property string $nama
 * @property string $instansi
 * @property string $alamat
 * @property string $kronologi
 * @property string $waktu
 * @property string $file
 * @property integer $user_id
 */
class Pengaduan extends Model
{
    use SoftDeletes;

    use HasFactory;

    public $table = 'pengaduans';
    

    protected $dates = ['deleted_at'];



    public $fillable = [
        'nama',
        'instansi',
        'alamat',
        'email',
        'phone',
        'kronologi',
        'waktu',
        'file',
        'user_id'
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'nama' => 'string',
        'instansi' => 'string',
        'alamat' => 'string',
        'email' => 'string',
        'phone' => 'string',
        'kronologi' => 'string',
        'waktu' => 'string',
        'file' => 'string',
        'user_id' => 'integer'
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'nama' => 'nullable',
        'instansi' => 'nullable',
        'alamat' => 'nullable',
        'email' => 'nullable',
        'phone' => 'nullable',
        'kronologi' => 'nullable',
        'waktu' => 'nullable',
        'file' => 'nullable'
    ];

    public function user()
    {
        return $this->belongsTo(\App\Models\User::class);
    }
    
}
