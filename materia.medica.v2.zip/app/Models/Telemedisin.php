<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

/**
 * Class Telemedisin
 * @package App\Models
 * @version December 29, 2021, 6:26 pm WIB
 *
 * @property string $pekerjaan
 * @property string $pertanyaan
 * @property string $jawaban
 */
class Telemedisin extends Model
{
    use SoftDeletes;

    use HasFactory;

    public $table = 'telemedisins';
    

    protected $dates = ['deleted_at'];



    public $fillable = [
        'user_id',
        'pertanyaan',
        'jawaban'
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'user_id' => 'string',
        'pertanyaan' => 'string',
        'jawaban' => 'string'
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'user_id' => 'required',
        'pertanyaan' => 'required',
        'jawaban' => 'nullable'
    ];
    public function user()
    {
        return $this->belongsTo(\App\Models\User::class, 'user_id');
    }
    
}
