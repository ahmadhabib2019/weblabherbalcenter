<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Carbon\Carbon;

/**
 * Class Service
 * @package App\Models
 * @version August 19, 2021, 9:14 am UTC
 *
 * @property \Illuminate\Database\Eloquent\Collection $contact_person
 * @property string $title
 * @property string $description
 * @property string $facilities
 * @property string $requirements
 * @property number $time_period
 * @property number $price
 * @property string $guarantee
 */
class Service extends Model
{
    use SoftDeletes;

    use HasFactory;

    public $table = 'services';

    const CREATED_AT = 'created_at';
    const UPDATED_AT = 'updated_at';


    protected $dates = ['deleted_at'];



    public $fillable = [
        'title',
        'category',
        'slug',
        'description',
        'facilities',
        'requirements',
        'time_period',
        'price',
        'guarantee',
        'contact_person_id'
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'title' => 'string',
        'category' => 'string',
        'slug' => 'string',
        'description' => 'string',
        'facilities' => 'string',
        'requirements' => 'string',
        'time_period' => 'string',
        'price' => 'string',
        'guarantee' => 'string',

    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'title' => 'required|string|max:191',
        'category' => 'nullable|string|max:191',
        'description' => 'nullable|string',
        'facilities' => 'nullable|string',
        'requirements' => 'nullable|string',
        'time_period' => 'nullable|string',
        'price' => 'nullable|string',
        'guarantee' => 'nullable|string',
        'deleted_at' => 'nullable',
        'created_at' => 'nullable',
        'updated_at' => 'nullable'
    ];

    /**
     * Get the contact_persons that owns the Service
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function contact_persons()
    {
        return $this->belongsTo(ContactPerson::class, 'contact_person_id');
    }


    public function registration(){
        return $this->hasMany(Registration::class);
    }

    /**
     * Get the formRegistration associated with the Service
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function form_registration()
    {
        return $this->hasMany(FormRegistration::class,'service_id');
    }

    public function formSkm()
    {
        return $this->hasMany(FormSkm::class,'service_id');
    }

    public function serviceFile()
    {
        return $this->hasMany(\App\Models\ServiceFile::class, 'service_id');
    }

    public function getCreatedAtAttribute($value)
    {
        return Carbon::parse($value)->format('d-M-Y H:i:s');
    }
    public function getUpdatedAtAttribute($value)
    {
        return Carbon::parse($value)->format('d-M-Y H:i:s');
    }

    public static function boot()
    {
        parent::boot();
        self::deleting(function ($service) { // before delete() method call this
            $service->serviceFile()->each(function ($service_file) {
                $service_file->delete(); // <-- direct deletion
            });
            $service->registration()->each(function ($registration) {
                $registration->delete(); // <-- direct deletion
            });
            $service->form_registration()->each(function ($form_registration) {
                $form_registration->delete(); // <-- direct deletion
            });
            // do the rest of the cleanup...
        });
    }
}
