<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Support\Facades\Hash;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Traits\HasRoles;
use App\Models\UserData;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Notifications\Notifiable;

/**
 * Class User
 * @package App\Models
 * @version August 11, 2021, 3:12 pm UTC
 *
 * @property string $name
 * @property string $email
 * @property string|\Carbon\Carbon $email_verified_at
 * @property string $password
 * @property string $remember_token
 */
class User extends Authenticatable implements MustVerifyEmail
{

    use HasFactory, HasRoles,Notifiable;

    public $table = 'users';

    const CREATED_AT = 'created_at';
    const UPDATED_AT = 'updated_at';


    protected $dates = ['deleted_at'];



    public $fillable = [
        'name',
        'username',
        'email',
        'password',
        'image'
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'name' => 'string',
        'username' => 'string',
        'email' => 'string',
        'password' => 'string',
        'image' => 'string'
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'name' => 'required|string|max:255',
        'username' => 'required|string|unique:users,username',
        'email' => 'required|email|max:255|unique:users,email',
        'password' => 'required|string|min:8|max:255|confirmed',
        'image' => 'image|mimes:jpg,png,jpeg,gif,svg|max:20480|dimensions:min_width=100,min_height=100,max_width=5000,max_height=5000',
        'created_at' => 'nullable',
        'updated_at' => 'nullable'
    ];

    public static $update_rules = [
        'name' => 'required|string|max:255',
        'password' => 'sometimes|nullable|string|min:8|max:255|confirmed',
        'image' => 'image|mimes:jpg,png,jpeg,gif,svg|max:20480|dimensions:min_width=100,min_height=100,max_width=5000,max_height=5000',
        'created_at' => 'nullable',
        'updated_at' => 'nullable'
    ];

    public function setPasswordAttribute($value)
    {
        $this->attributes['password'] = Hash::make($value);
    }

    /**
     * Get the roles that owns the User
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    function role()
    {
        return $this->belongsToMany(Role::class, 'model_has_roles', 'model_id', 'role_id');
    }

    public function userData()
    {
        return $this->hasOne(UserData::class);
    }

    public function produkOrder()
    {
        return $this->hasMany(\App\Models\ProdukOrder::class);
    }

    public function pengaduan()
    {
        return $this->hasMany(\App\Models\Pengaduan::class);
    }

    /**
     * Get all of the registrations for the User
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function registrations()
    {
        return $this->hasMany(Registration::class);
    }

    public function saranKritik()
    {
        return $this->hasMany(\App\Models\SaranKritik::class);
    }

    public function telemedisin()
    {
        return $this->hasMany(\App\Models\Telemedisin::class);
    }
}
