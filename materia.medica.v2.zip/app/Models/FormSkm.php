<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

/**
 * Class FormSkm
 * @package App\Models
 * @version September 26, 2021, 3:10 pm WIB
 *
 * @property integer $service_id
 * @property integer $question_skm_id
 */
class FormSkm extends Model
{
    use SoftDeletes;

    use HasFactory;

    public $table = 'form_skms';
    

    protected $dates = ['deleted_at'];



    public $fillable = [
        'service_id',
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'service_id' => 'integer',
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'service_id' => 'required',
    ];

    public function formSkmContent()
    {
        return $this->hasMany(\App\Models\FormSkmContent::class);
    }
    public function service()
    {
        return $this->belongsTo(\App\Models\Service::class);
    }

}
