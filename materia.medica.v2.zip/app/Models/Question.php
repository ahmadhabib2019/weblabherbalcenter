<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

/**
 * Class Question
 * @package App\Models
 * @version August 30, 2021, 7:27 pm WIB
 *
 * @property string $question
 * @property string $type
 * @property string $option
 */
class Question extends Model
{
    use SoftDeletes;

    use HasFactory;

    public $table = 'questions';
    

    protected $dates = ['deleted_at'];



    public $fillable = [
        'question',
        'type',
        'option'
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'question' => 'string',
        'type' => 'string',
        'option' => 'string'
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'question' => 'required',
        'type' => 'required',
    ];

    
}
