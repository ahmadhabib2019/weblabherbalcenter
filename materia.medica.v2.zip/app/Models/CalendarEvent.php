<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Carbon\Carbon;
/**
 * Class CalendarEvent
 * @package App\Models
 * @version September 4, 2021, 8:46 am WIB
 *
 * @property string $title
 * @property boolean $fullday
 * @property string|\Carbon\Carbon $start
 * @property string|\Carbon\Carbon $finish
 * @property string $stringEventId
 */
class CalendarEvent extends Model
{
    use SoftDeletes;

    use HasFactory;

    public $table = 'calendar_events';

    const CREATED_AT = 'created_at';
    const UPDATED_AT = 'updated_at';


    protected $dates = ['deleted_at'];



    public $fillable = [
        'title',
        'peserta',
        'fullday',
        'start',
        'finish',
        'stringEventId',
        'location'
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'title' => 'string',
        'peserta' => 'integer',
        'fullday' => 'boolean',
        'start' => 'datetime',
        'finish' => 'datetime',
        'stringEventId' => 'string',
        'location'=>'string'
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'title' => 'required|string|max:191',
        'peserta' => 'nullable|integer',
        'fullday' => 'required|boolean',
        'start' => 'required',
        'finish' => 'required',
        'location'=>'nullable',
        'stringEventId' => 'nullable|string|max:191',
        'deleted_at' => 'nullable',
        'created_at' => 'nullable',
        'updated_at' => 'nullable'
    ];

     public function getStartAttribute($value)
    {
        return Carbon::parse($value)->format('d-M-Y H:i:s');
    }
    public function getFinishAttribute($value)
    {
        return Carbon::parse($value)->format('d-M-Y H:i:s');
    }

}
