<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Support\Carbon;

/**
 * Class ProdukOrder
 * @package App\Models
 * @version September 11, 2021, 8:21 am WIB
 *
 * @property integert $user_id
 * @property integer $produk_id
 * @property integer $kategori_id
 * @property string $kode_trans
 * @property integer $qty
 * @property string $total
 */
class ProdukOrder extends Model
{
    use SoftDeletes;

    use HasFactory;

    public $table = 'produk_orders';
    

    protected $dates = ['deleted_at'];



    public $fillable = [
        'user_id',
        'kode_trans',
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'user_id' => 'integer',
        'kode_trans' => 'string',
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'user_id' => 'required',
        'kode_trans' => 'required',
    ];

    public function getCreatedAtAttribute($value)
    {
        return Carbon::parse($value)->format('d-M-Y H:i:s');
    }
    public function getUpdatedAtAttribute($value)
    {
        return Carbon::parse($value)->format('d-M-Y H:i:s');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function produkDetail()
    {
        return $this->hasMany(\App\Models\ProdukDetail::class);
    }
    public function produkOrderDetail()
    {
        return $this->hasMany(\App\Models\ProdukOrderDetail::class,'order_id');
    }
    
    public function user()
    {
        return $this->belongsTo(\App\Models\User::class);
    }
}
