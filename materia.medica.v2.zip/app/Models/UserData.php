<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\User;
use Laravolt\Indonesia\Models\City;
use Laravolt\Indonesia\Models\Provinsi;
use Carbon\Carbon;
class UserData extends Model
{
    use HasFactory;

    public $table = 'user_data';

    const CREATED_AT = 'created_at';
    const UPDATED_AT = 'updated_at';


    protected $dates = ['deleted_at'];



    public $fillable = [
        'user_id',
        'nik',
        'nip',
        'gender',
        'tempat_lahir',
        'tgl_lahir',
        'alamat',
        'provinsi',
        'kota',
        'phone',
        'pendidikan_akhir',
        'pekerjaan',
        'jurusan',
        'fakultas',
        'instansi',
        'alamat_instansi',
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'user_id'=>'integer',
        'nik'=>'string',
        'nip'=>'string',
        'gender'=>'string',
        'tempat_lahir'=>'string',
        'tgl_lahir'=>'date',
        'alamat'=>'string',
        'provinsi'=>'string',
        'kota'=>'string',
        'phone'=>'string',
        'pendidikan_akhir'=>'string',
        'pekerjaan'=>'string',
        'jurusan'=>'string',
        'fakultas'=>'string',
        'instansi'=>'string',
        'alamat_instansi'=>'string',
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'nik'=>'required|string|max:255|unique:user_data,nik',
        'nip'=>'string|max:255',
        'tempat_lahir'=>'required|string|max:255',
        'tgl_lahir'=>'required|date',
        'alamat'=>'required|string|max:255',
        'provinsi'=>'required|string|max:255',
        'kota'=>'required|string|max:255',
        'phone'=>'required|string|max:255',
        'pendidikan_akhir'=>'required|string|max:255',
        'pekerjaan'=>'required|string|max:255',
    ];
    public static $update_rules = [
        'nik'=>'required|string|max:255',
        'nip'=>'string|max:255',
        'tempat_lahir'=>'required|string|max:255',
        'tgl_lahir'=>'required|date',
        'alamat'=>'required|string|max:255',
        'provinsi'=>'required|string|max:255',
        'kota'=>'required|string|max:255',
        'phone'=>'required|string|max:255',
        'pendidikan_akhir'=>'required|string|max:255',
        'pekerjaan'=>'required|string|max:255',
    ];

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function province()
    {
        return $this->belongsTo(Provinsi::class, 'provinsi');
    }

    public function city()
    {
        return $this->belongsTo(City::class, 'kota');
    }

    public function getTglLahirAttribute($value)
    {
        return Carbon::parse($value)->format('Y-m-d');
    }
}
