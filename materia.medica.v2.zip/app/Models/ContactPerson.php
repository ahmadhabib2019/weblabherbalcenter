<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

/**
 * Class ContactPerson
 * @package App\Models
 * @version August 20, 2021, 1:32 am UTC
 *
 * @property string $name
 * @property string $email
 * @property string $phone
 */
class ContactPerson extends Model
{
    use SoftDeletes;

    use HasFactory;

    public $table = 'contact_persons';
    
    const CREATED_AT = 'created_at';
    const UPDATED_AT = 'updated_at';


    protected $dates = ['deleted_at'];



    public $fillable = [
        'name',
        'email',
        'phone'
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'name' => 'string',
        'email' => 'string',
        'phone' => 'string'
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'name' => 'required|string|max:191',
        'email' => 'nullable|string|max:191',
        'phone' => 'required|string|max:191',
        'deleted_at' => 'nullable',
        'created_at' => 'nullable',
        'updated_at' => 'nullable'
    ];

    /**
     * Get all of the services for the ContactPerson
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function services()
    {
        return $this->hasMany(Service::class);
    } 

    public static function boot()
    {
        parent::boot();
        self::deleting(function ($gallery) { // before delete() method call this
            $gallery->services()->each(function ($services) {
                $services->contact_person_id = 0;
                $services->save();
            });
        });
    }

}
