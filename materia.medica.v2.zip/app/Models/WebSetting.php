<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

/**
 * Class WebSetting
 * @package App\Models
 * @version August 12, 2021, 6:13 am UTC
 *
 * @property string $name
 * @property string $value
 * @property string $url
 */
class WebSetting extends Model
{
    use SoftDeletes;

    use HasFactory;

    public $table = 'web_settings';
    

    protected $dates = ['deleted_at'];



    public $fillable = [
        'name',
        'value',
        'url'
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'name' => 'string',
        'value' => 'string',
        'url' => 'string'
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        
    ];

    
}
