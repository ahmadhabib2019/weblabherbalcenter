<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

/**
 * Class RegistrationValue
 * @package App\Models
 * @version September 9, 2021, 10:35 am WIB
 *
 * @property \App\Models\Question $question
 * @property \App\Models\Registration $registration
 * @property integer $registration_id
 * @property integer $question_id
 * @property string $values
 */
class RegistrationValue extends Model
{
    use SoftDeletes;

    use HasFactory;

    public $table = 'registration_values';
    
    const CREATED_AT = 'created_at';
    const UPDATED_AT = 'updated_at';


    protected $dates = ['deleted_at'];



    public $fillable = [
        'registration_id',
        'question_id',
        'values'
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'registration_id' => 'integer',
        'question_id' => 'integer',
        'values' => 'string'
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'registration_id' => 'required',
        'question_id' => 'required',
        'values' => 'required|string',
        'created_at' => 'nullable',
        'updated_at' => 'nullable'
    ];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function question()
    {
        return $this->belongsTo(\App\Models\Question::class, 'question_id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function registration()
    {
        return $this->belongsTo(\App\Models\Registration::class, 'registration_id');
    }
}
