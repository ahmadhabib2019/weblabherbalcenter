<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

/**
 * Class Fasilitas
 * @package App\Models
 * @version August 25, 2021, 10:46 am WIB
 *
 * @property string $title
 * @property string $description
 */
class Fasilitas extends Model
{
    use SoftDeletes;

    use HasFactory;

    public $table = 'fasilitas';


    protected $dates = ['deleted_at'];



    public $fillable = [
        'title',
        'description','slug'
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'title' => 'string',
        'description' => 'string',
        'slug'=>'string'
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'title' => 'required'
    ];

    public function fasilitas_files(){
        return $this->hasMany(\App\Models\FasilitasFile::class,'fasilitas_id');
    }

    public static function boot(){
        parent::boot();
        self::deleting(function ($fasilitas) { // before delete() method call this
            $fasilitas->fasilitas_files()->each(function ($fasilitas_file) {
                $fasilitas_file->delete(); // <-- direct deletion
            });
            // do the rest of the cleanup...
        });
    }

}
