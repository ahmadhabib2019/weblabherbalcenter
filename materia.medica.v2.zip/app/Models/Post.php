<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Carbon;
use Illuminate\Support\Str;
use Storage;

/**
 * Class Post
 * @package App\Models
 * @version August 12, 2021, 7:04 am UTC
 *
 * @property string $title
 * @property string $slug
 * @property string $content
 * @property string $category
 * @property string $featured_image
 */
class Post extends Model
{
    use SoftDeletes;

    use HasFactory;

    public $table = 'posts';

    const CREATED_AT = 'created_at';
    const UPDATED_AT = 'updated_at';


    protected $dates = ['deleted_at'];



    public $fillable = [
        'title',
        'slug',
        'content',
        'category',
        'featured_image'
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'title' => 'string',
        'slug' => 'string',
        'content' => 'string',
        'category' => 'string',
        'featured_image' => 'string'
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'title' => 'required|string|max:255',
        'content' => 'required|string',
        'category' => 'required|string',
        'featured_image' => 'nullable|sometimes|image|mimes:jpeg,png|max:100000',
        'created_at' => 'nullable',
        'updated_at' => 'nullable'
    ];

    public function getCreatedAtAttribute($value)
    {
        return Carbon::parse($value)->format('d-M-Y H:i:s');
    }
    public function getUpdatedAtAttribute($value)
    {
        return Carbon::parse($value)->format('d-M-Y H:i:s');
    }

    /**
     * Get all of the postFiles for the Post
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function postFiles()
    {
        return $this->hasMany(PostFile::class, 'post_id');
    }
    public static function boot()
    {
        parent::boot();
        self::deleting(function ($post) { // before delete() method call this
            $post->postFiles()->each(function ($post_file) {
                $post_file->delete(); // <-- direct deletion
            });
            Storage::delete($post->featured_image);
            // do the rest of the cleanup...
        });
    }

    public function getAbbreviatedPostAttribute()
    {
        return Str::limit(strip_tags($this->content), 100, '...');
    }

    public function getFeaturedImageAttribute($value){
        if (!empty($value)) {
            return asset($value);
        }


    }

    public function getShortCreatedAtAttribute(){
         return Carbon::parse($this->crated_at)->format('d-M-Y');
    }
}
