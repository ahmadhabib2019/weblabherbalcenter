<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Model;

class InovasiFile extends Model
{
    use HasFactory;
    use SoftDeletes;

    public $table = 'inovasi_files';
    
    const CREATED_AT = 'created_at';
    const UPDATED_AT = 'updated_at';


    protected $dates = ['deleted_at'];



    public $fillable = [
        'inovasi_id',
        'url',
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'url' => 'string',
        'inovasi_id' => 'integer'
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'url' => 'required|string|max:191',
        'inovasi_id' => 'required',
        'created_at' => 'nullable',
        'updated_at' => 'nullable'
    ];
    public function inovasi()
    {
        return $this->belongsTo(\App\Models\Inovasi::class, 'inovasi_id');
    }

    public function getSrcAttribute($value)
    {
        return asset($value);
    }
}
