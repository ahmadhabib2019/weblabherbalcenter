<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

/**
 * Class ProdukKategori
 * @package App\Models
 * @version September 4, 2021, 7:12 pm WIB
 *
 * @property string $name
 */
class ProdukKategori extends Model
{
    use SoftDeletes;

    use HasFactory;

    public $table = 'produk_kategoris';
    

    protected $dates = ['deleted_at'];

    public $fillable = [
        'produk_id',
        'name'
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'name' => 'string',
        'produk_id'=>'string',
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        
    ];

    public function produk()
    {
        return $this->belongsTo(\App\Models\Produk::class,'produk_id');
    }

    public function produkOrder()
    {
        return $this->hasMany(\App\Models\ProdukOrder::class);
    }
    
}
