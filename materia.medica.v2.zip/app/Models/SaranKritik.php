<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

/**
 * Class SaranKritik
 * @package App\Models
 * @version September 26, 2021, 11:12 am WIB
 *
 * @property integer $user_id
 * @property string $saran
 * @property string $response_saran
 * @property string $kritik
 * @property string $response_kritik
 */
class SaranKritik extends Model
{
    use SoftDeletes;

    use HasFactory;

    public $table = 'saran_kritiks';
    

    protected $dates = ['deleted_at'];



    public $fillable = [
        'user_id',
        'saran',
        'response_saran',
        'kritik',
        'response_kritik'
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'user_id' => 'integer',
        'saran' => 'string',
        'response_saran' => 'string',
        'kritik' => 'string',
        'response_kritik' => 'string'
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'user_id' => 'required',
        'saran' => 'nullable',
        'response_saran' => 'nullable',
        'kritik' => 'nullable',
        'response_kritik' => 'nullable'
    ];

    public function user()
    {
        return $this->belongsTo(\App\Models\User::class, 'user_id');
    }
}
