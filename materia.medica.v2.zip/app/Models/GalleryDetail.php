<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

/**
 * Class GalleryDetail
 * @package App\Models
 * @version August 16, 2021, 7:58 am UTC
 *
 * @property \App\Models\Gallery $gallery
 * @property string $image_description
 * @property string $src
 * @property integer $gallery_id
 */
class GalleryDetail extends Model
{
    use SoftDeletes;

    use HasFactory;

    public $table = 'gallery_details';
    
    const CREATED_AT = 'created_at';
    const UPDATED_AT = 'updated_at';


    protected $dates = ['deleted_at'];



    public $fillable = [
        'src',
        'gallery_id'
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'image_description' => 'string',
        'src' => 'string',
        'gallery_id' => 'integer'
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'src' => 'required|string|max:191',
        'gallery_id' => 'required',
        'created_at' => 'nullable',
        'updated_at' => 'nullable'
    ];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function gallery()
    {
        return $this->belongsTo(\App\Models\Gallery::class, 'gallery_id');
    }

    public function getSrcAttribute($value)
    {
        return asset($value);
    }
}
