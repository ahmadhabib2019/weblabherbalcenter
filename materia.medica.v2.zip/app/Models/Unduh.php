<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

/**
 * Class Unduh
 * @package App\Models
 * @version September 15, 2021, 5:34 pm WIB
 *
 * @property string $title
 * @property string $description
 * @property string $url
 * @property string $file
 * @property integer $year
 */
class Unduh extends Model
{
    use SoftDeletes;

    use HasFactory;

    public $table = 'unduhs';
    

    protected $dates = ['deleted_at'];



    public $fillable = [
        'title',
        'description',
        'url',
        'file',
        'image',
        'category',
        'download',
        'year'
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'title' => 'string',
        'description' => 'string',
        'url' => 'string',
        'file' => 'string',
        'image' => 'string',
        'category' => 'string',
        'download' => 'integer',
        'year' => 'integer'
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'title' => 'required',
        'description' => 'nullable',
        'url' => 'nullable',
        'file' => 'nullable',
        'image' => 'nullable',
        'category' => 'nullable',
        'download' => 'nullable',
        'year' => 'nullable'
    ];

    
}
