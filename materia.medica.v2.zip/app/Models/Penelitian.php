<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

/**
 * Class Penelitian
 * @package App\Models
 * @version September 13, 2021, 4:38 pm WIB
 *
 * @property string $title
 * @property string $description
 * @property string $publication_link
 * @property string $file
 * @property string $download
 */
class Penelitian extends Model
{
    use SoftDeletes;

    use HasFactory;

    public $table = 'penelitians';
    

    protected $dates = ['deleted_at'];



    public $fillable = [
        'title',
        'description',
        'publication_link',
        'file',
        'images',
        'download',
        'year',
        'category',
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'title' => 'string',
        'description' => 'string',
        'publication_link' => 'string',
        'file' => 'string',
        'images' => 'string',
        'download' => 'string',
        'year' => 'integer'
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'title' => 'required',
        'year' => 'required',
        'images' => 'image|mimes:jpeg,png,jpg,gif,svg,JPG,PNG,JPEG|max:5000',
        'download' => 'nullable',
    ];

    public static function boot()
    {
        parent::boot();
        self::deleting(function ($penelitian) { // before delete() method call this
            $penelitian->each(function ($penelitian) {
                $penelitian->delete(); // <-- direct deletion
            });
            // do the rest of the cleanup...
        });
    }

    public function getImagesAttribute($value)
    {
        return asset($value);
    }

}