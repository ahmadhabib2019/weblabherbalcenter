<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

/**
 * Class FormRegistration
 * @package App\Models
 * @version September 6, 2021, 9:48 pm WIB
 *
 * @property \Illuminate\Database\Eloquent\Collection $formRegistrationContents
 * @property integer $service_id
 * @property string $kategori
 * @property string $name
 */
class FormRegistration extends Model
{
    use SoftDeletes;

    use HasFactory;

    public $table = 'form_registrations';

    const CREATED_AT = 'created_at';
    const UPDATED_AT = 'updated_at';
    const FORM_INDIVIDU = 'individu';
    const FORM_KELOMPOK = 'kelompok';
    const FORM_OPEN_CLASS = 'open_class';
    const FORM_CUSTOM_CLASS = 'custom_class';

    protected $dates = ['deleted_at'];



    public $fillable = [
        'service_id',
        'name',
        'options',
        'description',
        'date',
        'jam',
        'image',
        'price',
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'service_id' => 'integer',
        'kategori' => 'string',
        'name' => 'string',
        'options'=>'string',
        'description'=>'string',
        'date'=>'string',
        'jam'=>'string',
        'image'=>'string',
        'price'=>'string',
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'options'=>'required',
        'service_id' => 'required',
        'created_at' => 'nullable',
        'updated_at' => 'nullable',
        'name' => 'required|string|max:191',
        'deleted_at' => 'nullable',
        'description'=>'nullable',
        'date'=>'nullable',
        'jam'=>'nullable',
        'image'=>'nullable',
        'price'=>'nullable',
    ];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     **/
    public function formRegistrationContents()
    {
        return $this->hasMany(\App\Models\FormRegistrationContent::class);
    }

    public function service()
    {
        return $this->belongsTo(\App\Models\Service::class);
    }
}
