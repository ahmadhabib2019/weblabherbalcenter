<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

/**
 * Class FormRegistrationContent
 * @package App\Models
 * @version August 30, 2021, 8:11 pm WIB
 *
 * @property integer $form_registration_id
 * @property integer $question_id
 */
class FormRegistrationContent extends Model
{
    use SoftDeletes;

    use HasFactory;

    public $table = 'form_registration_contents';


    protected $dates = ['deleted_at'];



    public $fillable = [
        'form_registration_id',
        'question_id',
        'options'
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'form_registration_id' => 'integer',
        'question_id' => 'integer'
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'name' => 'required',
        'question_id' => 'required',
        'service_id'=>'required'
    ];


    public static $update_rules = [
        'name' => 'required',
        'service_id' => 'required',
        'old_question_id' => 'required_without:question_id',
        'question_id' => 'required_without:old_question_id'
    ];


    public function formRegistrasi()
    {
        return $this->belongsTo(\App\Models\FormRegistration::class, 'form_registration_id');
    }

    public function question()
    {
        return $this->belongsTo(\App\Models\Question::class);
    }

}
