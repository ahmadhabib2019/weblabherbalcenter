<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Carbon\Carbon;

/**
 * Class Gallery
 * @package App\Models
 * @version August 13, 2021, 1:19 pm UTC
 *
 * @property \Illuminate\Database\Eloquent\Collection $galleryDetails
 * @property string $title
 * @property string $description
 * @property string $category
 */
class Gallery extends Model
{
    use SoftDeletes;

    use HasFactory;

    public $table = 'galleries';

    const CREATED_AT = 'created_at';
    const UPDATED_AT = 'updated_at';


    protected $dates = ['deleted_at'];



    public $fillable = [
        'title',
        'description',
        'category',
        'tgl',
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'title' => 'string',
        'description' => 'string',
        'category' => 'string',
        'tgl' => 'string'
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'title' => 'required|string|max:191',
        'tgl' => 'nullable',
        'description' => 'nullable|string',
        'category' => 'required|string',
        'image' => 'min:1',
        'deleted_at' => 'nullable',
        'created_at' => 'nullable',
        'updated_at' => 'nullable'
    ];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     **/
    public function galleryDetails()
    {
        return $this->hasMany(\App\Models\GalleryDetail::class, 'gallery_id');
    }

    public function getCreatedAtAttribute($value)
    {
        return Carbon::parse($value)->format('d-M-Y H:i:s');
    }
    public function getUpdatedAtAttribute($value)
    {
        return Carbon::parse($value)->format('d-M-Y H:i:s');
    }

    public static function boot()
    {
        parent::boot();
        self::deleting(function ($gallery) { // before delete() method call this
            $gallery->galleryDetails()->each(function ($gallery_details) {
                $gallery_details->delete(); // <-- direct deletion
            });
            // do the rest of the cleanup...
        });
    }
}
