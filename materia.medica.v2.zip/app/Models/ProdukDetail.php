<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Produk;

class ProdukDetail extends Model
{
    use HasFactory;

    public $table = 'produk_details';

    const CREATED_AT = 'created_at';
    const UPDATED_AT = 'updated_at';

    protected $dates = ['deleted_at'];

    public $fillable = [
        'produk_id',
        'nama_latin',
        'berat',
        'pemerian',
        'keunggulan',
        'isipaket',
        'deskripsipaket',
        'nama_daerah',
        'bagian_tanaman',
        'organoleptis',
        'manfaat',
        'cara_penggunaan',
        'famili',
        'kandungan',
        'morfologi',

    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'produk_id'=>'integer',
        'nama_lokal'=>'string',
        'nama_latin'=>'string',
        'berat'=>'string',
        'pemerian'=>'string',
        'keunggulan'=>'string',
        'isipaket'=>'string',
        'deskripsipaket'=>'string',
        'nama_daerah'=>'string',
        'bagian_tanaman'=>'string',
        'organoleptis'=>'string',
        'manfaat'=>'string',
        'cara_penggunaan'=>'string',
        'famili'=>'string',
        'kandungan'=>'string',
        'morfologi'=>'string',
    ];

    /**
     * Validation rules
     *
     * @var array
     */
   
    public function produk()
    {
        return $this->belongsTo(Produk::class, 'produk_id');
    }
}
