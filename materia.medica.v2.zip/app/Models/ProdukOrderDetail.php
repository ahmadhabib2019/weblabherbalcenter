<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

/**
 * Class ProdukOrder
 * @package App\Models
 * @version September 11, 2021, 8:21 am WIB
 *
 * @property integert $user_id
 * @property integer $produk_id
 * @property integer $kategori_id
 * @property string $kode_trans
 * @property integer $qty
 * @property string $total
 */
class ProdukOrderDetail extends Model
{
    use SoftDeletes;

    use HasFactory;

    public $table = 'produk_order_detail';
    

    protected $dates = ['deleted_at'];



    public $fillable = [
        'order_id',
        'user_id',
        'produk_id',
        'kategori_id',
        'qty',
        'total'
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'order_id' => 'integer',
        'produk_id' => 'integer',
        'kategori_id' => 'integer',
        'qty' => 'integer',
        'total' => 'string'
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'order_id' => 'required',
        'produk_id' => 'required',
        'kategori_id' => 'required',
        'qty' => 'required',
        'total' => 'required',
    ];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     **/
    public function produk()
    {
        return $this->belongsTo(\App\Models\Produk::class,'produk_id');
    }
    public function kategori()
    {
        return $this->belongsTo(\App\Models\ProdukKategori::class, 'kategori_id');
    }

}
