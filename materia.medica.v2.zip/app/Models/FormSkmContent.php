<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

/**
 * Class FormSkm
 * @package App\Models
 * @version September 26, 2021, 3:10 pm WIB
 *
 * @property integer $service_id
 * @property integer $question_skm_id
 */
class FormSkmContent extends Model
{
    use SoftDeletes;

    use HasFactory;

    public $table = 'form_skm_content';
    

    protected $dates = ['deleted_at'];



    public $fillable = [
        'form_skm_id',
        'question_skm_id',
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'form_skm_id' => 'integer',
        'question_skm_id' => 'integer',
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'form_skm_id' => 'integer',
        'question_skm_id' => 'required',
    ];

    public function formSkm()
    {
        return $this->belongsTo(\App\Models\FormSkm::class);
    }

    public function questionSkm()
    {
        return $this->belongsTo(\App\Models\QuestionSkm::class);
    }
}
