<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

/**
 * Class Carousel
 * @package App\Models
 * @version August 13, 2021, 7:54 am UTC
 *
 * @property string $title
 * @property string $description
 * @property string $image_url
 * @property string $link_url
 * @property boolean $is_active
 */
class Carousel extends Model
{
    use SoftDeletes;

    use HasFactory;

    public $table = 'carousel';
    
    const CREATED_AT = 'created_at';
    const UPDATED_AT = 'updated_at';


    protected $dates = ['deleted_at'];



    public $fillable = [
        'title',
        'description',
        'image_url',
        'link_url',
        'is_active'
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'title' => 'string',
        'description' => 'string',
        'image_url' => 'string',
        'link_url' => 'string',
        'is_active' => 'boolean'
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'title' => 'required|string|max:191',
        'description' => 'nullable|string',
        'image_url' => 'image|mimes:jpg,png,jpeg,gif,svg|max:2000',
        'link_url' => 'nullable|string|max:191',
        'is_active' => 'required|boolean',
        'deleted_at' => 'nullable',
        'created_at' => 'nullable',
        'updated_at' => 'nullable'
    ];

    
}
