<?php

namespace App\Providers;

use Illuminate\Routing\UrlGenerator;
use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Schema;
use Illuminate\Contracts\View\View;
use App\Models\Menu;
use App\Models\Post;
use App\Models\WebSetting;
use App\Models\Visitor;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        if(config('app.env')=='local' ){
         $this->app['request']->server->set('HTTPS', true);
        }
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot(UrlGenerator $url)
    {
        Schema::defaultStringLength(191);
        if(config('app.env')=='local' ){
            $url->forceScheme('https');
        }
         $this->menu_view();
         $this->websetting_view();
    }

    private function menu_view(){
        view()->composer('*',function(View $view){
        $menu = Menu::all();
        $view->with('menu',$menu);
        });
    }

    private function websetting_view(){
        view()->composer('*',function(View $view){
            $news = Post::where('category','berita')->orderBy('created_at','desc')->take(3)->get();
            $sides = Post::where('category','berita')->orderBy('created_at', 'desc')->take(5)->get();
            $websetting = WebSetting::all();
            $visitorD = Visitor::where('date','=', today())->count();
            $visitorY = Visitor::whereYear('date', now()->toDateString('Y'))->count();
            $sinceyear = Visitor::whereYear('date','>=','2021')->count();
            $isonline = Visitor::where('created_at', '>',Carbon::now()->subHours(1)->toDateTimeString())->count();
            $view->with('websetting', $websetting);
            $view->with('news', $news);
            $view->with('isonline', $isonline);
            $view->with('visitorD', $visitorD);
            $view->with('visitorY', $visitorY);
            $view->with('sides', $sides);
            $view->with('sinceyear', $sinceyear);
        });
    }
}
