<?php

namespace App\Exports;

use App\Models\SaranKritik as Saran;
use Maatwebsite\Excel\Concerns\FromCollection;
use Illuminate\Http\Request;
use Illuminate\Contracts\View\View;
use Maatwebsite\Excel\Excel;
use Maatwebsite\Excel\Concerns\FromView;

class SaranExport implements FromView
{
    /**
    * @return \Illuminate\Support\Collection
    */
   function __construct(Request $request) {
        $this->tanggal = $request->tanggal;
    }
    public function view(): View
    {                
        return view('/saran_kritiks/export', [
            'data' => Saran::whereMonth('created_at', substr($this->tanggal,0,2))->whereYear('created_at',substr($this->tanggal,3,7))->get(),
            'tanggal' => $this->tanggal,
        ]);
    }
}
