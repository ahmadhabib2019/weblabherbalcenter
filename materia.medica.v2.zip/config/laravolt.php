<?php

return [
    'indonesia' => [
        'table_prefix' => 'id_',
    ],
];