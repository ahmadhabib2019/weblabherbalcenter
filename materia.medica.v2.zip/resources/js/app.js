import './bootstrap';
import 'bs-custom-file-input';
import 'bootstrap4-toggle';
import 'admin-lte';
import 'icheck-bootstrap';
import 'select2';
import 'eonasdan-bootstrap-datetimepicker';
import 'bootstrap-switch';