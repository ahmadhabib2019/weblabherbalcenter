<!-- Title Field -->
<div class="form-group col-sm-6">
    {!! Form::label('title', 'Title:') !!}
    {!! Form::text('title', null, ['class' => 'form-control', 'maxlength' => 191, 'maxlength' => 191]) !!}
</div>


<!-- Description Field -->
<div class="form-group col-sm-12 col-lg-12 editor-area">
    {!! Form::label('description', 'Description:') !!}
    <div id="editor" style="min-height:200px;">
        @if (!empty($carousel)){!! $carousel->description !!}@endif {!! old('description')  !!}
    </div>
    {!! Form::textarea('description', null, ['class' => 'form-control', 'id' => 'editor_content', 'style' => 'display:none']) !!}
</div>

<!-- Image Url Field -->
<div class="form-group col-sm-12">
    {!! Form::label('image_url', 'Image Url:') !!}
    {!! Form::file('image_url', null, ['class' => 'form-control', 'maxlength' => 191, 'maxlength' => 191]) !!}
    <div>
        @if (isset($carousel->image_url))
            <img src="{{ asset($carousel->image_url) }}" class="img-fluid img-medium">
        @endif
    </div>
</div>

<!-- Link Url Field -->
<!-- <div class="form-group col-sm-12">
    {!! Form::label('link_url', 'Link Url:') !!}
    {!! Form::text('link_url', null, ['class' => 'form-control', 'maxlength' => 191, 'maxlength' => 191]) !!}
</div> -->

<!-- Is Active Field -->
<div class="form-group col-sm-6">
    <div class="form-check">
        {!! Form::hidden('is_active', 0, ['class' => 'form-check-input']) !!}
        {!! Form::checkbox('is_active', '1', null, ['class' => 'form-check-input']) !!}
        {!! Form::label('is_active', 'Is Active', ['class' => 'form-check-label']) !!}
    </div>
</div>
