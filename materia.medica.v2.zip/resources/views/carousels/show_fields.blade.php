<!-- Title Field -->
<div class="col-sm-12">
    {!! Form::label('title', 'Title:') !!}
    <p>{{ $carousel->title }}</p>
</div>

<!-- Description Field -->
<div class="col-sm-12">
    {!! Form::label('description', 'Description:') !!}
    <p>{!! $carousel->description !!}</p>
</div>

<!-- Image Url Field -->
<div class="col-sm-12">
    {!! Form::label('image_url', 'Image Url:') !!}
    <p> <img class="img-fluid img-medium" src="{{ asset($carousel->image_url) }}"/></p>
</div>

<!-- Link Url Field -->
<!-- <div class="col-sm-12">
    {!! Form::label('link_url', 'Link Url:') !!}
    <p>{{ $carousel->link_url }}</p>
</div> -->

<!-- Is Active Field -->
<div class="col-sm-12">
    {!! Form::label('is_active', 'Is Active:') !!}
    <p>{{ $carousel->is_active }}</p>
</div>

