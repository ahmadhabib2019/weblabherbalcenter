<x-layout>
    <x-slot name="title">Homepage</x-slot>
    <x-loader />
    <!-- Main Wrapper -->
    <div id="main-wrapper">
        <x-header-top />
        <x-header />
        <!-- Post Section Start -->
        <div class="post-section section">
            <div class="container">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-md-10" style="margin-top: 2%">
                            <div class="alert alert-primary" role="alert">
                                <h3 class="box-title" style="padding: 2%">Verify Your Email Address</h3>

                                <div class="box-body">
                                    @if (session('resent'))
                                        <div class="alert alert-success" role="alert">
                                            A fresh verification link has been sent to your email address
                                        </div>
                                    @endif
                                    <p>
                                        Before proceeding, please check your email for a verification link.If you did
                                        not receive the email,
                                    </p>
                                    <form action="{{ route('verification.resend') }}" method="post">
                                        @csrf
                                        <button class="btn btn-sm btn-info type=" submit">Request a new link</button>
                                    </form>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <x-footer :websetting="$websetting" />
        </div>
    </div>
    <style>
        .box {
            background-color: #40bff5;
            min-height: 10rem;
            margin-bottom: 15px;
        }

    </style>
</x-layout>
