<!-- Hero Section Start -->
<div class="hero-section section mt-30 mb-30">
    <div class="container">
        <div class="row">
            <div class="col">
                <div class="row row-1">
                    <div class="order-lg-2 col-lg-12 col-12"
                        <!-- Hero Post Slider Start -->
                        <div class="post-carousel-1">
                            @foreach ($carousels as $carousel)
                                <!-- Overlay Post Start -->
                                <div class="post post-overlay hero-post">
                                    <div class="post-wrap">
                                        <!-- Image -->
                                        <a class="image" href="{{ asset($carousel->image_url) }}"><img alt="tes" src="{{ asset($carousel->image_url) }}">
                                        </a>
                                        <!-- Category -->
                                        <a href="#" class="category politic">{{ $carousel->title  }}</a>
                                        <!-- Content -->
                                        <div class="post-content">
                                            <!-- Title -->
                                        <h2 class="title"><a href="post-details.html">{!! Str::substr($carousel->description, 0, 100); !!}</a></h2>
                                            <!-- Meta -->
                                            
                                        </div>
                                    </div>
                                </div><!-- Overlay Post End -->
                            @endforeach
                        </div><!-- Hero Post Slider End -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><!-- Hero Section End -->
