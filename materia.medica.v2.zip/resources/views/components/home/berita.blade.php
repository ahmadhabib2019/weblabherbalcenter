<div class="post feature-post post-separator-border mb-15">
    <div class="post-wrap">
        <a class="image" href="{{  route('frontend.post.show',[$berita->slug,$berita->id])  }}" style="min-height: 150px"> <img src="{{ $berita->featured_image ? $berita->featured_image : asset('frontend/img/logo.png')  }}" alt="post"
                class="img-fluid"></a>
        <!-- Content -->
        <div class="post-content">
            <!-- Title -->
            <h4 class="title" style="min-height: 50px"><a
                href="{{ route('frontend.post.show', [$berita->slug, $berita->id]) }}">{{ Str::limit($berita->title,45)  }}
            </h4></a>

            <!-- Meta -->
            <div class="meta fix">
                <!-- <a href="#" class="meta-item author"><i class="fa fa-user"></i>Sathi Bhuiyan</a> -->
                <span class="meta-item date"><i class="fa fa-clock-o"></i> {{ date('d-m-Y', strtotime($berita->created_at)) }}</span>
            </div>
            <!-- Description -->
        </div>
    </div>
    <hr>
</div><!-- Post End -->
