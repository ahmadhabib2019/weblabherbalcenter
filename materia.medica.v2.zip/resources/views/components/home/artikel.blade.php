
<div class="post feature-post post-separator-border">
    <div class="post-wrap">
        <a class="image" href="{{  route('frontend.post.show',[$artikel->slug,$artikel->id])  }}" style="min-height: 150px">
            <img src="{{ $artikel->featured_image ? $artikel->featured_image : asset('frontend/img/logo.png')  }}" width="200" height="180" alt="post" class="img-fluid">
        </a>

        <div class="post-content">
        <h4 class="title" style="min-height: 50px"><a href="{{  route('frontend.post.show',[$artikel->slug,$artikel->id])  }}">{{ Str::limit($artikel->title,45)  }}</h4></a>
            <div class="meta fix">
                <!-- <a href="#" class="meta-item author"><i class="fa fa-user"></i>Sathi Bhuiyan</a> -->
                <span class="meta-item date"><i class="fa fa-clock-o"></i> {{ date('d-m-Y', strtotime($artikel->created_at)) }}</span>
            </div>

        </div>
    </div>
</div>
<hr>
