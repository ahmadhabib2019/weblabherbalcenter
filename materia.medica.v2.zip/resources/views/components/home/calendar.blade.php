<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
    <ol class="carousel-indicators">
        <li style="color: red" data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
        <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
        <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
    </ol>
    <a href="{{ route('frontend.post','kalender-kegiatan')}}">
        <div class="carousel-inner">
            @foreach ($calendar as $item)
                <div class="carousel-item {{ $loop->first ? "active" :""  }}">
                <div class="container">
                    <div class="row">
                        <div class="col-2 text-right">
                            <h3 class="display-5"><span class="badge badge-secondary">{{Carbon\Carbon::parse( $item->start)->format('d') }}</span></h3>
                            <h4>{{ Carbon\Carbon::parse($item->start)->format('M')}}</h4>
                        </div>
                        <div class="col-10">
                            <h5 class="text-uppercase"><strong>{{ $item->title  }}</strong></h5>
                            <ul class="list-inline">
                                <li class="list-inline-item"><i class="fa fa-clock-o" aria-hidden="true"></i> {{ Carbon\Carbon::parse($item->start)->format('h-i')  }} - {{ Carbon\Carbon::parse($item->finish)->format('h-i')  }}</li>
                                <li class="list-inline-item"><i class="fa fa-location-arrow" aria-hidden="true"></i> {{ $item->location  }}
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            @endforeach
        </div>
    </a>
</div>
<style>
    .carousel-indicators {
        position: absolute;
        margin-bottom: -25px;
    }

    .badge{
        width:40px;
    }
    .carousel-indicators li {
        background-color: #40bff5 !important;
    }

</style>
