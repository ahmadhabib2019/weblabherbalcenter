<div class="container">

    <!--Carousel Wrapper-->
    <div id="carousel-example-2" class="carousel slide carousel-fade" data-ride="carousel">
        <!--Indicators-->
        {{--<ol class="carousel-indicators">
            <li data-target="#carousel-example-2" data-slide-to="0" class="active"></li>
            <li data-target="#carousel-example-2" data-slide-to="1"></li>
            <li data-target="#carousel-example-2" data-slide-to="2"></li>
        </ol>--}}
        <!--/.Indicators-->
        <!--Slides-->
        <div class="carousel-inner" role="">
            <div class="carousel-item active">
                <div class="view " style="height:400px">
                @foreach($openClass as $data)
                    <center>
                        <a class="image"data-toggle="lightbox" data-gallery="gallery"  href="{{ asset($data->image) }}">
                            @isset($openClass)
                                <img class="d-block" src="{{ $data->image ? $data->image : asset('frontend/img/logo.png')}}" style="height:400px">
                            @else
                                <img class="d-block" src="{{ asset('frontend/img/logo.png')}}" style="height:400px">
                            @endif
                        </a>
                    </center>
                @endforeach
                </div>
                <div class="carousel-caption">
                </div>
            </div>
        </div>
        <!--/.Slides-->
        <!--Controls-->
        {{--<a class="carousel-control-prev" href="#carousel-example-2" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carousel-example-2" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>--}}
        <!--/.Controls-->
    </div>
    <!--/.Carousel Wrapper-->

</div>
@push('styles')
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ekko-lightbox/5.3.0/ekko-lightbox.css" integrity="sha512-Velp0ebMKjcd9RiCoaHhLXkR1sFoCCWXNp6w4zj1hfMifYB5441C+sKeBl/T/Ka6NjBiRfBBQRaQq65ekYz3UQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
@endpush

@push('scripts')
    <script src="https://cdnjs.cloudflare.com/ajax/libs/ekko-lightbox/5.3.0/ekko-lightbox.min.js" integrity="sha512-Y2IiVZeaBwXG1wSV7f13plqlmFOx8MdjuHyYFVoYzhyRr3nH/NMDjTBSswijzADdNzMyWNetbLMfOpIPl6Cv9g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <script>
        $(document).on("click", '[data-toggle="lightbox"]', function(event) {
            event.preventDefault();
            $(this).ekkoLightbox();
        });
    </script>
@endpush