<div class="blog-section section">
    <div class="container">

        <!-- Feature Post Row Start -->
        <div class="row">
                <x-search.content-section
                    :posts="$posts"
                    :fasilitas="$fasilitas"
                    :inovasi="$inovasi"
                    :penelitian="$penelitian"
                    :products="$products"
                    :services="$services"
                    :galleries="$galleries"
                 />
                <x-article.sidebar-section />
        </div><!-- Feature Post Row End -->

    </div>
</div>
