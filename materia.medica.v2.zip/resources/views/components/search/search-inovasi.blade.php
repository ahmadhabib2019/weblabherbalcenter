@if (count($inovasi) > 0)
    @foreach ($inovasi as $post)
        <!-- Post Start -->
        <div class="post fashion-post post-default-list post-separator-border">
            <div class="post-wrap">

                <!-- Content -->
                <div class="post-content">

                    <!-- Title -->
                    <h4 class="title"><a
                            href="{{ route('frontend.inovasi.show', ['id' => $post->id]) }}">{{ $post->title }}</a>
                    </h4>

                    <!-- Meta -->
                    <div class="meta fix">
                        <a href="#" class="meta-item author"><i class="fa fa-user"></i> Materia
                            Medica </a>
                        <span class="meta-item date"> <i class="fa fa-calendar"></i>
                            {{ $post->created_at }}</span>
                    </div>

                    <!-- Description -->
                    {!! Str::substr($post->description, 0, 200) !!}

                    <!-- Read More -->
                    <a href="{{ route('frontend.inovasi.show', ['id' => $post->id]) }}"
                        class="read-more">continue reading</a>

                </div>

            </div>
        </div><!-- Post End -->
    @endforeach
@else
@endif
