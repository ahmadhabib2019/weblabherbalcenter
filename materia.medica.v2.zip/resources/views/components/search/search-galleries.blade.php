@if (count($galleries) > 0)
   @foreach ($galleries as $gallerie)
      <!-- Post Start -->
      <div class="post fashion-post post-default-list post-separator-border">
         <div class="post-wrap">

               <!-- Content -->
               <div class="post-content">

                  <!-- Title -->
                  <h4 class="title">
                  </h4>

                  @foreach ($galleries as $item)
                     @if($item->category == 'tanaman-obat')
                        @php
                           $detail = \DB::table('gallery_details')->where('gallery_id', $item->id)->count();
                        @endphp

                        @if($detail <= 1)
                           @php
                              $d = \App\Models\GalleryDetail::where('gallery_id', $item->id)->first();
                           @endphp
                  
                           <div class="post sports-post post-separator-border col-12">
                              <div class="post-wrap">
                                    <a class="thumbnail image" data-toggle="lightbox" data-gallery="gallery"
                                       href="{{ asset($d->src) }}">
                                       <img class="img-thumbnail" src="{{ asset($d->src) }}"
                                          alt="{{ $d->gallery->title }}">
                                    </a>
                                    <div >
                                       <a>{{ $d->gallery->title }}</a>
                                    </div>
                              </div>
                           </div>
                        @else
                           <div class="post sports-post post-separator-border col-12">
                              <div class="post-wrap">
                                    <a class="image" href="{{ route('frontend.gallery.show',$item['id']) }}">
                                       <img class="img-thumbnail" src="{{ asset($item['galleryDetails'][0]['src']) }}"
                                          alt="Another alt text">
                                    </a>
                                    <div >
                                       <a class="title">{{ $item->title }}</a>
                                    </div>
                              </div>
                           </div>
                        @endIf
                     @else
                        <div class="post sports-post post-separator-border col-12">
                           <div class="post-wrap">
                              <a class="image" href="{{ route('frontend.gallery.show',$item['id']) }}">
                                    <img class="img-thumbnail" src="{{ asset($item['galleryDetails'][0]['src']) }}"
                                       alt="Another alt text">
                              </a>
                              <div >
                                    <a class="title">{{ $item->title }}</a>
                              </div>
                           </div>
                        </div>
                     @endIf
                  @endforeach

               </div>

         </div>
      </div><!-- Post End -->
   @endforeach
@else
@endif