<div class="col-lg-8 col-12 mb-50">

    <!-- Post Block Wrapper Start -->
    <div class="post-block-wrapper">

        <!-- Post Block Body Start -->
        <div class="body">
            <h2>Search {{ request()->get('param') }}</h2>
            <x-search.search-post :posts="$posts" />
            <x-search.search-fasilitas :fasilitas="$fasilitas" />
            <x-search.search-penelitian :penelitian="$penelitian" />
            <x-search.search-inovasi :inovasi="$inovasi" />
            <x-search.search-products :products="$products" />
            <x-search.search-services :services="$services" />
            <x-search.search-galleries :galleries="$galleries" />
            <div class="d-flex">
                <div class="mx-auto">
                    {{ $posts->links() }}
                </div>
            </div>

</div>
</div>
</div>
