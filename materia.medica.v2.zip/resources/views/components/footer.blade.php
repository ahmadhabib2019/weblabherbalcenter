<div class="footer-top-section section bg-dark">
    <div class="container-fluid">
        <div class="row">
            <div class="footer-widget col-xl-4 col-md-6 col-12 mb-60">
                <h4 class="widget-title">Kontak Kami</h4>
                
                <div class="footer-widget-post">
                    <h4 style="color:#DFDEDE">Alamat</h4>
                    @foreach ($websetting as $item)
                        @if ($item->name == 'alamat_1' || $item->name == 'alamat_2' || $item->name == 'alamat_3')
                            <div class="post-wrap">
                                <a style="color:#DFDEDE" href="{{ $item->url }}">
                                    <i class="fa fa-map-marker fa-fw"></i> {{ $item->value }}
                                </a>
                            </div>
                        @endif
                    @endforeach
                </div>
                
                <div class="footer-widget-post">
                    <h4 style="color:#DFDEDE">Jam Operasional</h4>
                    @foreach ($websetting as $item)
                        @if ($item->name == 'jadwal_1')
                            <div class="post-wrap">
                                <p style="color:#DFDEDE">
                                    <i class="fa fa-clock-o fa-fw"></i> Senin – Kamis : pukul {{ $item->value }} WIB.
                                </p>
                            </div>
                        @elseif ($item->name == 'jadwal_2')
                            <div class="post-wrap">
                                <p style="color:#DFDEDE">
                                    <i class="fa fa-clock-o fa-fw"></i> Jumat : pukul {{ $item->value }} WIB.
                                </p>
                            </div>
                        @endif
                    @endforeach
                </div>
                
                <div class="footer-widget-post">
                    @foreach ($websetting as $item)
                        @if ($item->name == 'phone')
                            <div class="post-wrap">
                                <p style="color:#DFDEDE"> <i class="fa fa-phone  fa-fw"></i> {{ $item->value }}</p>
                            </div>
                        @elseif ($item->name =='email')
                            <div class="post-wrap">
                                <p style="color:#DFDEDE">
                                    <i class="fa fa-envelope-o fa-fw"></i> {{ $item->value }}
                                </p>
                            </div>
                        @elseif ($item->name =='facebook')
                            <div class="post-wrap">
                                <a style="color:#DFDEDE"
                                    href="{{ $item->url  }}">
                                    <i class="fa fa-facebook fa-fw"></i> {{ $item->value  }}
                                </a>
                            </div>
                        @elseif ($item->name =='instagram')
                            <div class="post-wrap">
                                <a style="color:#DFDEDE" href="{{ $item->url  }}">
                                    <i class="fa fa-instagram fa-fw"></i> {{ $item->value  }}
                                </a>
                            </div>
                        @elseif ($item->name =='youtube')
                            <div class="post-wrap">
                                <a style="color:#DFDEDE" href="{{ $item->url  }}">
                                    <i class="fa fa-youtube fa-fw"></i> {{ $item->value }}
                                </a>
                            </div>
                        @endif
                    @endforeach
                </div>
            </div>

            <div class="footer-widget col-xl-4 col-md-6 col-12 mb-60">
                <h4 class="widget-title">Statistik Pengunjung</h4>
                <div class="post-wrap">
                    <a style="color:#DFDEDE">
                        <i class="fa fa-user fa-fw"></i> {{ $isonline }} <b>User</b>
                    </a>
                </div>
                    <div class="post-wrap" style="padding-left:25px">
                        <a style="color:#DFDEDE">Sedang Online Hari Ini</a>
                    </div>
                <div class="post-wrap">
                    <a style="color:#DFDEDE">
                        <i class="fa fa-users fa-fw"></i> {{ $visitorD }} <b>User</b>
                    </a>
                </div>
                    <div class="post-wrap" style="padding-left:25px">
                        <a style="color:#DFDEDE">Pengunjung Hari Ini</a>
                    </div>
                <div class="post-wrap">
                    <a style="color:#DFDEDE">
                        <i class="fa fa-users fa-fw"></i> {{ $visitorY }} <b>User</b>
                    </a>
                </div>
                    <div class="post-wrap" style="padding-left:25px">
                        <a style="color:#DFDEDE">Total Pengunjung Tahun {{ now()->Format('Y')}}</a>
                    </div>
                <div class="post-wrap">
                    <a style="color:#DFDEDE">
                        <i class="fa fa-users fa-fw"></i> {{ $sinceyear }} <b>User</b>
                    </a>
                </div>
                    <div class="post-wrap" style="padding-left:25px">
                        <a style="color:#DFDEDE">Total Pengunjung Sejak Tahun 2021</a>
                    </div>
            </div>

            <div class="footer-widget col-xl-4 col-md-6 col-12 mb-60">
                <h4 class="widget-title">Video Kami</h4>
                {{--@for ($i = 0; $i <= 3; $i++)--}}
                    <x-footer-list />
                {{--@endfor--}}
            </div>
        </div>
    </div>
</div>

<div class="footer-bottom-section section bg-dark">
    <div class="container">
        <div class="row">
            <div class="copyright text-center col">
                <p>@ {{ \Carbon\Carbon::now()->format('Y') }} UPT LABORATORIUM HERBAL MATERIA MEDICA BATU</p>
            </div>
        </div>
    </div>
</div>