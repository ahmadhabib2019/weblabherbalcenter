<div class="blog-section section">
    <div class="container">
        
        <!-- Feature Post Row Start -->
        <div class="row">
            
            <x-gallery.content-section :galleries='$galleries' :judul='$judul'/>
            <x-article.sidebar-section/>
        </div><!-- Feature Post Row End -->
        
    </div>
</div>