<!-- Footer Widget Post Start -->
<div class="footer-widget-post">
    <div class="post-wrap">
        <div class="embed-responsive embed-responsive-16by9">
            <iframe src="https://www.youtube.com/embed/5c1RNbySJGE" loading="lazy" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        </div> 

        <div class="content" style="margin-top: 10px">
            <h4 class="title"><a href="#">Video Profil UPT Lab. Herbal Materia Medica</a></h4>
            <div class="meta fix">
                <span class="meta-item date"></span>
            </div>
        </div>
    </div>
</div>