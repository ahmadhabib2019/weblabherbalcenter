<!-- Post Block Wrapper Start -->
<div class="col-md-2">
    
</div>

<div class="col-lg-8 col-12 mb-50">
    <div class="post-block-wrapper">
        <!-- Post Block Head Start -->
        @if ($message = Session::get('info'))
        <div class="alert alert-success alert-block" style="margin-top:10px ">
            <button type="button" class="close" data-dismiss="alert">×</button>    
            <strong>{{ $message }}</strong>
        </div>
        @endif
        <div class="head d-flex justify-content-center">
            <!-- Title -->
            <h4 class="title">Form Pengaduan</h4>
        </div><!-- Post Block Head End -->
        <!-- Post Block Body Start -->
        <div class="body" >
            <div class="post-comment-form">
                {!! Form::open(['route' => ['frontend.pengaduan.store'], 'files'=>true,'method'=>'post']) !!}
        
                        {{-- {!! Form::label('', 'Identitas Terlapor:') !!}

                        <div class="form-group col-sm-12">
                            {!! Form::label('nama', 'Nama:') !!}
                            {!! Form::text('nama', null, ['class' => 'form-control','style'=>'background:#F8F8F8']) !!}
                        </div>

                        <!-- Instansi Field -->
                        <div class="form-group col-sm-12">
                            {!! Form::label('instansi', 'Instansi:') !!}
                            {!! Form::text('instansi', null, ['class' => 'form-control','style'=>'background:#F8F8F8']) !!}
                        </div>

                        <!-- Alamat Field -->
                        <div class="form-group col-sm-12 col-lg-12">
                            {!! Form::label('alamat', 'Alamat:') !!}
                            {!! Form::textarea('alamat', null, ['class' => 'form-control','style'=>'background:#F8F8F8']) !!}
                        </div>

                        <div class="form-group col-sm-12">
                            {!! Form::label('phone', 'No HP:') !!}
                            {!! Form::number('phone', null, ['class' => 'form-control','style'=>'background:#F8F8F8']) !!}
                        </div>

                        <div class="form-group col-sm-12">
                            {!! Form::label('email', 'Email:') !!}
                            {!! Form::email('email', null, ['class' => 'form-control','style'=>'background:#F8F8F8']) !!}
                        </div> --}}
                        <div class="form-group">
                            <div class="input-group">
                                <input type="date" name="tanngal_lahir" id="datetimepicker" class="form-control"
                                    placeholder="Tanggal lahir*" required="required" />
                                <div class="input-group-append">
                                    <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                </div>
                            </div>
                        </div>
                        <!-- Kronologi Field -->
                        <div class="form-group col-sm-12 col-lg-12">
                            {!! Form::label('kronologi', 'Kronologi:') !!}
                            {!! Form::textarea('kronologi', null, ['class' => 'form-control','style'=>'background:#F8F8F8']) !!}
                        </div>

                        <!-- Waktu Field -->
                        <div class="form-group col-sm-12">
                            {!! Form::label('waktu', 'Waktu:') !!}
                            {!! Form::text('waktu', null, ['class' => 'form-control','style'=>'background:#F8F8F8']) !!}
                        </div>

                        <!-- File Field -->
                        <div class="form-group col-sm-12">
                            {!! Form::label('file', 'Dokumen Pendukung:') !!}
                            {!! Form::file('file', null, ['class' => 'form-control','style'=>'background:#F8F8F8']) !!}
                        </div>

                        <!-- User Id Field -->
                            <input style="display:none" name="user_id" type="text" value="{{ auth()->user()->id }}">
                    <div class="col-12">
                        <input type="submit" value="Submit">
                    </div>
                {!! Form::close() !!}
            </div>
        </div><!-- Post Block Body End -->
    </div><!-- Post Block Wrapper End -->
</div>
{{-- @push('scripts')

<script src="{{ asset('js/app.js') }}"></script>
<script type="text/javascript">
    $(function() {
        $('#datetimepicker').datetimepicker({
            sideBySide: true,
            format: 'YYYY-MM-DD',
            icons: {
                next: 'fa fa-angle-right',
                previous: 'fa fa-angle-left'
            },
        });
    });
</script>
@endpush --}}