<div class="blog-section section">
    <div class="container">

        <!-- Feature Post Row Start -->
        <div class="row">
            <x-pengaduan.index-section />
        </div><!-- Feature Post Row End -->

    </div>
</div>
