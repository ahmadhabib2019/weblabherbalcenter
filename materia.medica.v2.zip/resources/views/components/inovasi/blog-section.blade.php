<div class="blog-section section">
    <div class="container">

        <!-- Feature Post Row Start -->
        <div class="row">
            @isset($inovasi)
                <x-inovasi.index-section :inovasi="$inovasi"/>
            @else
                <x-inovasi.show-section :detailInovasi="$detailInovasi"/>
            @endisset
        </div><!-- Feature Post Row End -->

    </div>
</div>
