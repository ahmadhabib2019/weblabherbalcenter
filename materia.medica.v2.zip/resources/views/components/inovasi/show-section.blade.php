<div class="col-lg-5 col-12 mb-50">

    <!-- Post Block Wrapper Start -->
    <div class="post-block-wrapper">

        <!-- Post Block Body Start -->
        <div class="body">
                <!-- Post Start -->
                <div class="post fashion-post post-default-list post-separator-border">
                    <div class="post-wrap">
                        <!-- Content -->
                        <div class="post-content">

                            <!-- Title -->
                            <h3 ><a  href="#">Detail Inovasi</a> </h3>
                            <div>
                                <p ><a  href="#">Judul : </a> </p>
                                <p>{!! $detailInovasi->title !!}</p>
                            </div>
                            <div>
                                <p ><a  href="#">Description : </a> </p>
                                <p>{!! $detailInovasi->description !!}</p>
                            </div>

                            <!-- Meta -->
                            <div class="meta fix">
                                <a href="#" class="meta-item author"></i>  Tahun </a>
                                <span class="meta-item date">:</span>
                                <span class="meta-item date">{{ $detailInovasi->year}}</span>
                            </div>

                            <!-- Description -->

                        </div>

                    </div>
                </div><!-- Post End -->
            <div class="d-flex">
                <div>
                        <a href="{{ route('welcome') }}"class="btn btn-danger btn-sm">Kembali</a>
                </div>
            </div>

        </div>
    </div>
</div>
<!-- Sidebar Start -->
<div class="col-lg-7 col-12 mb-50">

<div class="post-block-wrapper">
        <div class="body">
            <div class="row">
                @foreach ($detailInovasi->inovasiFile as $item)
                    <div class="post sports-post post-separator-border col-md-4 col-12">
                        <div class="post-wrap">
                        <a class="" data-toggle="lightbox" data-gallery="gallery" target="_blank"
                            href="{{ asset($item->src) }}">
                            <img class="img-thumbnail" src="{{ asset($item->src) }}"
                                alt="{{ asset($item->src) }}">
                        </a>
                    </div>
                </div>
                @endforeach
            </div>
        </div>
    </div>
</div><!-- Sidebar End -->
@push('styles')
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ekko-lightbox/5.3.0/ekko-lightbox.css" integrity="sha512-Velp0ebMKjcd9RiCoaHhLXkR1sFoCCWXNp6w4zj1hfMifYB5441C+sKeBl/T/Ka6NjBiRfBBQRaQq65ekYz3UQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
@endpush

@push('scripts')
    <script src="https://cdnjs.cloudflare.com/ajax/libs/ekko-lightbox/5.3.0/ekko-lightbox.min.js" integrity="sha512-Y2IiVZeaBwXG1wSV7f13plqlmFOx8MdjuHyYFVoYzhyRr3nH/NMDjTBSswijzADdNzMyWNetbLMfOpIPl6Cv9g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <script>
        $(document).on("click", '[data-toggle="lightbox"]', function(event) {
            event.preventDefault();
            $(this).ekkoLightbox();
        });
    </script>
@endpush