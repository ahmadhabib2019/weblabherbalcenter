<div class="blog-section section">
    <div class="container">

        <!-- Feature Post Row Start -->
        <div class="row">
            @isset($unduh)
                <x-unduh.index-section :unduh="$unduh"/>
            @else
                <x-unduh.show-section :unduhDetail="$unduhDetail"/>
            @endisset
        </div><!-- Feature Post Row End -->

    </div>
</div>
