<div class="header-section section">
    <div class="container">
        <div class="row align-items-center">
            <div class="header-logo col-md-3 d-none d-md-block">
                <a href="{{ route('welcome') }}" class="logo"><img src="{{ asset('images/logo-horizontal.png') }}" alt="Logo"></a>
            </div>
            
            <!-- Header Banner -->
            <!-- <div class="header-banner col-md-8 col-12">
                <div class="banner"><a href="#"><img src="{{ asset('frontend/img/banner/header-banner-1.png') }}" alt="Header Banner"></a></div>
            </div> -->
            
        </div>
    </div>
</div>