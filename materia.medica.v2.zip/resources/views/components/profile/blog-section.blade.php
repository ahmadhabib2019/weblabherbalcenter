<div class="blog-section section">
    <div class="container">

        <!-- Feature Post Row Start -->
        <div class="row">
            <x-profile.profile-section :user="$user" :provinces="$provinces" :cities="$cities" :pendidikan="$pendidikan" :pekerjaan="$pekerjaan" :gender="$gender" />
        </div><!-- Feature Post Row End -->

    </div>
</div>
