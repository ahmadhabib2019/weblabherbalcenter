<!-- Post Block Wrapper Start -->
<div class="col-md-2">

</div>

<div class="col-lg-8 col-12 mb-50">
    <div class="post-block-wrapper">
        <!-- Post Block Head Start -->
        <div class="head d-flex justify-content-center">
            <!-- Title -->
            <h4 class="title">Profile {{ auth()->user()->name }}</h4>
        </div><!-- Post Block Head End -->
        <!-- Post Block Body Start -->
        <div class="body">
            @if (session('status'))
                <div class="alert alert-success">
                    {{ session('status') }}
                </div>
            @endif
            @if ($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif
            <div class="post-comment-form">
                {!! Form::model($user, ['route' => ['frontend.profile-update', $user->id], 'method' => 'patch', 'files' => true]) !!}
                @if ($user->userData)
                    <div class="col-md-12 col-12 mb-20">
                        <label for="name">Nama Lengkap <sup>*</sup></label>
                        <input style="background-color:#F8F8F8" name="name" id="name" type="text" value="{{ $user->name }}" class="form-control">
                    </div>
                    <div class="col-md-12 col-12 mb-20">
                        <label for="nik">Nik<sup>*</sup></label>
                        <input style="background-color:#F8F8F8" name="nik" id="nik" type="text"
                            value="{{ $user->userData->nik }}" readonly>
                    </div>
                    <div class="col-md-12 col-12 mb-20">
                        <label for="nip">Nip <sup>*</sup></label>
                        <input style="background-color:#F8F8F8" name="nip" id="nip" type="text"
                            value="{{ $user->userData->nip }}">
                    </div>
                    <div class="col-md-12 col-12 mb-20">
                        <label for="gender">Gender <sup>*</sup></label>
                        @foreach ($gender as $key => $item)
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="gender" id="{{ $key }}"
                                    value="{{ $key }}"
                                    {{ $user->userData->gender == $key ? 'checked' : '' }}>
                                <label class="form-check-label" for="{{ $key }}">{{ $item }}</label>
                            </div>
                        @endforeach
                    </div>
                    <div class="col-md-12 col-12 mb-20">
                        <label for="tempat_lahir">Tempat Lahir<sup>*</sup></label>
                        <input style="background-color:#F8F8F8" name="tempat_lahir" id="tempat_lahir" type="text"
                            value="{{ $user->userData->tempat_lahir }}">
                    </div>
                    <div class="col-md-12 col-12 mb-20">
                        <label for="tgl_lahir">Tanggal Lahir<sup>*</sup></label>
                        <input type="date" name="tgl_lahir" class="form-control"
                            value="{{ $user->userData->tgl_lahir }}" />
                    </div>
                    <div class="col-md-12 col-12 mb-20">
                        <label for="alamat">Alamat <sup>*</sup></label>
                        <textarea style="background-color:#F8F8F8" name="alamat" id="alamat" cols="30"
                            rows="10">{{ $user->userData->alamat }}</textarea>
                    </div>
                    <div class="col-md-12 col-12 mb-20">
                        <label for="province">Provinsi <sup>*</sup></label>
                        {!! Form::select('provinsi', $provinces, $user->userData->provinsi, ['class' => 'form-control', 'id' => 'province']) !!}
                    </div>
                    <div class="col-md-12 col-12 mb-20">
                        <label for="city">Kota <sup>*</sup></label>
                        {!! Form::select('kota', $cities, $user->userData->kota, ['class' => 'form-control', 'id' => 'city']) !!}
                    </div>
                    <div class="col-md-12 col-12 mb-20">
                        <label for="phone">No telephone <sup>*</sup></label>
                        <input style="background-color:#F8F8F8" name="phone" type="text"
                            value="{{ $user->userData->phone }}">
                    </div>
                    <div class="col-md-12 col-12 mb-20">
                        <label for="pendidikan_akhir">Pendidikan Terakhir>*</sup></label>
                        {!! Form::select('pendidikan_akhir', $pendidikan, $user->userData->pendidikan_akhir, ['class' => 'form-control', 'id' => 'pendidikan_akhir']) !!}
                    </div>
                    <div class="col-md-12 col-12 mb-20">
                        <label for="pekerjaan">Pekerjaan <sup>*</sup></label>
                        {!! Form::select('pekerjaan', $pekerjaan, $user->userData->pekerjaan, ['class' => 'form-control', 'id' => 'pekerjaan']) !!}
                    </div>
                    <div class="col-md-12 col-12 mb-20">
                        <label for="jurusan">Jurusan <sup>*</sup></label>
                        <input style="background-color:#F8F8F8" name="jurusan" type="text" id="jurusan"
                            value="{{ $user->userData->jurusan }}">
                    </div>
                    <div class="col-md-12 col-12 mb-20">
                        <label for="fakultas">Fakultas <sup>*</sup></label>
                        <input style="background-color:#F8F8F8" name="fakultas" type="text" id="fakultas"
                            value="{{ $user->userData->fakultas }}">
                    </div>
                    <div class="col-md-12 col-12 mb-20">
                        <label for="instansi">Instansi <sup>*</sup></label>
                        <input style="background-color:#F8F8F8" name="instansi" type="text" id="instansi"
                            value="{{ $user->userData->instansi }}">
                    </div>
                    <div class="col-md-12 col-12 mb-20">
                        <label for="alamat_instansi">Alamat Instansi <sup>*</sup></label>
                        <input style="background-color:#F8F8F8" name="alamat_instansi" type="text" id="alamat_instansi"
                            value="{{ $user->userData->alamat_instansi }}">
                    </div>

                    <div class="col-md-12 col-12 mb-20">
                        <label for="name">Username <sup>*</sup></label>
                        <input style="background-color:#F8F8F8" type="text" name="username"
                            value="@if (!empty($user)){!! $user->username !!}@endif{!! old('username') !!}" readonly />
                    </div>
                    <div class="col-md-12 col-12 mb-20">
                        <label for="email">Email <sup>*</sup></label>
                        <input style="background-color:#F8F8F8" name="email" type="text" value="{{ $user->email }}"
                            readonly />
                    </div>
                    <div class="col-12 mb-20">
                        <label for="website">Password <sup>*</sup></label>
                        {!! Form::password('password', ['class' => 'form-control', 'maxlength' => 255, 'maxlength' => 255, 'style' => 'background-color:#F8F8F8']) !!}
                    </div>
                    <div class="col-12 mb-20">
                        <label for="message">Password Confirmation<sup>*</sup></label>
                        {!! Form::password('password_confirmation', ['class' => 'form-control', 'maxlength' => 255, 'maxlength' => 255, 'style' => 'background-color:#F8F8F8']) !!}
                    </div>
                @endif
                <div class="col-12">
                    <input type="submit" value="Perbarui">
                </div>
                {!! Form::close() !!}
            </div>
        </div><!-- Post Block Body End -->
    </div><!-- Post Block Wrapper End -->
</div>
@push('styles')
    <link href="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/css/select2.min.css" rel="stylesheet" />
@endpush
@push('scripts')
    <script src="https://cdnjs.cloudflare.com/ajax/libs/axios/0.21.4/axios.min.js"
        integrity="sha512-lTLt+W7MrmDfKam+r3D2LURu0F47a3QaW5nF0c6Hl0JDZ57ruei+ovbg7BrZ+0bjVJ5YgzsAWE+RreERbpPE1g=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js"></script>
    <script type="text/javascript">
        $(function() {

            $('#province').select2({
                // theme: 'bootstrap4',
            });
            $('#city').select2({
                // theme: 'bootstrap4',
            })
            $('#province').on('change', function() {
                var city_id = $(this).val();
                var url = '{{ route('profile.get_city', ':city_id') }}';
                url = url.replace(':city_id', city_id);
                console.log(url);
                axios.get(url)
                    .then(function(response) {
                        $('#city').empty();
                        $.each(response.data, function(id, name) {
                            $('#city').append(new Option(name, id))
                        })
                    });
            });
        });
    </script>
@endpush
