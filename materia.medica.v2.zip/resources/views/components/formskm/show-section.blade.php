<div class="blog-section section mb-30">
    <div class="container">
        <!-- Feature Post Row Start -->
        <div class="row d-flex justify-content-center">
            <div class="col-lg-10 col-12 mb-50">
                <!-- Post Block Wrapper Start -->
                <div class="post-block-wrapper">
                    @if ($message = Session::get('info'))
                    <div class="alert alert-success alert-block" style="margin-top:10px ">
                        <button type="button" class="close" data-dismiss="alert">×</button>    
                        <strong>{{ $message }}</strong>
                    </div>
                    @endif
                    <!-- Post Block Head Start -->
                    <div class="head d-flex justify-content-center">
                        <!-- Title --> 
                        <center>
                            <h3 class="title">
                                Survey Kepuasan Masyarakat <br> {{ date('Y')}}
                            </h3>
                        </center>
                    </div><!-- Post Block Head End -->
                    <!--  -->
                    
                    <!-- Post Block Body Start -->
                    <div class="body">
                        <div class="row">
                            <div>
                                <div><a href="{{ route('frontend.skm.show',['tgl'=>1]) }}" class="btn btn-light btn-sm @isset($_GET['tgl']){{ $_GET['tgl'] == 1 ? 'active' : ''}} @endisset" style="width:100px;margin-bottom:2px">Januari</a></div>
                                <div><a href="{{ route('frontend.skm.show',['tgl'=>2]) }}" class="btn btn-light btn-sm @isset($_GET['tgl']){{ $_GET['tgl'] == 2 ? 'active' : ''}} @endisset" style="width:100px;margin-bottom:2px">Februari</a></div>
                                <div><a href="{{ route('frontend.skm.show',['tgl'=>3]) }}" class="btn btn-light btn-sm @isset($_GET['tgl']){{ $_GET['tgl'] == 3 ? 'active' : ''}} @endisset" style="width:100px;margin-bottom:2px">Maret</a></div>
                                <div><a href="{{ route('frontend.skm.show',['tgl'=>4]) }}" class="btn btn-light btn-sm @isset($_GET['tgl']){{ $_GET['tgl'] == 4 ? 'active' : ''}} @endisset" style="width:100px;margin-bottom:2px">April</a></div>
                                <div><a href="{{ route('frontend.skm.show',['tgl'=>5]) }}" class="btn btn-light btn-sm @isset($_GET['tgl']){{ $_GET['tgl'] == 5 ? 'active' : ''}} @endisset" style="width:100px;margin-bottom:2px">Mei</a></div>
                                <div><a href="{{ route('frontend.skm.show',['tgl'=>6]) }}" class="btn btn-light btn-sm @isset($_GET['tgl']){{ $_GET['tgl'] == 6 ? 'active' : ''}} @endisset" style="width:100px;margin-bottom:2px">Juni</a></div>
                                <div><a href="{{ route('frontend.skm.show',['tgl'=>7]) }}" class="btn btn-light btn-sm @isset($_GET['tgl']){{ $_GET['tgl'] == 7 ? 'active' : ''}} @endisset" style="width:100px;margin-bottom:2px">Juli</a></div>
                                <div><a href="{{ route('frontend.skm.show',['tgl'=>8]) }}" class="btn btn-light btn-sm @isset($_GET['tgl']){{ $_GET['tgl'] == 8 ? 'active' : ''}} @endisset" style="width:100px;margin-bottom:2px">Agustus</a></div>
                                <div><a href="{{ route('frontend.skm.show',['tgl'=>9]) }}" class="btn btn-light btn-sm @isset($_GET['tgl']){{ $_GET['tgl'] == 9 ? 'active' : ''}} @endisset" style="width:100px;margin-bottom:2px">September</a></div>
                                <div><a href="{{ route('frontend.skm.show',['tgl'=>10]) }}" class="btn btn-light btn-sm @isset($_GET['tgl']){{ $_GET['tgl'] == 10 ? 'active' : ''}} @endisset" style="width:100px;margin-bottom:2px">Oktober</a></div>
                                <div><a href="{{ route('frontend.skm.show',['tgl'=>11]) }}" class="btn btn-light btn-sm @isset($_GET['tgl']){{ $_GET['tgl'] == 11 ? 'active' : ''}} @endisset" style="width:100px;margin-bottom:2px">November</a></div>
                                <div><a href="{{ route('frontend.skm.show',['tgl'=>12]) }}" class="btn btn-light btn-sm @isset($_GET['tgl']){{ $_GET['tgl'] == 12 ? 'active' : ''}} @endisset" style="width:100px;margin-bottom:2px">Desember</a></div>
                            </div>
                            <div class="post-comment-form col-md-10">
                                <div id="skmChart"></div>
                                <center>
                                    <div><img height="180" src="{{ asset('images/tableikm.png') }}" alt=""></div>
                                </center>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@php
    if(isset($_GET['tgl'])){
        $tgl = \Carbon\Carbon::createFromFormat('m',$_GET['tgl'])->locale('id')->settings(['formatFunction' => 'translatedFormat'])->format('F-Y');
    }
@endphp
@push('scripts')
<script src="https://code.highcharts.com/highcharts.js"></script>

<script>
    Highcharts.chart('skmChart', {
        chart: {
            type: 'line'
        },
        title: {
            text: '<b>Capaian IKM Per Unit Pelayanan <br> @isset($_GET['tgl']){{$tgl}}@else {!! \Carbon\Carbon::now()->setTimezone('Asia/Jakarta')->locale('id')->isoFormat('MMMM YYYY') !!}@endisset</b>'
        },
        subtitle: {
            text: ''
        },
        accessibility: {
            announceNewData: {
                enabled: false
            }
        },
        xAxis: {
            type: 'category'
        },
        yAxis: {
            title: {
                text: ''
            }
        },
        yAxis: {
        min: 0,
        max: 100
        },
        legend: {
            enabled: false
        },
        plotOptions: {
            series: {
                borderWidth: 0,
                dataLabels: {
                    enabled: true,
                    format: '{point.y:.0f}%'
                }
            }
        },

        tooltip: {
            headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
            pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y:.2f}%</b> of total<br/>'
        },
        credits: {
            enabled: false
        },

        series: [
            {
                name: "Layanan",
                colorByPoint: true,
                data: 
                    [
                        {
                            name: "Wisata Edukasi Toga",
                            y: {{$skm0}},
                            drilldown: "Wisata Edukasi Toga"
                        },{
                            name: "Workshop Pengolahan Tanaman Obat ",
                            y:{{$skm1}},
                            drilldown: "Workshop Pengolahan Tanaman Obat "
                        },
                        {
                            name: "Narasumber",
                            y:{{$skm2}},
                            drilldown: "Narasumber"
                        },
                        {
                            name: "PKL dan Magang",
                            y:{{$skm3}},
                            drilldown: "PKL dan Magang"
                        },
                        {
                            name: "Identifikasi Tanaman Obat (Determinasi)",
                            y:{{$skm4}},
                            drilldown: "Identifikasi Tanaman Obat (Determinasi)"
                        },
                        {
                            name: "Pengolahan Pasca Panen Tanaman Obat ",
                            y:{{$skm5}},
                            drilldown: "OpPengolahan Pasca Panen Tanaman Obat ra"   
                        },
                        {
                            name: "Ekstraksi Tanaman Obat",
                            y:{{$skm6}},
                            drilldown: "Ekstraksi Tanaman Obat"
                        },
                        {
                            name: "Pengujian Kandungan Tanaman Obat ",
                            y:{{$skm7}},
                            drilldown: "Pengujian Kandungan Tanaman Obat" 
                        },
                        {
                            name: "Pengujian Mikrobiologi ",
                            y:{{$skm8}},
                            drilldown: "Pengujian Mikrobiologi "
                        },
                        {
                            name: "Pelayanan Kesehatan Tradisional (Griya Sehat)",
                            y:{{$skm9}},
                            drilldown: "Pelayanan Kesehatan Tradisional (Griya Sehat)"
                        },{
                            name: "Herbalmart",
                            y:{{$skm10}},
                            drilldown: "Herbalmart"
                        },{
                            name: "Bibit Tanaman Obat",
                            y:{{$skm11}},
                            drilldown: "Bibit Tanaman Obat"
                        },{
                            name: "Sewa Fasilitas Gedung dan atau Alat",
                            y:{{$skm12}},
                            drilldown: "Sewa Fasilitas Gedung dan atau Alat"
                        },{
                            name: "Materia Medica Café ",
                            y:{{$skm13}},
                            drilldown: "Materia Medica Café "
                        },{
                            name: "Homecare",
                            y:{{$skm14}},
                            drilldown: "Homecare"
                        },{
                            name: "Telemedisin Griya Sehat ",
                            y:{{$skm15}},
                            drilldown: "Telemedisin Griya Sehat "
                        }
                    ]

            }
        ],
        
    });
</script>
@endpush
