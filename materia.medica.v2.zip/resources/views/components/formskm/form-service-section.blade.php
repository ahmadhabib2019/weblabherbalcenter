<!-- Post Block Wrapper Start -->
<div class="col-md-2">
    
</div>

<div class="col-lg-8 col-12 mb-50">
    <div class="post-block-wrapper">
        <!-- Post Block Head Start -->
        @if ($message = Session::get('info'))
        <div class="alert alert-success alert-block" style="margin-top:10px ">
            <button type="button" class="close" data-dismiss="alert">×</button>    
            <strong>{{ $message }}</strong>
        </div>
        @endif
        <div class="head d-flex justify-content-center">
            <!-- Title -->
            <h4 class="title">Pilih Layanan Untuk Survey Kepuasan Masyarakat</h4>
        </div><!-- Post Block Head End -->
        <!-- Post Block Body Start -->
        <div class="body" >
            <div class="post-comment-form">
                @foreach($skm as $data)
                <div style="margin-bottom:10px">
                    <a href="{{ route('frontend.skm.form-skm',[$data->id])  }}" class="btn btn-info" style="width: 100%">{{ $data->service->title }}</a>
                </div>
                @endforeach
            </div>
        </div><!-- Post Block Body End -->
    </div><!-- Post Block Wrapper End -->
</div>