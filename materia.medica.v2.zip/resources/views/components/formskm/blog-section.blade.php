<div class="blog-section section">
    <div class="container">

        <!-- Feature Post Row Start -->
        <div class="row">
            
            @if(isset($formskm))
                <x-formskm.form-service-section :skm="$formskm"/>
            @elseif(isset($detailSkm))
                <x-formskm.form-skm-section :detailSkm="$detailSkm"/>
            @else
                <x-formskm.show-section :data="$data" :skm0="$skm0" :skm1="$skm1" :skm2="$skm2" :skm3="$skm3" :skm4="$skm4" :skm5="$skm5" :skm6="$skm6" :skm7="$skm7" :skm8="$skm8" :skm9="$skm9" :skm10="$skm10" :skm11="$skm11" :skm12="$skm12" :skm13="$skm13" :skm14="$skm14" :skm15="$skm15" />
            @endif
        </div><!-- Feature Post Row End -->

    </div>
</div>
