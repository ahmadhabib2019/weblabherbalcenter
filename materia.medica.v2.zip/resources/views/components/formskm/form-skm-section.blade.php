<!-- Post Block Wrapper Start -->
<div class="col-md-1">
    
</div>
<div class="col-lg-9 col-12 mb-50">
    <div class="post-block-wrapper">
        <!-- Post Block Head Start -->
        @if ($message = Session::get('info'))
        <div class="alert alert-success alert-block" style="margin-top:10px ">
            <button type="button" class="close" data-dismiss="alert">×</button>    
            <strong>{{ $message }}</strong>
        </div>
        @elseif ($message = Session::get('warning'))
        <div class="alert alert-warning alert-block" style="margin-top:10px ">
            <button type="button" class="close" data-dismiss="alert">×</button>    
            <strong>{{ $message }}</strong>
        </div>
        @elseif ($message = Session::get('danger'))
        <div class="alert alert-danger alert-block" style="margin-top:10px ">
            <button type="button" class="close" data-dismiss="alert">×</button>    
            <strong>{{ $message }}</strong>
        </div>
        @endif
        <div class="head d-flex justify-content-center">
            <!-- Title -->
            <center>
                <h4 class="title">Silahkan Melakukan Penilaian Layanan <br>{{ $detailSkm->service->title }}</h4>
            </center>
        </div><!-- Post Block Head End -->
        <!-- Post Block Body Start -->
        <div class="body" >
            <div class="post-comment-form">
                {!! Form::open(['route' => ['frontend.skm.store'], 'id' => 'form', 'method'=>'post']) !!}
                {!! Form::hidden('user_id', auth()->user()->id) !!}
                <input type="text" name="service_id" value="{{$detailSkm->service_id}}" style="display:none">

                    <div class="col-md-12 col-12 mb-20">
                        <table class="">
                            <thead>
                                <tr>
                                    <th scope="col-span-3">Pertanyaan :</th>
                                    <th scope="col-span"></th>
                                    <th scope=""style="width:10px;" class="text-center">TB</th>
                                    <th scope=""style="width:10px;" class="text-center">KB</th>
                                    <th scope=""style="width:10px;" class="text-center">B</th>
                                    <th scope="" style="width:10px;"class="text-center">SB</th>
                                </tr>
                            </thead>
                            <tbody>@php $key = 1; @endphp
                                @foreach ($detailSkm->formSkmContent as $data)
                                    <tr>
                                        <td class="">
                                            {{ $key++ }}
                                        </td>
                                        <td class="d-none d-md-table-cell nowrap">{{ $data->questionSkm->question }}</td>
                                        <td style="width:30px;margin-right:20px">
                                            <input type="radio" value="1" name="question[{{ $data->questionSkm->id }}]" required>
                                        </td>
                                        <td style="width:30px;margin-right:20px">
                                            <input type="radio" value="2" name="question[{{ $data->questionSkm->id }}]" required>
                                        </td>
                                        <td style="width:30px;margin-right:20px">
                                            <input type="radio" value="3" name="question[{{ $data->questionSkm->id }}]" required>
                                        </td>
                                        <td style="width:30px;margin-right:20px">
                                            <input type="radio" value="4" name="question[{{ $data->questionSkm->id }}]" required>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                        <hr>
                        <div class="form-group row">
                            {!! Form::submit('Submit', ['class' => 'btn btn-primary']) !!}
                        </div>

                    </div>
                {!! Form::close() !!}
            </div>
        </div><!-- Post Block Body End -->
    </div><!-- Post Block Wrapper End -->
</div>
<div class="col-md-2" style="padding-top:70px">
    <table class="">
        <tr>
            <th>Keterangan :</th>
        </tr>
        <tr>
            <td>Tidak baik (TB)</td>
        </tr>
        <tr>
            <td>Kurang baik (KB)</td>
        </tr>
        <tr>
            <td>Baik (B) </td>
        </tr>
        <tr>
            <td>Sangat baik (SB)</td>
        </tr>
        
    </table>
</div>