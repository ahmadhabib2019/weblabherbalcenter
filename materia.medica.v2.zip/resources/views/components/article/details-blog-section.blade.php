<div class="col-lg-8 col-12 mb-50">
    <div class="container">

        @if ($blogprofile == null)
            <div class="single-blog mb-50">
                <div class="blog-wrap" style="text-align: center;">
                    <h4 class="alert alert-danger"> Not Found! </h4>
                </div>
            </div>
        @else
            <div class="single-blog mb-50">
                <div class="blog-wrap">
                    <h5 class="title"><a href="#"></a>{{ $blogprofile->title }}</h5>
                    <div class="post-content">
                        {!! $blogprofile->content ? $blogprofile->content : $blogprofile->description !!}
                    </div>
                    @if ($blogprofile->fasilitas_files)
                        <div class="files">
                            <div class="post-block-wrapper">
                                <div class="body">
                                    <div class="row ">
                                        @foreach ($blogprofile->fasilitas_files as $item)
                                            <div class="post sports-post post-separator-border col-md-4 col-12">
                                                <div class="post-wrap">
                                                    <a class="thumbnail image" data-toggle="lightbox"
                                                        data-gallery="gallery" href="{{ asset($item['src']) }}">
                                                        <img class="img-thumbnail" src="{{ asset($item['src']) }}"
                                                            alt="{{ $blogprofile->title }}">
                                                    </a>
                                                </div>
                                            </div>
                                        @endforeach
                                    </div>
                                </div>
                            </div>
                        </div>
                    @endif

                </div>
            </div>
        @endIf
    </div>

</div>
@push('styles')
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ekko-lightbox/5.3.0/ekko-lightbox.css" integrity="sha512-Velp0ebMKjcd9RiCoaHhLXkR1sFoCCWXNp6w4zj1hfMifYB5441C+sKeBl/T/Ka6NjBiRfBBQRaQq65ekYz3UQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
@endpush

@push('scripts')
    <script src="https://cdnjs.cloudflare.com/ajax/libs/ekko-lightbox/5.3.0/ekko-lightbox.min.js" integrity="sha512-Y2IiVZeaBwXG1wSV7f13plqlmFOx8MdjuHyYFVoYzhyRr3nH/NMDjTBSswijzADdNzMyWNetbLMfOpIPl6Cv9g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <script>
        $(document).on("click", '[data-toggle="lightbox"]', function(event) {
            event.preventDefault();
            $(this).ekkoLightbox();
        });
    </script>
@endpush
