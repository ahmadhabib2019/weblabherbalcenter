<!-- Sidebar Start -->
<div class="col-lg-4 col-12 mb-50">
    <div class="row">

        <!-- Single Sidebar -->
        <div class="single-sidebar col-lg-12 col-md-6 col-12">

            <!-- Sidebar Block Wrapper -->
            <div class="sidebar-block-wrapper">

                <!-- Sidebar Block Head Start -->
                <div class="head feature-head">

                    <!-- Title -->
                    <h4 class="title" style="text-align: center">List Berita</h4>

                </div><!-- Sidebar Block Head End -->

                <!-- Sidebar Block Body Start -->
                <div class="body">

                    <div class="row">
                        @foreach ($sides as $value)
                            <!-- Post Small Start -->
                            <div class="post post-small post-list feature-post post-separator-border">
                                <div class="post-wrap " style="min-height: 80px;padding:10px 0;">
                                    <!-- Image -->
                                    <a class="image" href="{{ route('frontend.post.show',[$value->slug,$value->id]) }}"><img src="{{ $value->featured_image ? $value->featured_image : asset('frontend/img/logo.png')  }}"
                                            alt="post"></a>
                                    <!-- Content -->
                                    <div class="post-content">
                                        <!-- Title -->
                                        <h5 class="title"><a href="{{ route('frontend.post.show',[$value->slug,$value->id]) }}">{{ Str::limit($value->title,30) }}</a></h5>
                                        <!-- Meta -->
                                        <div class="meta fix">
                                            <span class="meta-item date"><i class="fa fa-clock-o"></i> {{ date('d-m-Y', strtotime($value->created_at))  }}</span>
                                        </div>
                                    </div>
                                </div>
                            </div><!-- Post Small End -->
                        @endforeach
                    </div>

                </div><!-- Sidebar Block Body End -->

            </div>

        </div>

        <!-- Single Sidebar -->
        {{-- <div class="single-sidebar col-lg-12 col-md-6 col-12">

            <!-- Sidebar Banner -->
            <a href="#" class="sidebar-banner"><img src="{{ asset('frontend/img/banner/sidebar-banner-1.jpg') }}" alt="Sidebar Banner"></a>

        </div>

        <!-- Single Sidebar -->
        <div class="single-sidebar col-lg-12 col-md-6 col-12">

            <!-- Sidebar Banner -->
            <a href="#" class="sidebar-banner"><img src="{{ asset('frontend/img/banner/sidebar-banner-2.jpg') }}" alt="Sidebar Banner"></a>

        </div> --}}

        <!-- Single Sidebar -->
       {{-- <div class="single-sidebar col-lg-12 col-md-6 col-12">

            <div class="sidebar-subscribe">
                <h4>Subscribe To <br>Our <span>Update</span> News</h4>
                <p>Adipiscing elit. Fusce sed mauris arcu. Praesent ut augue imperdiet, semper lorem id.</p>
                <!-- Newsletter Form -->
                <form
                    action="http://devitems.us11.list-manage.com/subscribe/post?u=6bbb9b6f5827bd842d9640c82&amp;id=05d85f18ef"
                    method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form"
                    class="subscribe-form validate" target="_blank" novalidate="">
                    <div id="mc_embed_signup_scroll">
                        <label for="mce-EMAIL" class="d-none">Subscribe to our mailing list</label>
                        <input type="email" value="" name="EMAIL" class="email" id="mce-EMAIL"
                            placeholder="Your email address" required="">
                        <!-- real people should not fill this in and expect good things - do not remove this or risk form bot signups-->
                        <div style="position: absolute; left: -5000px;" aria-hidden="true"><input type="text"
                                name="b_6bbb9b6f5827bd842d9640c82_05d85f18ef" tabindex="-1" value=""></div>
                        <button type="submit" name="subscribe" id="mc-embedded-subscribe" class="button">submit</button>
                    </div>
                </form>
            </div>

        </div>--}}

    </div>
</div><!-- Sidebar End -->
