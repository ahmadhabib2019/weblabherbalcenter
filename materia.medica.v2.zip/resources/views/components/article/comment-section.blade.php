<!-- Post Block Wrapper Start -->
<div class="post-block-wrapper">
    <!-- Post Block Head Start -->
    <div class="head">
        <!-- Title -->
        <h4 class="title">Leave a Comment</h4>
    </div><!-- Post Block Head End -->
    <!-- Post Block Body Start -->
    <div class="body">
        <div class="post-comment-form">
            <form action="#" class="row">
                <div class="col-md-6 col-12 mb-20">
                    <label for="name">Name <sup>*</sup></label>
                    <input type="text" id="name">
                </div>
                <div class="col-md-6 col-12 mb-20">
                    <label for="email">Email <sup>*</sup></label>
                    <input type="text" id="email">
                </div>
                <div class="col-12 mb-20">
                    <label for="website">Website <sup>*</sup></label>
                    <input type="text" id="website">
                </div>
                <div class="col-12 mb-20">
                    <label for="message">Message <sup>*</sup></label>
                    <textarea id="message"></textarea>
                </div>
                <div class="col-12">
                    <input type="submit" value="Submit Comment">
                </div>
            </form>
        </div>
    </div><!-- Post Block Body End -->
</div><!-- Post Block Wrapper End -->
