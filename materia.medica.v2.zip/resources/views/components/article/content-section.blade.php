<div class="col-lg-8 col-12 mb-50">

    <!-- Post Block Wrapper Start -->
    <div class="post-block-wrapper">

        <!-- Post Block Body Start -->
        <div class="body">
            @foreach ($posts as $post)
            @php 
                $visitor = \App\Models\Visitor::where('page_id',$post->id)->where('slug',Request::segment(1))->count();
            @endphp

                <!-- Post Start -->
                <div class="post fashion-post post-default-list post-separator-border">
                    <div class="post-wrap">

                        <!-- Image -->
                        @if ($post->featured_image)
                        <a class="image" href="{{ route('frontend.post.show', ['id' => $post->id, 'slug' => $post->slug]) }}">
                            <img src="{{ $post->featured_image ? $post->featured_image : asset('frontend/img/logo.png') }}" class="img-thumbnail">
                        </a>
                        @endif

                        <!-- Content -->
                        <div class="post-content">

                            <!-- Title -->
                            <h4 class="title"><a
                                    href="{{ route('frontend.post.show', ['id' => $post->id, 'slug' => $post->slug]) }}">{{ $post->title }}</a>
                            </h4>

                            <!-- Meta -->
                            <div class="meta fix">
                                <a href="#" class="meta-item author"><i class="fa fa-user"></i> Viewer {{$visitor}} </a>
                                <span class="meta-item date"> <i class="fa fa-calendar"></i> {{ date('d-m-Y', strtotime($post->created_at)); }}</span>
                            </div>

                            <!-- Description -->
                            {!! Str::limit($post->content,300) !!}
                            <!-- Read More -->
                            <b><a href="{{ route('frontend.post.show', ['id' => $post->id, 'slug' => $post->slug]) }}">Selengkapnya</a></b>
                        </div>

                    </div>
                </div><!-- Post End -->
            @endforeach
            <div class="d-flex">
                <div class="mx-auto">
                    {{ $posts->links() }}
                </div>
            </div>

        </div>
    </div>
</div>
