<div class="blog-section section">
    <div class="container">

        <!-- Feature Post Row Start -->
        <div class="row">
            @if(isset($posts))
                <x-article.content-section :posts="$posts" />
            @elseif(isset($fasilitas))
                <x-article.details-fasilitas-section :fasilitas="$fasilitas" />
            @else
                <x-article.details-blog-section :blogprofile="$blogprofile" />
            @endif
                <x-article.sidebar-section />
        </div><!-- Feature Post Row End -->
    </div>
</div>
