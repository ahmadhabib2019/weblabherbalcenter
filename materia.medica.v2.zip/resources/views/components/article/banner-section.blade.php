<div class="page-banner-section section mt-30 mb-30">
    <div class="container">
        <div class="row row-1">
            <!-- Page Banner Start -->
            <div class="col-12">
                <div class="page-banner"
                    style="background-image: url(https://image.shutterstock.com/z/stock-photo-long-wide-banner-with-natural-herbal-pills-for-detox-and-immunity-support-in-pandemic-time-big-1790217356.jpg)">
                    <h2>Blog Details</h2>
                    <ol class="page-breadcrumb">
                        <li><a href="#">Home</a></li>
                        <li class="active">blog details</li>
                    </ol>
                </div>
            </div><!-- Page Banner End -->
        </div>
    </div>
</div>
