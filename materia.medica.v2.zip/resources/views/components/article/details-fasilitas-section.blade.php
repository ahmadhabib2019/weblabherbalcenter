<div class="col-lg-8 col-12 mb-50">
    <div class="container">

        @if ($fasilitas == null)
            <div class="single-blog mb-50">
                <div class="blog-wrap" style="text-align: center;">
                    <h4 class="alert alert-danger"> Not Found! </h4>
                </div>
            </div>
        @else
            <div class="single-blog mb-50">
                <div class="blog-wrap">
                    <h5 class="title"><a href="#"></a>{{ $fasilitas->title }}</h5>
                    @if ($fasilitas->featured_image)
                        <img src="{{ $fasilitas->featured_image ? $fasilitas->featured_image : asset('frontend/img/logo.png') }}" class="rounded mx-auto d-block"
                            alt="post" style="width: 50%; height: 60%;">
                    @endif
                    @if ($fasilitas->fasilitas_files)
                        <div class="">
                            <div class="">
                                <div class="body">
                                    <div class="post-carousel-1">
                                        @foreach ($fasilitas->fasilitas_files as $item)
                                        <div class="post post-overlay hero-post">
                                            <div class="post-wrap">
                                                <!-- Image -->
                                                <a class="image" href="{{ asset($item['src']) }}"><img alt="tes" src="{{ asset($item['src']) }}">
                                                </a>
                                                <!-- Category -->
                                                <!-- Content -->
                                            </div>
                                        </div><!-- Overlay Post End -->
                                        @endforeach
                                    </div>
                                </div>
                            </div>
                        </div>
                    @endif
                    <div class="post-content">
                        {!! $fasilitas->content ? $fasilitas->content : $fasilitas->description !!}
                    </div>
                </div>
            </div>
        @endIf
    </div>

</div>
@push('styles')
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ekko-lightbox/5.3.0/ekko-lightbox.css" integrity="sha512-Velp0ebMKjcd9RiCoaHhLXkR1sFoCCWXNp6w4zj1hfMifYB5441C+sKeBl/T/Ka6NjBiRfBBQRaQq65ekYz3UQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
@endpush

@push('scripts')
    <script src="https://cdnjs.cloudflare.com/ajax/libs/ekko-lightbox/5.3.0/ekko-lightbox.min.js" integrity="sha512-Y2IiVZeaBwXG1wSV7f13plqlmFOx8MdjuHyYFVoYzhyRr3nH/NMDjTBSswijzADdNzMyWNetbLMfOpIPl6Cv9g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <script>
        $(document).on("click", '[data-toggle="lightbox"]', function(event) {
            event.preventDefault();
            $(this).ekkoLightbox();
        });
    </script>
@endpush