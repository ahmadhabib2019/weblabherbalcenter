<div class="col-lg-8 col-12 mb-50">
    @if($post == NULL)
        <div class="single-blog mb-50">
            <div class="blog-wrap" style="text-align: center; height: 20vw;">
                <h4><i style="font-size: 40px; color: red;" class="fa fa-exclamation"></i> <br> Konten belum di Update</h4>
            </div>
        </div>
    @else
        <div class="single-blog mb-50">
            <div class="blog-wrap">
                <h5 class="title"><a href="#"></a>{{$post->title}}</h5>

                <div class="post-content">
                    <p>{!! $post->content  !!}</p>
                </div>

                <div class="tags-social float-left">
                    <div class="tags float-left">
                        <i class="fa fa-tags"></i>
                        <a href="#">Lifestyle,</a>
                        <a href="#">Woman,</a>
                        <a href="#">Cool</a>
                    </div>
                    <div class="blog-social float-right">
                        <a href="#" class="facebook"><i class="fa fa-facebook"></i></a>
                        <a href="#" class="twitter"><i class="fa fa-twitter"></i></a>
                        <a href="#" class="dribbble"><i class="fa fa-dribbble"></i></a>
                        <a href="#" class="google-plus"><i class="fa fa-google-plus"></i></a>
                    </div>
                </div>
            </div>
        </div>
    @endIf

    <div class="post-nav mb-50">
        <a href="#" class="prev-post"><span>previous post</span>he 10 Best Beauty Looks: Week of September 11, 2019.</a>
        <a href="#" class="next-post"><span>next post</span>The top 7 collections of New York fashion week.</a>
    </div>

    <x-article.comment-section/>
</div>
