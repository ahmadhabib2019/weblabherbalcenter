<!-- Post Block Wrapper Start -->
<div class="col-md-1">

</div>

<div class="col-lg-10 col-12 mb-50">
    <div class="post-block-wrapper">
        <!-- Post Block Head Start -->
        <div class="head d-flex justify-content-center">
            <!-- Title -->
            <h4 class="title">History {{ auth()->user()->name}}</h4>
        </div><!-- Post Block Head End -->
        <!-- Post Block Body Start -->
        <div class="body" >
            <div class="post-comment-form">
                    <div class="col-md-12 col-12 mb-20">
                        <table class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th scope="col">No</th>
                                    <th scope="col">Layanan</th>
                                    <th scope="col" class="text-center">Detail</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($tableData as $key => $data)
                                    <tr>
                                        <td class="w-5">
                                            {{ $key + 1 }}
                                        </td>
                                        <td class="d-none d-md-table-cell nowrap">{{ $data->services->title }}</td>
                                        <td class="text-center">
                                            <a href="{{ route('frontend.history.detail', [$data->id]) }}">
                                                <i class="fa fa-list"></i>
                                            </a>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                        <div class="d-flex">
                            <div class="mx-auto">
                                {{ $tableData->links() }}
                            </div>
                        </div>
                    </div>
            </div>
        </div><!-- Post Block Body End -->
    </div><!-- Post Block Wrapper End -->
</div>
