<div class="blog-section section">
    <div class="container">

        <!-- Feature Post Row Start -->
        <div class="row">
            <x-history.history-section :tableData="$tableData"/>
        </div><!-- Feature Post Row End -->

    </div>
</div>
