<div class="blog-section section">
    <div class="container">

        <!-- Feature Post Row Start -->
        <div class="row">
            @isset($sarankritik)
                <x-sarankritik.show-section :sarankritik="$sarankritik"/>
            @else
                <x-sarankritik.index-section />
            @endisset
        </div><!-- Feature Post Row End -->

    </div>
</div>
