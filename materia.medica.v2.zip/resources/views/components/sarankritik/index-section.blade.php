<!-- Post Block Wrapper Start -->
<div class="col-md-2">
    
</div>

<div class="col-lg-8 col-12 mb-50">
    <div class="post-block-wrapper">
        <!-- Post Block Head Start -->
        @if ($message = Session::get('info'))
        <div class="alert alert-success alert-block" style="margin-top:10px ">
            <button type="button" class="close" data-dismiss="alert">×</button>    
            <strong>{{ $message }}</strong>
        </div>
        @endif
        <div class="head d-flex justify-content-center">
            <!-- Title -->
            <h4 class="title">Form Saran Kritik</h4>
        </div><!-- Post Block Head End -->
        <!-- Post Block Body Start -->
        <div class="body" >
            <div class="post-comment-form">
                {!! Form::open(['route' => ['frontend.sarankritik.store'], 'files'=>true,'method'=>'post']) !!}
        
                        {!! Form::label('', '') !!}

                        <div class="form-group col-sm-12">
                            {!! Form::label('saran', 'Saran:') !!}
                            {!! Form::textarea('saran', null, ['class' => 'form-control','style'=>'background:#F8F8F8','placeholder'=>'.....']) !!}
                        </div>

                        <!-- Instansi Field -->
                        <div class="form-group col-sm-12">
                            {!! Form::label('kritik', 'Kritik:') !!}
                            {!! Form::textarea('kritik', null, ['class' => 'form-control','style'=>'background:#F8F8F8','placeholder'=>'.....']) !!}
                        </div>


                        <!-- User Id Field -->
                            <input style="display:none" name="user_id" type="text" value="{{ auth()->user()->id }}">
                    <div class="col-12">
                        <input type="submit" value="Submit">
                    </div>
                {!! Form::close() !!}
            </div>
        </div><!-- Post Block Body End -->
    </div><!-- Post Block Wrapper End -->
</div>