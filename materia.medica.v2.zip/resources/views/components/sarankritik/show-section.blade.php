<div class="row">

<div class="col-md-2">
    </div>
    <div class="col-lg-8 col-12 mb-50">
        <div class="post-block-wrapper">
            <!-- Post Block Head Start -->
            <div class="head d-flex justify-content-center">
                <!-- Title -->
                <h4 class="title">Saran dan Kritik</h4>
            </div><!-- Post Block Head End -->
            <!-- Post Block Body Start -->
            <div class="body" >
                <div class="post-comment-form">
                    <div>
                        <table class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th scope="col">No</th>
                                    <th scope="col">Saran</th>
                                    <th scope="col">Tanggapan</th>
                                    <th scope="col">Kritik</th>
                                    <th scope="col">Tanggapan</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($sarankritik as $key => $data)
                                    <tr>
                                        <td class="w-5">
                                            {{ $key + 1 }}
                                        </td>
                                        <td class="d-none d-md-table-cell nowrap">{{ $data->saran }}</td>
                                        <td class="d-none d-md-table-cell nowrap">{{ $data->response_saran }}</td>
                                        <td class="d-none d-md-table-cell nowrap">{{ $data->kritik }}</td>
                                        <td class="d-none d-md-table-cell nowrap">{{ $data->response_kritik }}</td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div><!-- Post Block Body End -->
        </div><!-- Post Block Wrapper End -->
    </div>
</div>