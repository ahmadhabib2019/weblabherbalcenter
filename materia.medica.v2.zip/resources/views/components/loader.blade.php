<style type="text/css">
    .preloader {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        z-index: 9999;
        background-color: #fff;
    }

    .preloader .loading {
        position: absolute;
        left: 50%;
        top: 50%;
        transform: translate(-50%, -50%);
        font: 14px arial;
        align-self: flex-end;
        animation-duration: 2s;
        animation-iteration-count: infinite;
        margin: 0 auto 0 auto;
        transform-origin: bottom;
    }

    .bounce-2 {
        animation-name: bounce-2;
        animation-timing-function: ease;
    }

    @keyframes bounce-2 {
        0% {
            transform: translateY(0);
        }

        50% {
            transform: translateY(-100px);
        }

        100% {
            transform: translateY(0);
        }
    }

</style>
<div class="preloader">
    <div class="loading bounce-2">
        <img src="{{ asset('images/logo-square.png') }}" width="150">
    </div>
</div>
@push('scripts')
    <script>
    $(document).ready(function() {
        $(".preloader").fadeOut();
    })
</script>
@endpush
