<!-- Header Top Start -->
<div class="header-top section">
    <div class="container">
        <div class="row">

            <!-- Header Top Links Start -->
            <div class="header-top-links col-md-6 col-6">

                <!-- Header Links -->
                <ul class="header-links">
                    <li class="disabled block d-none d-md-block"><a href="#"><i
                                class="fa fa-clock-o"></i>{{ \Carbon\Carbon::now()->setTimezone('Asia/Jakarta')->locale('id')->isoFormat('dddd, Do MMMM YYYY, h:mm') }}</a>
                    </li>
                    <li><a href="https://aksijitu.materiamedicabatu.jatimprov.go.id/"><i class="fa fa-laptop"></i>AKSIJITU</a></li>
                    <li><a href="https://gudang.andigustaf.com/login"><i class="fa fa-laptop"></i>ALAMANDA</a></li>
                    <li><a href="{{ route('statplanet.unduh') }}" title="unduh aplikasi statplanet"><i class="fa fa-download" title="unduh aplikasi statplanet"></i>STATPLANET</a></li>
                </ul>

            </div><!-- Header Top Links End -->

            <!-- Header Top Social Start -->
            <div class="header-top-social col-md-3 col-6">

                <!-- Header Social -->


            </div><!-- Header Top Social End -->
            <div class="header-top-links header-top-social col-md-3">
                <div class="float-right">
                    <ul class="header-links">
                        @if (auth()->user())
                            @if (auth()->user()->id == 1)
                                <a href="{{ route('home') }}">
                                    <span class="d-none d-md-inline">Hello, {!! strtok(auth()->user()->name, "2 ") !!}</span>
                                </a>
                            @else
                                <li class="nav-item dropdown user-menu">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                    <span class="d-none d-md-inline">Hello, {!! strtok(auth()->user()->name, "2 ") !!}</span>
                                </a>
                                <ul class="dropdown-menu dropdown" style="width:50%">
                                    <li class="user-footer">
                                        <a style="font-size:13px" href="{{ route('frontend.profile') }}" class="btn btn-default">Profile</a>
                                        <a style="font-size:13px" href="{{ route('frontend.history') }}" class="btn btn-default">History</a>
                                        <a style="font-size:13px" href="#" class="btn btn-default"
                                        onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                            Log Out
                                        </a>
                                        <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                                            @csrf
                                        </form>
                                    </li>
                                </ul>
                            </li>
                            @endif
                        @else
                            <li >
                            <a href="{{ route('login') }}"><i class="fa fa-user-circle-o"></i>SIGN IN</a>
                            </li>
                            <li >
                                <a href="{{ route('register') }}">REGISTER</a>
                            </li>
                        @endif
                    </ul>
                </div>
                <div class="header-social" style="padding-right:30px">
                    <ul>
                        @foreach($websetting as $value)
                            @switch($value->name)
                                @case('facebook')
                                <a href="{{ url($value->url) }}" title="{{ $value->value }}" target="_blank"><i class="fa fa-facebook"></i></a>
                                @break
                                @case('youtube')
                                <a href="{{ url($value->url) }}" title="{{ $value->value }}" target="_blank"><i class="fa fa-youtube-play"></i></a>
                                @break
                                @case('instagram')
                                <a href="{{ url($value->url) }}" title="{{ $value->value }}" target="_blank"><i class="fa fa-instagram"></i></a>
                                @break
                            @endswitch
                        @endforeach
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div><!-- Header Top End -->
