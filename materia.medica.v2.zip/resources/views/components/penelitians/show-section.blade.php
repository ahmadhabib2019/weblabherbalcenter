<div class="col-lg-5 col-12 mb-50">

    <!-- Post Block Wrapper Start -->
    <div class="post-block-wrapper">

        <!-- Post Block Body Start -->
        <div class="body">
                <!-- Post Start -->
                <div class="post fashion-post post-default-list post-separator-border">
                    <div class="post-wrap">
                        <!-- Content -->
                        <div class="post-content">

                            <!-- Title -->
                            <h3 ><a  href="#">Detail Penelitian</a> </h3>
                            <div>
                                <p ><a  href="#">Judul : </a> </p>
                                <p>{!! $detailPenelitian->title !!}</p>
                            </div>
                            <div>
                                <p ><a  href="#">Description : </a> </p>
                                <p>{!! $detailPenelitian->description !!}</p>
                            </div>

                            <!-- Meta -->
                            <div class="meta fix">
                                <a href="#" class="meta-item author"></i>  Tahun </a>
                                <span class="meta-item date">:</span>
                                <span class="meta-item date">{{ $detailPenelitian->year}}</span>
                            </div>
                            <div class="meta fix">
                                <a href="#" class="meta-item author"></i>  Jumlah Unduhan </a>
                                <span class="meta-item date">:</span>
                                <span class="meta-item date">{{ $detailPenelitian->download}}</span>
                            </div>

                            <!-- Description -->

                        </div>

                    </div>
                </div><!-- Post End -->
            <div class="d-flex">
                <div>
                        <a href="{{ route('welcome') }}"class="btn btn-danger btn-sm">Kembali</a>
                        <a href="{{ route('frontend.penelitians.unduh',[$detailPenelitian->id]) }}" class="btn btn-success btn-sm"><i class="fa fa-file-o"> </i> Download Dokumen</a>
                </div>
            </div>

        </div>
    </div>
</div>
<!-- Sidebar Start -->
<div class="col-lg-7 col-12 mb-50">

    <!-- Sidebar Block Body Start -->
    <div class="body">

        <div class="sidebar-social-follow">
            <iframe style="width:700px;height:587px" src="{{ $detailPenelitian->publication_link }}"  seamless="seamless" scrolling="no" frameborder="0" allowtransparency="true" allowfullscreen="true" ></iframe>
        </div>

    </div><!-- Sidebar Block Body End -->

</div><!-- Sidebar End -->
