<div class="blog-section section">
    <div class="container">

        <!-- Feature Post Row Start -->
        <div class="row">
            @isset($penelitians)
                <x-penelitians.index-section :penelitians="$penelitians"/>
            @else
                <x-penelitians.show-section :detailPenelitian="$detailPenelitian"/>
            @endisset
        </div><!-- Feature Post Row End -->

    </div>
</div>
