<div class="col-lg-8 col-12 mb-50">

    <!-- Post Block Wrapper Start -->
    <div class="post-block-wrapper">

        <!-- Post Block Body Start -->
        <div class="body">
            @if ($penelitians == null)
                <div class="single-blog mb-50">
                    <div class="blog-wrap" style="text-align: center;">
                        <h4 class="alert alert-danger"> Not Found! </h4>
                    </div>
                </div>
            @else
                @foreach ($penelitians as $data)
                @php 
                    $visitor = \App\Models\Visitor::where('page_id',$data->id)->where('slug',Request::segment(1))->count();
                @endphp
                    <!-- Post Start -->
                    <div class="post fashion-post post-default-list post-separator-border">
                        <div class="post-wrap">
                            <!-- Content -->
                            <div class="content col-md-8">

                                <!-- Title -->
                                <h4 class="title"><a  href="{{ route('frontend.penelitians.show',[$data->id])}}">{{ $data->title }} </a> </h4>                           

                                <!-- Meta -->
                                <div class="meta fix">
                                    <a href="#" class="meta-item author"><i class="fa fa-calendar"></i>  {{ $data->created_at->format('d-m-Y') }} </a>
                                    <span class="meta-item date"><i class="fa fa-eye">Viewer {{$visitor}}</i></span>
                                    <span class="meta-item date"><i class="fa fa-download"> Diunduh {{ $data->download }} Kali</i></span>
                                </div>

                                <!-- Description -->

                            </div>

                            <div class="col-md-4">
                                <!-- Image -->
                                <a class="image" href="#">
                                    <img height="150px" src="{{ asset($data->images) }}" alt="post">
                                </a>
                            </div>

                        </div>
                    </div><!-- Post End -->
                @endforeach
                <div class="d-flex">
                    <div class="mx-auto">
                        {{ $penelitians->links() }}
                    </div>
                </div>
            @endif
        </div>
    </div>
</div>
<x-article.sidebar-section />
