<div class="blog-section section mb-30">
    <div class="container">
        <!-- Feature Post Row Start -->
        <div class="row d-flex justify-content-center">
            <div class="col-lg-8 col-12 mb-50">
                <!-- Post Block Wrapper Start -->
                <div class="post-block-wrapper">
                    @if ($message = Session::get('info'))
                    <div class="alert alert-success alert-block" style="margin-top:10px ">
                        <button type="button" class="close" data-dismiss="alert">×</button>    
                        <strong>{{ $message }}</strong>
                    </div>
                    @endif
                    <!-- Post Block Head Start -->
                    <div class="head d-flex justify-content-center">
                        <!-- Title -->
                        <h4 class="title">
                            Data Registrasi : {{ $registration->user->name }}
                        </h4>
                    </div><!-- Post Block Head End -->
                    <!--  -->
                    @if($registration->agreement == "pending")
                        @php 
                            $status = "Menunggu Persetujuan"; 
                            $color = "orange";
                        @endphp
                    @elseif($registration->agreement == "ya")
                        @php 
                            $status = "Disetujui"; 
                            $color = "green";
                        @endphp
                    @else
                        @php 
                            $status = "Tidak Disetujui"; 
                            $color = "red";
                        @endphp
                    @endif
                    <!-- Post Block Body Start -->
                    <div class="body">
                        <div class="post-comment-form">
                            <table class="table">
                                <tr>
                                    <th>Nama</th>
                                    <td>{{ $registration->user->name }}</td>
                                </tr>
                                <tr>
                                    <th>Layanan</th>
                                    <td>{{ $registration->services->title }}</td>
                                </tr>
                                @isset($registration->options)
                                <tr>
                                    <th>Jenis</th>
                                    <td>{{ $registration->options }}</td>
                                </tr>
                                @endisset
                                <tr>
                                    <th>Tanggal Daftar</th>
                                    <td>{{ \Carbon\Carbon::parse($registration->created_at)->setTimezone('Asia/Jakarta')->locale('id')->isoFormat('dddd, Do MMMM YYYY, h:mm') }}
                                    </td>
                                </tr>
                                <tr>
                                    <th>Status</th>
                                    <td><a style="color:{{$color}}"> {{ $status }} </a></td>
                                </tr>
                            </table>
                        </div>
                        <hr>
                        @if($registration->services_id != 2)
                        <div class="post-comment-form">
                            <table class="table">
                                <tr>
                                    <th colspan="2">Data Pertanyaan</th>
                                </tr>
                                @foreach ($registration->registrationValues as $key => $item)
                                <tr>
                                    @if(Str::substr($item->question->question, 0, 6) == 'Upload')
                                        <th></th>
                                    @else
                                    <th class="col-md-5"> {{ $item->question->question }} </th>
                                    @endif
                                    @if ($item->question->type == 'date_range')
                                            @php
                                                $item_value = json_decode($item->values);
                                            @endphp
                                        <td> Mulai {{ $item_value[0]  }} sampai dengan {{ $item_value[1]  }} </td>
                                    @elseif($item->question->type == 'checkbox')
                                        @php
                                            $item_value = json_decode($item->values);
                                        @endphp
                                        <td> 
                                            @foreach($item_value as $key=> $value)
                                                <a>{{$value}}, </a>
                                            @endforeach
                                        </td>
                                    @else
                                        @if (Str::substr($item->values, 0, 7) == 'storage')
                                            <td> </td>
                                        @else
                                            <td>{{ $item->values }}</td>
                                        @endif
                                    @endif
                                </tr>
                                @endforeach
                            </table>
                        </div>
                        @endif
                        <a href="{{ route('welcome') }}" class="btn btn-info">Back</a>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
