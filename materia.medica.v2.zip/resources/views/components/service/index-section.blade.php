<div class="blog-section section mt-30">
    <div class="container">
        <!-- Feature Post Row Start -->
        <div class="row d-flex justify-content-center">
            <div class="col-lg-8 col-12 mb-50 d-flex justify-content-center ">
                <!-- Post Block Wrapper Start -->
                <div class="post-block-wrapper">
                    <!-- Post Block Head Start -->
                    <div class="head">
                        <!-- Title -->
                        <h4 class="title">Layanan {!! $service->title !!}</h4>
                    </div><!-- Post Block Head End -->
                    <!-- Post Block Body Start -->
                    <div class="body">
                        <div class="post-comment-form">
                            <form action=""class="row">
                                <div class="col-md-12 mb-20">
                                    <label for="name"><h4>Deskripsi Layanan :</h4></label>
                                   
                                    <div class="post-carousel-1">
                                        @foreach ($service->serviceFile as $item)
                                        <div class="post post-overlay hero-post">
                                            <div class="post-wrap">
                                                <!-- Image -->
                                                <a class="image" href="{{asset($item->src)}}"><img alt="tes" src="{{ asset($item->src) }}">
                                                </a>
                                                <!-- Category -->
                                                <!-- Content -->
                                            </div>
                                        </div><!-- Overlay Post End -->
                                        @endforeach
                                    </div>
                                    <br>
                                    <div style="padding-left:30px;" class="border border-grey"> {!! $service->description !!} </div>
                                </div>
                                <div class="col-md-12 mb-20">
                                    <label for="email"><h4>Fasilitas :</h4></label>
                                    <div style="padding-left:30px;" class="border border-grey"> {!! $service->facilities !!} </div>
                                </div>
                                <div class="col-12 mb-20">
                                    <label for="website"><h4>Persyaratan Pelayanan  :</h4></label>
                                    <div style="padding-left:30px;" class="border border-grey"> {!! $service->requirements !!} </div>
                                </div>
                                <div class="col-12 mb-20">
                                    <label for="message"><h4>Jangka Waktu Penyelesaian :</h4></label>
                                    <div style="padding-left:30px;" class="border border-grey"> {!! $service->time_period !!} </div>
                                </div>
                                <div class="col-12 mb-20">
                                    <label for="message"><h4>Biaya :</h4></label>
                                    <div style="padding-left:30px;" class="border border-grey"> {!! $service->price !!} </div>
                                </div>
                                <div class="col-12 mb-20">
                                    <label for="message"><h4>Jaminan Pelayanan:</h4></label>
                                    <div style="padding-left:30px;" class="border border-grey"> {!! $service->guarantee !!} </div>
                                </div>
                                <div class="col-12 mb-20">
                                    <label for="message"><h4>Contact Person:</h4></label>
                                    <div style="padding-left:30px;" class="border border-grey"> Name : <a href="http://wa.me/62{{ $service->contact_persons->phone }}">{!! $service->contact_persons->name !!} </a></div>
                                </div>

                            </form><br></br>
                            <div class="row">
                                @if(Request::is('service/show/herbalmart') || Request::is('service/show/bibit-tanaman-obat') == 'true')
                                    <div Class="col-10" >
                                        <a href="{{ route('herbalmart.katalog',[$service->slug]) }}" class="btn btn-info" type="button">KATALOG PRODUK</a>
                                    </div>
                                    <div class="col-2 float-left">
                                        @if(Request::is('service/show/herbalmart') == true)
                                            <a href="{{ route('herbalmart.form',Request::segment(3)) }}" class="btn btn-info" type="button">Pesan</a>
                                        @elseif(Request::is('service/show/bibit-tanaman-obat') == true)
                                            <a href="{{ route('herbalmart.form',Request::segment(3)) }}" class="btn btn-info" type="button">Pesan</a>
                                        @endif
                                    </div>

                                @elseif(isset($_GET['option']))
                                    @if($_GET['option'] == 'open')
                                        <div class="col-12">
                                            <a href="{{ route('frontend.workshop.openclass',['option'=>'Open Class'])  }}" class="btn btn-info" style="width: 100%">Lihat Workshop</a>
                                        </div>
                                    @elseif($_GET['option'] == 'offline' || $_GET['option'] == 'online')
                                        <div class="col-12">
                                            <a href="{{ route('frontend.service.register', [$service->id, $service->slug]) }}" class="btn btn-info" style="width: 100%">Daftar</a>
                                        </div>
                                    @endif
                                @else
                                    @if($service->id <= 16)
                                        <div class="col-12">
                                            <a href="{{ route('frontend.service.register', [$service->id, $service->slug])  }}" class="btn btn-info" style="width: 100%">Daftar</a>
                                        </div>
                                    @endif
                                @endif
                            </div>
                        </div>
                    </div><!-- Post Block Body End -->
                </div><!-- Post Block Wrapper End -->
            </div>

        </div><!-- Feature Post Row End -->

    </div>
</div>
@push('styles')
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ekko-lightbox/5.3.0/ekko-lightbox.css" integrity="sha512-Velp0ebMKjcd9RiCoaHhLXkR1sFoCCWXNp6w4zj1hfMifYB5441C+sKeBl/T/Ka6NjBiRfBBQRaQq65ekYz3UQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
@endpush

@push('scripts')
    <script src="https://cdnjs.cloudflare.com/ajax/libs/ekko-lightbox/5.3.0/ekko-lightbox.min.js" integrity="sha512-Y2IiVZeaBwXG1wSV7f13plqlmFOx8MdjuHyYFVoYzhyRr3nH/NMDjTBSswijzADdNzMyWNetbLMfOpIPl6Cv9g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <script>
        $(document).on("click", '[data-toggle="lightbox"]', function(event) {
            event.preventDefault();
            $(this).ekkoLightbox();
        });
    </script>
@endpush