<div class="blog-section section mb-30">
    <div class="container">
        <!-- Feature Post Row Start -->
        <div class="row d-flex justify-content-center">
            <div class="col-lg-8 col-12 mb-50">
                <!-- Post Block Wrapper Start -->
                <div class="post-block-wrapper">
                    <!-- Post Block Head Start -->
                    <div class="head d-flex justify-content-center">
                        <!-- Title -->
                        <h4 class="title">{{ $formRegistration->name }} </h4>
                    </div><!-- Post Block Head End -->
                    <!-- Post Block Body Start -->
                    <div class="body">
                            {!! Form::open(['route' => ['service.registerForm.store', $formRegistration->service->id], 'id' => 'form', 'files' => true]) !!}
                            {!! Form::hidden('options', request()->has('option') ? request()->get('option') : null) !!}
                            {!! Form::hidden('user_id', auth()->user()->id) !!}
                            @foreach ($formRegistration->formRegistrationContents as $item)
                            <div class="container">
                                <div class="row">
                                    <div class="col-md-5" style="padding-bottom:20px">
                                    <label for="" class=""><b>{{ $item->question->question }}</b></label>
                                    </div>
                                    <div class="col-md-7 form">
                                        @switch($item->question->type)
                                            @case('dropdown')
                                                @php
                                                    $options = explode("\n", $item->question->option);
                                                @endphp
                                                <div class="row">
                                                    <div class="col-sm-12" id="option-wrapper" style="padding-bottom:20px">
                                                        <select class="form-control" name="question[{{ $item->question->id }}]"
                                                            required
                                                            id="type">
                                                            @foreach ($options as $i)
                                                                <option value="{{ $i }}">{{ $i }}</option>
                                                            @endforeach
                                                        </select>
                                                    </div>
                                                </div>
                                            @break
                                            @case('date')
                                            <div class="row">
                                                <div class="col-sm-6">
                                                    <div class="input-group date" id="datetimepicker1"
                                                        data-target-input="nearest">
                                                        <input type="text" name="question[{{ $item->question->id }}]"
                                                            class="form-control datetimepicker-input"
                                                            data-target="#datetimepicker1" />
                                                        <div class="input-group-append" data-target="#datetimepicker1"
                                                            data-toggle="datetimepicker">
                                                            <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            @break
                                            @case('date_range')
                                            <div class="row">
                                                <div class="col-sm-6">
                                                    <div class="input-group date" id="datetimepicker2"
                                                        data-target-input="nearest">
                                                        <input type="text" name="question[{{ $item->question->id }}][]"
                                                            class="form-control datetimepicker-input"
                                                            data-target="#datetimepicker2" />
                                                        <div class="input-group-append" data-target="#datetimepicker2"
                                                            data-toggle="datetimepicker">
                                                            <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div class="input-group date" id="datetimepicker3"
                                                        data-target-input="nearest">
                                                        <input type="text" name="question[{{ $item->question->id }}][]"
                                                            class="form-control datetimepicker-input"
                                                            data-target="#datetimepicker2" />
                                                        <div class="input-group-append" data-target="#datetimepicker3"
                                                            data-toggle="datetimepicker">
                                                            <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            @break
                                            @case('textarea')
                                                        <textarea name="question[{{ $item->question->id }}]" id="" cols="30"
                                                            rows="10" class="form-control"></textarea>
                                            @break
                                            @case('download')
                                                        <a href="{{ route('frontend.service.unduh', [$item->question->id]) }}"
                                                            class="btn btn-success btn-sm"><i class="fa fa-file-o"> </i> Download
                                                            Dokumen</a>
                                            @break
                                            @case('upload')
                                                        <input type="file" name="question[{{ $item->question->id }}]" required
                                                            class="form-control">
                                            @break
                                            @case('number')
                                                        <input type="number" min="1" value="1"
                                                            name="question[{{ $item->question->id }}]" required
                                                            class="form-control">
                                            @break
                                            @case('time')
                                                        <input type="time" min="1" name="question[{{ $item->question->id }}]"
                                                            required class="form-control">
                                            @break
                                            @case('checkbox')
                                                @php
                                                    $options = explode("\n", $item->question->option);
                                                @endphp
                                                <div class="col-sm-12" style="padding-bottom:20px">
                                                    @foreach ($options as $i)
                                                        <input style="width:20px"type="checkbox" name="question[{{ $item->question->id }}][]">{{ $i }}</input>
                                                    @endforeach
                                                </div>
                                            @break
                                            @default
                                                        <input type="text" name="question[{{ $item->question->id }}]"
                                                            class="form-control">
                                            @break
                                        @endswitch
                                    </div>
                                </div>
                            </div>
                            
                                
                            @endforeach
                            <div class="form-group row">
                                {!! Form::submit('Register', ['class' => 'btn btn-primary']) !!}
                            </div>
                            {!! Form::close() !!}
                    </div><!-- Post Block Body End -->
                </div><!-- Post Block Wrapper End -->
            </div>
        </div><!-- Feature Post Row End -->
    </div>
</div>


@push('styles')
    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/tempusdominus-bootstrap-4/5.39.0/css/tempusdominus-bootstrap-4.min.css">
@endpush

@push('scripts')
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"
        integrity="sha512-qTXRIMyZIFb8iQcfjXWCO8+M5Tbc38Qi5WzdPOYZHIlZpzBHG3L3by84BBBOiRGiEb7KKtAOAs5qYdUiZiQNNQ=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/tempusdominus-bootstrap-4/5.39.0/js/tempusdominus-bootstrap-4.js"
        integrity="sha512-1+GNKHQ9yw2vSBLvpsquZDJh0ktonnPGPkYBNd7Xh85jnvibX7MQaVLQEeTQBhcSSFLYu6DAefDsn/KFQo/YNQ=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script type="text/javascript">
        $(function() {
            $('#datetimepicker1').datetimepicker({
                sideBySide: true,
                format: 'YYYY-MM-DD',
                daysOfWeekDisabled: [0, 6]

            });
            $('#datetimepicker2').datetimepicker({
                sideBySide: true,
                format: 'YYYY-MM-DD',
                daysOfWeekDisabled: [0, 6]

            });
            $('#datetimepicker3').datetimepicker({
                sideBySide: true,
                format: 'YYYY-MM-DD',
                daysOfWeekDisabled: [0, 6],
                useCurrent: false

            });
            $("#datetimepicker2").on("change.datetimepicker", function(e) {
                $('#datetimepicker3').datetimepicker('minDate', e.date);
            });
            $("#datetimepicker3").on("change.datetimepicker", function(e) {
                $('#datetimepicker2').datetimepicker('maxDate', e.date);
            });
            $('#type').on('change',function(){
                var $type = $(this).val();
                console.log($type);
                if($type == 'Lainya' || $type == 'Etahol..%'){
                    $('#option-wrapper2').removeClass('d-none');                            
                }
            });
        });
    </script>
@endpush
