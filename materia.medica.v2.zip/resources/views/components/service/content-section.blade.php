<div class="col-lg-8 col-12 mb-50">
    <div class="container">
        <div class="row" style="padding:25px 0px">
            <div class="row">
                <!-- Footer Widget Start -->
                <div class="col-12">
                    <!-- Title -->
                    <h3 class="">{{ $service->title}}</h3>
                    <!-- Footer Widget Post Start -->
                    <div class="footer-widget-post">
                        <h4>Deskripsi Layanan</h4>
                            <div class="post-wrap" style="padding-left:20px">
                                <a>{!! $service->description !!}</a>
                            </div>
                    </div>
                    <div class="footer-widget-post">
                        <h4>Fasilitas</h4>
                            <div class="post-wrap" style="padding-left:20px">
                                <a>{!! $service->facilities !!}</a>
                            </div>
                    </div>
                    <div class="footer-widget-post">
                        <h4>Persyaratan Layanan</h4>
                            <div class="post-wrap" style="padding-left:20px">
                                <a>{!! $service->requirements !!}</a>
                            </div>
                    </div>
                    <div class="footer-widget-post">
                        <h4>Jangka Waktu Penyelesaian</h4>
                            <div class="post-wrap" style="padding-left:20px">
                                <a>{!! $service->time_period !!}</a>
                            </div>
                    </div>
                    <div class="footer-widget-post">
                        <h4>Biaya</h4>
                            <div class="post-wrap" style="padding-left:20px">
                                <a>{!! $service->price !!}</a>
                            </div>
                    </div>
                    <div class="footer-widget-post">
                        <h4>Jaminan Pelayanan</h4>
                            <div class="post-wrap" style="padding-left:20px">
                                <a>{!! $service->guarantee !!}</a>
                            </div>
                    </div>
                    <div class="footer-widget-post">
                        <h4>Contac Person</h4>
                            <div class="post-wrap" style="padding-left:20px">
                                <a  href="https://api.whatsapp.com/send?phone=62{{ $service->contact_persons->phone }}">
                                    <i></i>{!! $service->contact_persons->name !!} : 0{!! $service->contact_persons->phone !!}
                                </a>
                            </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
