<div class="blog-section section mt-30">
    <div class="container">
        <!-- Feature Post Row Start -->
        <div class="row d-flex justify-content-center">
            <div class="col-lg-8 col-12 mb-50">
                <!-- Post Block Wrapper Start -->
                <div class="post-block-wrapper">
                    <!-- Post Block Head Start -->
                    <div class="head d-flex justify-content-center">
                        <!-- Title -->
                        <h4 class="title">Kategori Layanan {{ $service->title }}</h4>
                    </div><!-- Post Block Head End -->
                    <!-- Post Block Body Start -->
                    <div class="body">
                        <div class="post-comment-form">

                            @foreach ($options as $item)
                                <div class="col-md-12 mb-20 d-flex justify-content-center">
                                    @if($item == 'Open Class')
                                        <a href="{{ route('frontend.workshop.openclass',['option'=>$item])  }}" class="btn btn-info" style="width: 100%">{{ ucfirst($item) }}</a>
                                @else
                                        <a href="{{ route('frontend.service.registerForm',[$service->id,'option'=>$item])  }}" class="btn btn-info" style="width: 100%">{{ ucfirst($item) }}</a>
                                    @endif
                                </div>
                            @endforeach

                        </div>
                    </div><!-- Post Block Body End -->
                </div><!-- Post Block Wrapper End -->
            </div>
        </div><!-- Feature Post Row End -->
    </div>
</div>
