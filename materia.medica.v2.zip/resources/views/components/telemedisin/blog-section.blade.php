<div class="blog-section section">
    <div class="container">
        <!-- Feature Post Row Start -->
        <div class="row">
            @isset($telemedisin)
                <x-telemedisin.show-section :telemedisin="$telemedisin"/>/>
            @else
                <x-telemedisin.index-section :tele="$tele"/>
            @endisset
        </div><!-- Feature Post Row End -->
    </div>
</div>
