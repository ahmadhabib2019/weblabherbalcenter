<div class="col-lg-8 col-12 mb-50">

    <!-- Post Block Wrapper Start -->
    <div class="post-block-wrapper">

        <!-- Post Block Body Start -->
        <div class="body">
            
            <!-- Post Start -->
            <div class="post-comment-form">
                       @foreach($telemedisin as $data)
                            <h5 class="title"><a><b>{{ $data->user->name }} | {{$data->created_at}} </b></a></h5>
                            <!-- Read More -->
                            <b> Pertanyaan :</b> {{$data->pertanyaan}} <br>
                            <b> Jawaban :</b> {{$data->jawaban}} 
                        @endforeach

            </div>
        </div>
    </div>
</div>
<x-article.sidebar-section />
