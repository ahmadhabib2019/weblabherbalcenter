<div class="col-lg-8 col-12 mb-50">

    <!-- Post Block Wrapper Start -->
    <div class="post-block-wrapper">
        @if ($message = Session::get('info'))
        <div class="alert alert-success alert-block" style="margin-top:10px ">
            <button type="button" class="close" data-dismiss="alert">×</button>    
            <strong>{{ $message }}</strong>
        </div>
        @endif
        <!-- Post Block Body Start -->
        <div class="body">
            
            <!-- Post Start -->
            <b>Ajukan Pertanyaan :</b>
            <div class="post-comment-form">
                <form method="POST" action="{{ route('frontend.tele.store') }}" enctype="multipart/form-data">
                    
                    @csrf            
                    
                    <!-- {!! Form::label('', '') !!} -->

                    <div class="form-group col-sm-12">
                        {!! Form::label('', '') !!}
                        {!! Form::textarea('pertanyaan', null, ['class' => 'form-control','style'=>'background:#eee']) !!}
                    </div>

                        <!-- User Id Field -->
                    <div class="col-12">
                        <input type="submit" name="Kirim" id="Kirim">
                    </div>
                </form>
            </div>
                <hr>
                @foreach($tele as $data)
                    <h5 class="title"><a><b>{{$data->user->name}} | {{$data->created_at}}</b></a></h5>
                    {!! Str::substr($data->pertanyaan, 0, 100); !!}

                    <!-- Read More -->
                    <a href="{{route('frontend.telemedisin.show',[$data->id])}}">... Baca Selengkapnya</a>
                @endforeach
        </div>
        <div class="d-flex">
                    <div class="mx-auto">
                        {{ $tele->links() }}
                    </div>
                </div>
    </div>
</div>
<x-article.sidebar-section />
