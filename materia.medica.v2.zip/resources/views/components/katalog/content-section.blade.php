<div class="col-lg-12 col-12 mb-50">
    <div style="margin-top: 10px;">
    @if(Request::segment(3) == 'herbalmart')
    <h3 style="color:#17A2B8"><b>Herbal Mart</b></h3>
    @else
    <h3 style="color:#17A2B8"><b>Bibit Tanaman Obat</b></h3>
    @endif
    
    </div>

    <div class="post-block-wrapper">
        <div class="body">
            <div class="row">
                @foreach ($produk as $item)
                    <div class="post sports-post post-separator-border col-md-2">
                        <div class="post-wrap">
                            <a class="" data-toggle="lightbox" data-gallery="gallery"
                                href="{{ asset($item['produkImages'][0]['src']) }}">
                                <img class="img-thumbnail" src="{{ $item['produkImages'][0]['src'] ? $item['produkImages'][0]['src'] : asset('frontend/img/logo-2.png')}}"
                                    alt="{{ asset($item['src']) }}">
                            </a>
                            <div class="content" style="text-align: center;padding-top: 10px;">
                                <h5 class="title"><a href="{{ route('herbalmart.katalog.detail',[$item['id']])}}">{!! Str::substr($item['nama'], 0, 25); !!}</a></h5>
                            </div>
                            <div class="content" style="text-align: center;padding-top: 10px;">
                                <a class="title">Rp. @php echo number_format($item['price'],0,',','.') @endphp</a>
                            </div>
                            <div class="content" style="text-align: center;padding-top: 10px;">
                                @if($item['stok'] == 0)
                                    <button class="btn btn-danger btn-block btn-sm">Kosong</button>
                                @else
                                    <button class="btn btn-info btn-block btn-sm">Tersedia</button>
                                @endif
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
            {{$produk->links()}}
        </div>
    </div>
</div>

@push('styles')
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ekko-lightbox/5.3.0/ekko-lightbox.css" integrity="sha512-Velp0ebMKjcd9RiCoaHhLXkR1sFoCCWXNp6w4zj1hfMifYB5441C+sKeBl/T/Ka6NjBiRfBBQRaQq65ekYz3UQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
@endpush

@push('scripts')
    <script src="https://cdnjs.cloudflare.com/ajax/libs/ekko-lightbox/5.3.0/ekko-lightbox.min.js" integrity="sha512-Y2IiVZeaBwXG1wSV7f13plqlmFOx8MdjuHyYFVoYzhyRr3nH/NMDjTBSswijzADdNzMyWNetbLMfOpIPl6Cv9g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <script>
        $(document).on("click", '[data-toggle="lightbox"]', function(event) {
            event.preventDefault();
            $(this).ekkoLightbox();
        });
    </script>
@endpush