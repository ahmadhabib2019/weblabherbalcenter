<div class="blog-section section mb-30">
    <div class="container">
        <!-- Feature Post Row Start -->
        <div class="row d-flex justify-content-center">
            <div class="col-lg-8 col-12 mb-50">
                <!-- Post Block Wrapper Start -->
                <div class="post-block-wrapper">
                    @if ($message = Session::get('info'))
                    <div class="alert alert-success alert-block" style="margin-top:10px ">
                        <button type="button" class="close" data-dismiss="alert">×</button>    
                        <strong>{{ $message }}</strong>
                    </div>
                    @endif
                    <!-- Post Block Head Start -->
                    <div class="head d-flex justify-content-center">
                        <!-- Title -->
                        <h4 class="title">
                            List Produk Yang Anda Pesan
                        </h4>
                    </div><!-- Post Block Head End -->
                    <!-- Post Block Body Start -->
                    <div class="body">
                        <div class="post-comment-form">
                            <tr>
                                <th >Kode Transaksi :</th>
                                <th  class="text-left" >{{ $produkOrder->kode_trans}}</th>
                            </tr> 
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Nama Produk</th>
                                        <th>Jenis Produk</th>
                                        <th>Qty</th>
                                        <th>Harga</th>
                                        <th>Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @php $total = 0; @endphp
                                    @foreach($produkOrder->produkOrderDetail as $data)
                                        <tr>
                                            <td>{{ $data->produk->nama}}</td>
                                            <td>{{ $data->kategori->name}}</td>
                                            <td>{{ $data->qty}}</td>
                                            <td>Rp.@php echo number_format($data->produk->price,0,',','.') @endphp</td>
                                            <td>Rp.@php echo number_format($data->total,0,',','.') @endphp</td>
                                        </tr>
                                            @php $total += $data->total @endphp
                                    @endforeach
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th colspan="4">Total</th>
                                        <th>Rp.@php echo number_format($total,0,',','.') @endphp</th>
                                    </tr>
                                    <tr>
                                        <td colspan="5">
                                            Konfirmasi pesanan : <a href="http://wa.me/62{{ $service->contact_persons->phone }}">0{{ $service->contact_persons->phone }}</a>
                                        </td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                        <a href="{{ route('welcome')  }}" class="btn btn-info btn-sm">Back</a>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
