<div class="blog-section section">
    <div class="container">
        <!-- Feature Post Row Start -->
        <div class="row d-flex d-flex justify-content-center">

            <div class="col-lg-8 col-12 mb-50">
                <!-- Post Block Wrapper Start -->
                <div class="post-block-wrapper">
                    <!-- Post Block Head Start -->
                    <div class="head d-flex justify-content-center">
                        <!-- Title -->
                        <h3 class="title">Herbal Mart</h3>
                    </div><!-- Post Block Head End -->
                    <!-- Post Block Body Start -->
                    {!! Form::open(['route' => 'herbalmart.store','method'=>'post']) !!}
                        <div class="body">
                            <table class="table">
                                <tr>
                                    <div class="row ">
                                        <div class="container">
                                            <div class="row">
                                                <div class="col-sm-12 ">
                                                    <input type="hidden" value="{{ Request::segment(3) }}" name="url">
                                                    <input type="hidden" value="{{ auth()->user()->id }}" name="user_id">

                                                    <label for="">Pilih Produk Simplisia</label></input>
                                                </div>

                                                <div class="col-7">
                                                    <select class="form-control select-barang1" id="simplisia_id">
                                                        <option value="">-- Pilih Barang --</option>
                                                        @foreach($produk1 as $key => $value)
                                                            <option value="{{$value->id}}">{{$value->nama}} - Rp.@php echo number_format($value['price'],0,',','.') @endphp</option>
                                                        @endforeach
                                                    </select>
                                                <input type="hidden" id="price1" value="_price">
                                                <input type="hidden" id="kategori1" value="_price">
                                                <input type="hidden" id="stok" value="_stok">
                                                </div>
                                                <div style="width:60px">
                                                    <input placeholder=".." type="number" min="1" class="form-control" id="qty1" value="1">
                                                </div>
                                                <div class="form-group col-1">
                                                    <button class="btn btn-success btn-sm" id="addMore" type="button">
                                                        <i class="fa fa-plus"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </tr>
                            </table>
                            <table style="">
                                <div class="row addRow" id="addRow" width=30%>

                                </div>
                            </table>
                                <hr>
                            <table class="table2">
                                <tr>
                                    <div class="row">
                                        <div class="container">
                                            <div class="row">
                                                <div class="col-sm-12">
                                                    <label for="">Pilih Produk Serbuk</label></input>
                                                </div>

                                                <div class="col-7">
                                                    <select class="form-control select-barang2" id="serbuk_id">
                                                        <option value="">-- Pilih Barang --</option>
                                                        @foreach($produk2 as $key => $value)
                                                            <option value="{{$value->id}}">{{$value->nama}} - Rp.@php echo number_format($value['price'],0,',','.') @endphp</option>
                                                        @endforeach
                                                    </select>
                                                    <input type="hidden" id="price2" value="_price">
                                                <input type="hidden" id="kategori2" value="_price">
                                                </div>
                                                <div style="width:60px">
                                                    <input placeholder=".." type="number" min="1" class="form-control" id="qty2" value="1">
                                                </div>
                                                <div class="form-group col-1">
                                                    <button class="btn btn-success btn-sm" id="addMore2" type="button">
                                                        <i class="fa fa-plus"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </tr>
                            </table>
                            <table style="">
                                <div class="row addRow2" id="addRow2" width=30%>

                                </div>
                            </table>
                            <hr>
                            <table class="table3">
                                <tr>
                                    <div class="row">
                                        <div class="container">
                                            <div class="row">
                                                <div class="col-sm-12">
                                                    <label for="">Pilih Paket Starter Kit</label></input>
                                                </div>

                                                <div class="col-7">
                                                    <select class="form-control select-barang3" id="starterkit_id">
                                                        <option value="">-- Pilih Barang --</option>
                                                        @foreach($produk3 as $key => $value)
                                                            <option value="{{$value->id}}">{{$value->nama}} - Rp.@php echo number_format($value['price'],0,',','.') @endphp</option>
                                                        @endforeach
                                                    </select>
                                                    <input type="hidden" id="price3" value="_price">
                                                <input type="hidden" id="kategori3" value="_price">
                                                </div>
                                                <div style="width:60px">
                                                    <input placeholder=".." type="number" min="1" class="form-control" id="qty3" value="1">
                                                </div>
                                                <div class="form-group col-1">
                                                    <button class="btn btn-success btn-sm" id="addMore3" type="button">
                                                        <i class="fa fa-plus"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </tr>
                            </table>
                            <table style="">
                                <div class="row addRow3" id="addRow3" width=30%>

                                </div>
                            </table>
                            <br><hr>
                            <div class="col-sm-3">
                                <div>
                                    <button class="btn btn-info" type="submit">Checkout</button>
                                </div>
                            </div>
                        </div><!-- Post Block Body End -->
                    {!! Form::close() !!}
                </div><!-- Post Block Wrapper End -->
            </div>
        </div><!-- Feature Post Row End -->
    </div>
</div>
@push('scripts')
         <!-- dynamic handlers -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/handlebars.js/4.4.2/handlebars.min.js"></script>
<!-- section script Simplisia -->
<script id="document-template" type="text/x-handlebars-template">
        <div class="delete_add_more_item container" id="delete_add_more_item">
            <div class="row" style="margin-bottom:10px">
                <div class="col-7">
                    <input type="text" value="@{{ question_name }}" class="form-control" readonly>
                    <input type="hidden" name="produk_id[]" value="@{{ simplisia_id }}" class="form-control" readonly>
                </div>
                <div style="width:60px">
                    <input type="text" name="qty[]" value="@{{ qty1 }}" class="form-control" readonly>
                </div>
                <div class="col-2">
                    <input type="text" name="subtotal[]" value="@{{ subtotal1 }}" class="form-control" readonly>
                    <input type="text" name="kategori[]" value="@{{ kategori }}" class="form-control" readonly style="display:none">
                </div>
                <div class="col-1" style="margin-left:-16px">
                    <button class="btn btn-danger btn-sm removeaddmore" type="button">
                        <i class="fa fa-minus"></i>
                    </button>
                </div>
            </div>
        </div>
 </script>
<!-- Section Script Serbuk -->
 <script id="document-template2" type="text/x-handlebars-template">
        <div class="delete_add_more_item2 container" id="delete_add_more_item2">
            <div class="row" style="margin-bottom:10px">
                <div class="col-7">
                    <input type="text" value="@{{ question_name }}" class="form-control" readonly>
                    <input type="hidden" name="produk_id[]" value="@{{ serbuk_id }}" class="form-control" readonly>
                </div>
                <div style="width:60px">
                    <input type="text" name="qty[]" value="@{{ qty2 }}" class="form-control" readonly>
                </div>
                <div class="col-2">
                    <input type="text" name="subtotal[]" value="@{{ subtotal2 }}" class="form-control" readonly>
                    <input type="text" name="kategori[]" value="@{{ kategori }}" class="form-control" readonly style="display:none">
                </div>
                <div class="col-1" >
                    <button class="btn btn-danger btn-sm removeaddmore2" type="button">
                        <i class="fa fa-minus"></i>
                    </button>
                </div>
            </div>
        </div>
 </script>
<!-- Section Starter Kit -->
 <script id="document-template3" type="text/x-handlebars-template">
        <div class="delete_add_more_item3 container" id="delete_add_more_item3">
            <div class="row" style="margin-bottom:10px">
                <div class="col-7">
                    <input type="text" value="@{{ question_name }}" class="form-control" readonly>
                    <input type="hidden" name="produk_id[]" value="@{{ starterkit_id }}" class="form-control" readonly>
                </div>
                <div style="width:60px">
                    <input type="text" name="qty[]" value="@{{ qty3 }}" class="form-control" readonly>
                </div>
                <div class="col-2">
                    <input type="text" name="subtotal[]" value="@{{ subtotal3 }}" class="form-control" readonly>
                    <input type="text" name="kategori[]" value="@{{ kategori }}" class="form-control" readonly style="display:none">
                </div>
                <div class="col-1" >
                    <button class="btn btn-danger btn-sm removeaddmore3" type="button">
                        <i class="fa fa-minus"></i>
                    </button>
                </div>
            </div>
        </div>
 </script>

<script type="text/javascript">
    $('.select-barang1').on("change", function(e) {
        var id = $(this).val();
        $.get("/produk/search/"+id, function(data, status){
            $('#price1').val(data[0]['price']);
            $('#kategori1').val(data[0]['kategori_id']);
            $('#stok').val(data[0]['stok']);
            var text = "Stok barang tersisa";
                if($('#stok').val() <= 0){
                confirm("Stok barang yang anda pilih kosong");
                }
                else if($('#stok').val() < 5){
                alert([text , $('#stok').val()]);
                }
        });
    });
    $('#addMore').on('click', function() {
        $('.table').show();
        var subtotal1 = parseInt($('#price1').val()) * $("#qty1").val();
        var simplisia_id = $("#simplisia_id").val();
        var qty1 = $("#qty1").val();
        var price = $("#price").val();
        var kategori = parseInt($('#kategori1').val());
        var question_name = $("#simplisia_id option:selected").text();
        var source = $("#document-template").html();
        var template = Handlebars.compile(source);

        var data = {
            simplisia_id: simplisia_id,
            question_name: question_name,
            qty1: qty1,
            kategori: kategori,
            subtotal1: subtotal1,
        }
        var html = template(data);
        $("#addRow").append(html)
    });
    $(document).on('click', '.removeaddmore', function(event) {
        $(this).closest('.delete_add_more_item').remove();
    });
</script>

<script type="text/javascript">
    $('.select-barang2').on("change", function(e) {
        var id = $(this).val();
        $.get("/produk/search/"+id, function(data, status){
            $('#price2').val(data[0]['price']);
            $('#kategori2').val(data[0]['kategori_id']);
            $('#stok').val(data[0]['stok']);
            var text = "Stok barang tersisa";
                    if($('#stok').val() <= 0){
                    confirm("Stok barang yang anda pilih kosong");
                    }
                    else if($('#stok').val() < 5){
                    alert([text , $('#stok').val()]);
                    }
        });
    });
    $('#addMore2').on('click', function() {
        $('.table2').show();
        var subtotal2 = parseInt($('#price2').val()) * $("#qty2").val();
        var serbuk_id = $("#serbuk_id").val();
        var qty2 = $("#qty2").val();
        var kategori = $("#kategori2").val();
        var question_name = $("#serbuk_id option:selected").text();
        var source = $("#document-template2").html();
        var template = Handlebars.compile(source);

        var data = {
            serbuk_id: serbuk_id,
            question_name: question_name,
            qty2: qty2,
            kategori: kategori,
            subtotal2: subtotal2,
        }

        var html = template(data);
        $("#addRow2").append(html)
    });
    $(document).on('click', '.removeaddmore2', function(event) {
        $(this).closest('.delete_add_more_item2').remove();
    });
</script>

<script type="text/javascript">
    $('.select-barang3').on("change", function(e) {
        var id = $(this).val();
        $.get("/produk/search/"+id, function(data, status){
            $('#price3').val(data[0]['price']);
            $('#kategori3').val(data[0]['kategori_id']);
            $('#stok').val(data[0]['stok']);
            var text = "Stok barang tersisa";
                    if($('#stok').val() <= 0){
                    confirm("Stok barang yang anda pilih kosong");
                    }
                    else if($('#stok').val() < 5){
                    alert([text , $('#stok').val()]);
                    }
        });
    });
    $('#addMore3').on('click', function() {
        $('.table3').show();
        var subtotal3 = parseInt($('#price3').val()) * $("#qty3").val();
        var starterkit_id = $("#starterkit_id").val();
        var qty3 = $("#qty3").val();
        var kategori = $("#kategori3").val();
        var question_name = $("#starterkit_id option:selected").text();
        var source = $("#document-template3").html();
        var template = Handlebars.compile(source);
        var data = {
            starterkit_id: starterkit_id,
            question_name: question_name,
            qty3: qty3,
            kategori: kategori,
            subtotal3: subtotal3,
        }

        var html = template(data);
        $("#addRow3").append(html)
    });
    $(document).on('click', '.removeaddmore3', function(event) {
        $(this).closest('.delete_add_more_item3').remove();
    });
</script>
@endpush
