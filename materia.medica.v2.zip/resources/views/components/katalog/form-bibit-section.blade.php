<div class="blog-section section">
    <div class="container">
        <!-- Feature Post Row Start -->
        <div class="row d-flex d-flex justify-content-center">
            <div class="col-lg-8 col-12 mb-50">
                <!-- Post Block Wrapper Start -->
                <div class="post-block-wrapper">
                    <!-- Post Block Head Start -->
                    @if ($message = Session::get('error'))
                        <div class="alert alert-danger alert-block">
                            <button type="button" class="close" data-dismiss="alert">×</button>
                            <strong>{{ $message }}</strong>
                        </div>
                    @endif
                    <div class="head d-flex justify-content-center">
                        <!-- Title -->
                        <h3 class="title">Bibit Tanaman Obat</h3>
                    </div><!-- Post Block Head End -->
                    <!-- Post Block Body Start -->
                    {!! Form::open(['route' => 'herbalmart.store','method'=>'post']) !!}
                        <div class="body">
                            <table class="table">
                                <tr>
                                    <div class="row ">
                                        <div class="container">
                                            <div class="row">
                                                <div class="col-sm-12">
                                                    <input type="hidden" class="form-control-input" value="{{ Request::segment(3) }}" name="url">
                                                    <input type="hidden" class="form-control-input" value="{{ auth()->user()->id }}" name="user_id">
                                                    <label for="">Pilih Bibit Tanaman Obat</label></input>
                                                </div>

                                                <div class="col-7">
                                                    <select class="form-control select-barang" id="produk_id">
                                                        <option value="">-- Pilih Barang --</option>
                                                        @foreach($produk as $key => $value)
                                                            <option value="{{$value->id}}">{{$value->nama}} - Rp.@php echo number_format($value['price'],0,',','.') @endphp</option>
                                                        @endforeach
                                                    </select>
                                                </div>
                                                <input type="hidden" id="price" value="_price">
                                                <input type="hidden" id="stok" value="_stok">
                                                <div style="width:50px">
                                                    <input placeholder=".." type="number" min="1" class="form-control" id="qty" value="1">
                                                </div>
                                                <div class="form-group col-1">
                                                    <button class="btn btn-success btn-sm" id="addMore" type="button">
                                                        <i class="fa fa-plus"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </tr>
                            </table>
                            <table >
                                <div class="row addRow" id="addRow" width=30%>

                                </div>
                            </table>
                            <hr>
                            <div class="col-sm-3">
                                <div>
                                    <button class="btn btn-info">Checkout</button>
                                </div>
                            </div>
                        </div><!-- Post Block Body End -->
                    {!! Form::close() !!}
                </div><!-- Post Block Wrapper End -->
            </div>
        </div><!-- Feature Post Row End -->
    </div>
</div>
@push('styles')
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css" rel="stylesheet" />
@endpush

@push('scripts')
         <!-- dynamic handlers -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/handlebars.js/4.4.2/handlebars.min.js"></script>

<script id="document-template" type="text/x-handlebars-template">
        <div class="delete_add_more_item container" id="delete_add_more_item">
            <div class="row" style="margin-bottom:10px">
                <div class="col-6">
                    <input type="text" value="@{{ question_name }}" class="form-control" readonly>
                    <input type="hidden" name="produk_id[]" value="@{{ produk_id }}" class="form-control" readonly>
                </div>
                <div style="width:50px">
                    <input type="text" name="qty[]" value="@{{ qty }}" class="form-control" readonly>
                </div>
                <div class="col-2">
                    <input type="text" name="subtotal[]" value="@{{ subtotal }}" class="form-control" readonly>
                </div>
                <div class="col-1" >
                    <button class="btn btn-danger btn-sm removeaddmore" type="button">
                        <i class="fa fa-minus"></i>
                    </button>
                </div>
            </div>
        </div>
 </script>

 <script type="text/javascript">
        $('#tag_list').select2({
            placeholder: "Choose tags...",
            minimumInputLength: 2,
            ajax: {
                url: '/tags/find',
                dataType: 'json',
                data: function (params) {
                    return {
                        q: $.trim(params.term)
                    };
                },
                processResults: function (data) {
                    return {
                        results: data
                    };
                },
                cache: true
            }
        });

    $(".select-barang").on("change", function(e) {
        var id = $(this).val();
        $.get("/produk/search/"+id, function(data, status){
            $('#price').val(data[0]['price']);
            $('#stok').val(data[0]['stok']);
            var text = "Stok barang tersisa";
                    if($('#stok').val() <= 0){
                    confirm("Stok barang yang anda pilih kosong");
                    }
                    else if($('#stok').val() < 10){
                    alert([text , $('#stok').val()]);
                    }
        });
    });
    $('#addMore').on('click', function() {
        var subtotals = parseInt($('#price').val()) * $("#qty").val();
        $('.table').show();

        var produk_id = $("#produk_id").val();
        var qty = $("#qty").val();
        var question_name = $("#produk_id option:selected").text();
        var source = $("#document-template").html();
        var template = Handlebars.compile(source);

        var data = {
            produk_id: produk_id,
            question_name: question_name,
            qty: qty,
            subtotal: subtotals,
        }
        var html = template(data);
        $("#addRow").append(html)
    });
    $(document).on('click', '.removeaddmore', function(event) {
        $(this).closest('.delete_add_more_item').remove();
    });
</script>
 @endpush
