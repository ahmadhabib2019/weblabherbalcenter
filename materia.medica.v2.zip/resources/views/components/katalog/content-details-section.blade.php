<div class="col-lg-5 col-12 mb-50">
    <div style="margin-top: 10px; padding: 10px 0px 10px 0px;">
        <h3 style="color:#17A2B8">{{ $produks->kategori->name }}</h3>
        <span style="font-weight: bold"></span>
    </div>
    <div class="post-block-wrapper">                        
        <div class="body">
            <div class="row">
                @if($images->count() > 1)
                    @foreach ($images as $item)
                        <div class="post sports-post post-separator-border col-sm-5">
                            <div class="post-wrap">
                                <a class="thumbnail image" data-toggle="lightbox" data-gallery="gallery" href="{{ $item->src }}">
                                    <img class="img-thumbnail" src="{{ $item->src }}"
                                        alt="{{ $produks->name }}">
                                </a>
                            </div>
                        </div>
                    @endforeach
                @else
                    @foreach ($images as $item)
                        <div class="post sports-post post-separator-border" style="padding: 10px 40px 5px 50px;">
                            <div class="post-wrap ">
                                <a class="thumbnail image" data-toggle="lightbox" data-gallery="gallery" href="{{ $item->src }}">
                                    <img class="img-thumbnail" style="width:400px" src="{{ $item->src }}"
                                        alt="{{ $produks->name }}">
                                </a>
                            </div>
                        </div>
                    @endforeach
                @endif
            </div>
        </div>
    </div>
</div>
<div class="col-lg-7 col-12 mb-50">
    <div class="row">

        <!-- Single Sidebar -->
        <div class="single-sidebar col-lg-12 col-md-6 col-12">

            <!-- Sidebar Block Wrapper -->
            <div class="sidebar-block-wrapper">

                <!-- Sidebar Block Head Start -->
                <div class="head feature-head">

                    <!-- Title -->
                    <h3 class="title">{{ $produks->nama }}</h3>

                </div><!-- Sidebar Block Head End -->

                <!-- Sidebar Block Body Start -->
                <div class="body row">
                    @if($produks->kategori_id < 3)

                        <div class="col-md-5" ><b> <a style="font-size:14px">Nama </a> </b></div>
                        <div class="col-md-0" style="padding:0px 0px 0px 0px" ><b> <a style="font-size:14px">:</a> </b></div>
                        <div class="col-md-5" >{{ $produks->nama}}</div>

                        <div class="col-md-5" ><b> <a style="font-size:14px">Berat Bersih</a> </b></div>
                        <div class="col-md-0" style="padding:0px 0px 0px 0px" ><b> <a style="font-size:14px">:</a> </b></div>
                        <div class="col-md-5" >{{ $produks->produkDetails[0]->berat}}</div>

                        <div class="col-md-5" ><b> <a style="font-size:14px">Nama Latin Tanaman</a> </b></div>
                        <div class="col-md-0" style="padding:0px 0px 0px 0px" ><b> <a style="font-size:14px">:</a> </b></div>
                        <div class="col-md-5" >{!! $produks->produkDetails[0]->nama_latin !!}</div>

                        <div class="col-md-5" ><b>  </b></div>
                        
                        <div class="col-md-12" >
                                <b> <a >Nama Daerah</a> : </b>
                        </div>
                        <div class="col-md-12" >{!! $produks->produkDetails[0]->nama_daerah !!}</div>

                        <div class="col-md-5" ><b> <a style="font-size:14px">Bagian tanaman yang digunakan </a> </b></div>
                        <div class="col-md-0" style="padding:0px 0px 0px 0px" ><b> <a style="font-size:14px">:</a> </b></div>
                        <div class="col-md-5" >{{ $produks->produkDetails[0]->bagian_tanaman}}</div>

                        <div class="col-md-12" >
                            <b> <a >Organoleptis</a> : </b>
                        </div>
                        <div class="col-md-12" >{!! $produks->produkDetails[0]->organoleptis !!}</div>
                        <div class="col-md-12" ><br></div>

                        <div class="col-sm-3" ><b>Quantity : </b><a style="font-family:Times New Roman">{{ $produks->stok}}</a> </div>
                        <div class="col-sm-9" ><b>Harga : </b><a style="font-family:Times New Roman">Rp. @php echo number_format($produks->price,0,',','.') @endphp</a></div>
                        <div class="col-md-12" >
                            <hr></hr>
                            <b> <a style="font-size:18px;color:#17A2B8">Keunggulan Produk</a> </b>
                        </div>
                        <div class="col-md-12" >{!! $produks->produkDetails[0]->keunggulan !!}</div>
                        <div class="col-md-12" ><br></div>
                        <div class="col-md-12" >
                            <b> <a style="font-size:18px;color:#17A2B8">Manfaat</a> </b>
                        </div>
                        <div class="col-md-12" >{!! $produks->produkDetails[0]->manfaat !!}</div>
                        <div class="col-md-12" ><br></div>
                        <div class="col-md-12" >
                            <b> <a style="font-size:18px;color:#17A2B8">Cara Penggunaan</a> </b>
                        </div>
                        <div class="col-md-12" >{!! $produks->produkDetails[0]->cara_penggunaan !!}</div>
                        <div class="col-md-5" >
                                <hr></hr>
                            <a href="{{ route('herbalmart.form',Request::segment(1)) }}" class="btn btn-outline-info btn-block btn-sm" type="button">Pesan</a>
                        </div>
                        
                    @elseif($produks->kategori_id == 3)
                        <div class="col-md-5" ><b> <a style="font-size:14px">Nama</a> </b></div>
                        <div class="col-md-0" style="padding:0px 0px 0px 0px" ><b> <a style="font-size:14px">:</a> </b></div>
                        <div class="col-md-5" >{{ $produks->nama}}</div>

                        <div class="col-md-5" ><b> <a style="font-size:14px">Isi Dalam Paket</a> </b></div>
                        <div class="col-md-0" style="padding:0px 0px 0px 0px" ><b> <a style="font-size:14px">:</a> </b></div>
                        <div class="col-md-5" >{!! $produks->produkDetails[0]->isipaket!!}</div>
                        <hr>
                        
                        <div class="col-sm-3" ><b>Quantity : </b><a style="font-family:Times New Roman">{{ $produks->stok ?? 0}}</a> </div>
                        <div class="col-sm-3" ><b>Harga : </b><a style="font-family:Times New Roman">Rp. @php echo number_format($produks->price,0,',','.') @endphp</a></div>
                        <div class="col-sm-3" ></div>
                        <br></br>
                        <div class="col-md-12" ><b> <a style="font-size:14px">Deskripsi</a> </b></div>
                        <div class="col-md-12" >{!! $produks->produkDetails[0]->deskripsipaket !!}</div>
                        <br></br>

                        <div class="col-md-5" >
                            <a href="{{ route('herbalmart.form',Request::segment(1)) }}" class="btn btn-outline-info btn-block btn-sm" type="button">Pesan</a>
                        </div>
                        
                        <div class="col-md-12" >
                        <hr>
                            <b> <a style="font-size:18px;color:#17A2B8">Keunggulan Produk</a> </b>
                        </div>
                        <div class="col-md-12" >{!! $produks->produkDetails[0]->keunggulan !!}</div>

                    @elseif($produks->kategori_id == 4)
                        <div class="col-md-5" ><b> <a style="font-size:14px">Nama </a> </b></div>
                        <div class="col-md-0" style="padding:0px 0px 0px 0px" ><b> <a style="font-size:14px">:</a> </b></div>
                        <div class="col-md-5" >{{ $produks->nama}}</div>

                        <div class="col-md-5" ><b> <a style="font-size:14px">Nama Latin Tanaman</a> </b></div>
                        <div class="col-md-0" style="padding:0px 0px 0px 0px" ><b> <a style="font-size:14px">:</a> </b></div>
                        <div class="col-md-5" >{!! $produks->produkDetails[0]->nama_latin !!}</div>

                        <div class="col-md-5" ><b> <a style="font-size:14px">Famili</a> </b></div>
                        <div class="col-md-0" style="padding:0px 0px 0px 0px" ><b> <a style="font-size:14px">:</a> </b></div>
                        <div class="col-md-5" >{!! $produks->produkDetails[0]->famili !!}</div>
                        
                        <div class="col-sm-12"><br></div>
                        <div class="col-sm-3" ><b>Quantity : </b><a style="font-family:Times New Roman">{{ $produks->stok}}</a> </div>
                        <div class="col-sm-9" ><b>Harga : </b><a style="font-family:Times New Roman">Rp. @php echo number_format($produks->price,0,',','.') @endphp</a></div>
                        <div class="col-sm-12"><br></div>
                        <div class="col-md-12" >
                                <b> <a >Nama Daerah</a> : </b>
                        </div>
                        <div class="col-md-12" >{!! $produks->produkDetails[0]->nama_daerah !!}</div>

                        <div class="col-md-12" >
                            <b> <a>Morfologi</a> : </b>
                        </div>
                        <div class="col-md-12" >{!! $produks->produkDetails[0]->morfologi !!}</div>
                        <div class="col-md-12" ><br></div>
                        <div class="col-md-12" >
                            <b> <a style="font-size:18px;color:#17A2B8">Kandungan Kimia</a> </b>
                        </div>
                        <div class="col-md-12" >{!! $produks->produkDetails[0]->kandungan !!}</div>
                        <div class="col-md-12" >
                            <b> <a style="font-size:18px;color:#17A2B8">Manfaat</a> </b>
                        </div>
                        <div class="col-md-12" >{!! $produks->produkDetails[0]->manfaat !!}</div>
                        <div class="col-md-5" >
                                <hr></hr>
                            <a href="{{ route('herbalmart.form',Request::segment(1)) }}" class="btn btn-outline-info btn-block btn-sm" type="button">Pesan</a>
                        </div>

                    @endif
                </div><!-- Sidebar Block Body End -->
                <div class="mobile-menu-wrap d-none">
                    <nav>
                        tes
                    </nav>
                </div>
            </div>

        </div>

    </div>
</div><!-- Sidebar End -->
@push('styles')
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ekko-lightbox/5.3.0/ekko-lightbox.css" integrity="sha512-Velp0ebMKjcd9RiCoaHhLXkR1sFoCCWXNp6w4zj1hfMifYB5441C+sKeBl/T/Ka6NjBiRfBBQRaQq65ekYz3UQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
@endpush

@push('scripts')
    <script src="https://cdnjs.cloudflare.com/ajax/libs/ekko-lightbox/5.3.0/ekko-lightbox.min.js" integrity="sha512-Y2IiVZeaBwXG1wSV7f13plqlmFOx8MdjuHyYFVoYzhyRr3nH/NMDjTBSswijzADdNzMyWNetbLMfOpIPl6Cv9g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <script>
        $(document).on("click", '[data-toggle="lightbox"]', function(event) {
            event.preventDefault();
            $(this).ekkoLightbox();
        });
    </script>
@endpush
