<div class="blog-section section">
    <div class="container">
        
        <!-- Feature Post Row Start -->
        <div class="row">
            
            <x-katalog.content-section :produk='$produk'/>
        </div><!-- Feature Post Row End -->
        
    </div>
</div>