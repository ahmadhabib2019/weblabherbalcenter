<div class="blog-section section">
    <div class="container">
        
        <!-- Feature Post Row Start -->
        <div class="row">

            <x-katalog.content-details-section :produks='$produks' :images="$images"/>
            
        </div><!-- Feature Post Row End -->
        
    </div>
</div>