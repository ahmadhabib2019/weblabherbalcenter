<!-- Menu Section Start -->
<div class="menu-section section bg-dark">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="menu-section-wrap">
                    <div class="main-menu float-left d-none d-md-block">
                        <nav>
                            <ul class="btn-group">
                                @foreach ($menu as $item)
                                    @if ($item->parent == 0)
                                        <li class="dropdown @if ($loop->first) active @endif @if (count($item->child($item->id)) > 0) has-dropdown @endif">
                                            @if($item->title == "PPID")
                                                <a href="https://ppid.materiamedicabatu.jatimprov.go.id">{{ $item->title }}</a>
                                            @else
                                                <a href="{{ route($item->url, $item->param) }}">{{ $item->title }}</a>
                                            @endif
                                            @if (count($item->child($item->id)) > 0)
                                                <!-- Submenu Start -->
                                                <ul class="sub-menu ">
                                                    @foreach ($item->child($item->id) as $child)
                                                        <li style="margin-bottom:"
                                                            class="{{ count($child->child($child->id)) > 0 ? 'dropdown-submenu' : '' }}">
                                                            <a href="{{ route($child->url, $child->param) }}">{{ $child->title }}
                                                                </i>
                                                            </a>
                                                            @if (count($child->child($child->id)) > 0)
                                                                <ul class="dropdown-menu sub-menu">
                                                                    @foreach ($child->child($child->id) as $subchild)
                                                                        <li>
                                                                            <a class="subchild" href="{{ route($subchild->url, $subchild->param) }}">{{ $subchild->title }}</a>
                                                                        </li>
                                                                    @endforeach
                                                                </ul>
                                                            @endif
                                                        </li>

                                                    @endforeach
                                                </ul><!-- Submenu End -->
                                            @endif
                                        </li>
                                    @endif
                                @endforeach
                            </ul>
                        </nav>
                    </div>

                    <div class="mobile-logo d-none d-block d-md-none"><a href="index.html">
                            <img src="{{ asset('frontend/img/logo-white.png') }}" alt="Logo"></a>
                    </div>

                    <div class="header-search float-right">
                        <button class="header-search-toggle"><i class="fa fa-search"></i></button>
                        <div class="header-search-form">
                            <form action="{{ route('frontend.search') }}" method="GET">
                                <input type="text" name="param" placeholder="Search Here">
                            </form>
                        </div>

                    </div>

                    <div class="mobile-menu-wrap d-none">
                        <nav>
                            <ul>
                                @foreach ($menu as $item)
                                    @if ($item->parent == 0)
                                        <li class="dropdown @if ($loop->first) active @endif @if (count($item->child($item->id)) > 0) has-dropdown @endif">
                                            @if($item->title == "PPID")
                                                <a href="https://ppid.materiamedicabatu.jatimprov.go.id">{{ $item->title }}</a>
                                            @else
                                                <a href="{{ route($item->url, $item->param) }}">{{ $item->title }}</a>
                                            @endif

                                            @if (count($item->child($item->id)) > 0)
                                                <!-- Submenu Start -->
                                                <ul class="dropdown-menu sub-menu">
                                                    @foreach ($item->child($item->id) as $child)
                                                        <li class="{{ count($child->child($child->id)) > 0 ? 'dropdown-submenu' : '' }}">
                                                            <a href="{{ route($child->url, $child->param) }}">{{ $child->title }}
                                                                </i>
                                                            </a>
                                                            @if (count($child->child($child->id)) > 0)
                                                                <ul class="dropdown-menu sub-menu">
                                                                    @foreach ($child->child($child->id) as $subchild)
                                                                        <li>
                                                                            <a class="subchild" href="{{ route($subchild->url, $subchild->param) }}">{{ $subchild->title }}</a>
                                                                        </li>
                                                                    @endforeach
                                                                </ul>
                                                            @endif
                                                        </li>

                                                    @endforeach
                                                </ul><!-- Submenu End -->
                                            @endif
                                        </li>
                                    @endif
                                @endforeach
                            </ul>
                        </nav>
                    </div>

                    <div class="mobile-menu"></div>

                </div>
            </div>
        </div>
    </div>
</div>
@push('scripts')
    <script>
        $(".btn-group, .dropdown").hover(
            function() {
                $('>.dropdown-menu', this).stop(true, true).fadeIn("fast");
                $(this).addClass('open');
            },
            function() {
                $('>.dropdown-menu', this).stop(true, true).fadeOut("fast");
                $(this).removeClass('open');
            });
    </script>
@endpush

@push('styles')
    <style>
        .dropdown-submenu {
            position: relative;
        }

        .dropdown-submenu>a:after {
            font-family: FontAwesome;
            content: "\f105";
            float: right;
        }

        .dropdown-submenu>.dropdown-menu {
            top: 0;
            left: 100%;
            margin-top: 0px;
            margin-left: 0px;
            font-size: 100%;
        }

        .dropdown-submenu:hover>.dropdown-menu {
            display: block;
        }

        .subchild{
            color: #6C757D !important;
        }
       .subchild:hover{
            color:#00C8FA !important;
        }
    </style>
@endpush
