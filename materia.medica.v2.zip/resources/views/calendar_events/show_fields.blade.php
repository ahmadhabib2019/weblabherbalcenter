<!-- Title Field -->
<div class="col-sm-12">
    {!! Form::label('title', 'Kegiatan:') !!}
    <p>{{ $calendarEvent->title }}</p>
</div>

<div class="col-sm-12">
    {!! Form::label('location', 'Lokasi') !!}
    <p>{{ $calendarEvent->location }}</p>
</div>
<div class="col-sm-12">
    {!! Form::label('location', 'Jumpah Peserta : ') !!}
    <a>{{ $calendarEvent->peserta }}</a>
</div>

<!-- Fullday Field -->
<div class="col-sm-12">
    {!! Form::label('fullday', 'Fullday:') !!}
    @if($calendarEvent->fullday == 1)
    <a>True</a>
    @else
    <a>False</a>
    @endif
</div>

<!-- Start Field -->
<div class="col-sm-3">
    {!! Form::label('start', 'Start:') !!}
    <a>{{ $calendarEvent->start }}</a>
</div>

<!-- Finish Field -->
<div class="col-sm-3">
    {!! Form::label('finish', 'Finish:') !!}
    <a>{{ $calendarEvent->finish }}</a>
</div>

<!-- Stringeventid Field -->

