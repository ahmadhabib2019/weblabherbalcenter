<!-- Title Field -->
<div class="form-group col-sm-10">
    {!! Form::label('title', 'Title:') !!}
    {!! Form::text('title', null, ['class' => 'form-control','maxlength' => 191,'maxlength' => 191]) !!}
</div>

<!-- Fullday Field -->
<div class="form-group col-sm-2">
{!! Form::label('title', '.') !!}
    <div class="form-check">
        {!! Form::hidden('fullday', 0, ['class' => 'form-check-input']) !!}
        {!! Form::checkbox('fullday', '1', null, ['class' => 'form-check-input']) !!}
        {!! Form::label('fullday', 'Fullday', ['class' => 'form-check-label']) !!}
    </div>
</div>


<!-- Start Field -->
<div class="form-group col-sm-3">
    {!! Form::label('start', 'Start:') !!}
    {!! Form::text('start', null, ['class' => 'form-control','id'=>'start']) !!}
    <a>{{ old('start', isset($calendarEvent)?$calendarEvent->start : '') }}</a>
</div>

@push('page_scripts')
    <script type="text/javascript">
        $('#start').datetimepicker({
            format: 'YYYY-MM-DD',
            useCurrent: true,
            sideBySide: true,
             icons: {
                    next: 'fa fa-angle-right',
                    previous: 'fa fa-angle-left'
                },
        })
    </script>
@endpush

<!-- Finish Field -->
<div class="form-group col-sm-3">
    {!! Form::label('finish', 'Finish:') !!}
    {!! Form::text('finish', null, ['class' => 'form-control','id'=>'finish']) !!}
    <a>{{ old('finish', isset($calendarEvent)?$calendarEvent->finish : '') }}</a>

</div>

@push('page_scripts')
    <script type="text/javascript">
        $('#finish').datetimepicker({
            format: 'YYYY-MM-DD',
            useCurrent: true,
            sideBySide: true,
            icons: {
                    next: 'fa fa-angle-right',
                    previous: 'fa fa-angle-left'
                },
        })
    </script>
@endpush

<!-- Stringeventid Field -->
<div class="form-group col-sm-12">
    {!! Form::label('location', 'Deskripsi:') !!}
    {!! Form::textarea('location', null, ['class'=>'form-control','id'=>'location']) !!}
</div>
<div class="form-group col-sm-3">
    {!! Form::label('peserta', 'Jumlah Peserta:') !!}
    {!! Form::number('peserta', null, ['class'=>'form-control']) !!}
</div>