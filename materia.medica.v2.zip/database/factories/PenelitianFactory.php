<?php

namespace Database\Factories;

use App\Models\Penelitian;
use Illuminate\Database\Eloquent\Factories\Factory;

class PenelitianFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Penelitian::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'title' => $this->faker->word,
        'description' => $this->faker->text,
        'publication_link' => $this->faker->word,
        'file' => $this->faker->word,
        'download' => $this->faker->word,
        'created_at' => $this->faker->date('Y-m-d H:i:s'),
        'updated_at' => $this->faker->date('Y-m-d H:i:s')
        ];
    }
}
