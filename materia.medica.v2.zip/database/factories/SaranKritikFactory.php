<?php

namespace Database\Factories;

use App\Models\SaranKritik;
use Illuminate\Database\Eloquent\Factories\Factory;

class SaranKritikFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = SaranKritik::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'user_id' => $this->faker->randomDigitNotNull,
        'saran' => $this->faker->word,
        'response_saran' => $this->faker->word,
        'kritik' => $this->faker->word,
        'response_kritik' => $this->faker->word,
        'created_at' => $this->faker->date('Y-m-d H:i:s'),
        'updated_at' => $this->faker->date('Y-m-d H:i:s')
        ];
    }
}
