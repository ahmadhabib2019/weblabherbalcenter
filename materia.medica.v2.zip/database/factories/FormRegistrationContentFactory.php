<?php

namespace Database\Factories;

use App\Models\FormRegistrationContent;
use Illuminate\Database\Eloquent\Factories\Factory;

class FormRegistrationContentFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = FormRegistrationContent::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'form_registration_id' => $this->faker->randomDigitNotNull,
        'question_id' => $this->faker->randomDigitNotNull,
        'created_at' => $this->faker->date('Y-m-d H:i:s'),
        'updated_at' => $this->faker->date('Y-m-d H:i:s')
        ];
    }
}
