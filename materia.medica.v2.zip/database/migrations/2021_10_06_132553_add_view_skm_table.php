<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class AddViewSkmTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        DB::statement(
            "CREATE VIEW viewskm AS
            SELECT 
                (avg(q1))*0.071 as s1, (avg(q2))*0.071 as s2, (avg(q3))*0.071 as s3,
                (avg(q4))*0.071 as s4, (avg(q5))*0.071 as s5, (avg(q6))*0.071 as s6,
                (avg(q7))*0.071 as s7, (avg(q8))*0.071 as s8, (avg(q9))*0.071 as s9,
                (avg(q10))*0.071 as s10, (avg(q11))*0.071 as s11, (avg(q12))*0.071 as qs2,
                (avg(q13))*0.071 as s13, (avg(q14))*0.071 as s14, service_id, services.title AS nama, CAST(skms.created_at AS DATE) AS tgl,
                
                ((avg(q1))*0.071)+ ((avg(q2))*0.071)+ ((avg(q3))*0.071)+
                ((avg(q4))*0.071)+ ((avg(q5))*0.071)+ ((avg(q6))*0.071)+
                ((avg(q7))*0.071)+ ((avg(q8))*0.071)+ ((avg(q9))*0.071)+
                ((avg(q10))*0.071)+ ((avg(q11))*0.071)+ ((avg(q12))*0.071)+
                ((avg(q13))*0.071)+ ((avg(q14))*0.071) as total, 
            
                (((avg(q1))*0.071)+ ((avg(q2))*0.071)+ ((avg(q3))*0.071)+
                ((avg(q4))*0.071)+ ((avg(q5))*0.071)+ ((avg(q6))*0.071)+
                ((avg(q7))*0.071)+ ((avg(q8))*0.071)+ ((avg(q9))*0.071)+
                ((avg(q10))*0.071)+ ((avg(q11))*0.071)+ ((avg(q12))*0.071)+
                ((avg(q13))*0.071)+ ((avg(q14))*0.071))*25 as totalakhir
                
            FROM `skms`
            INNER JOIN services ON services.id = skms.service_id
            group by service_id, services.title, CAST(skms.created_at AS DATE)"
        );
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        \Illuminate\Support\Facades\DB::unprepared('DROP VIEW viewskm');

    }
}
