<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateProdukDetailsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('produk_details', function (Blueprint $table) {
            $table->id();
            $table->foreignId('produk_id')->references('id')->on('produks');
            $table->string('nama_latin')->nullable();
            $table->string('berat')->nullable();
            $table->string('pemerian')->nullable();
            $table->longText('keunggulan')->nullable();
            $table->longText('isipaket')->nullable();
            $table->longText('deskripsipaket')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('produk_details');
    }
}
