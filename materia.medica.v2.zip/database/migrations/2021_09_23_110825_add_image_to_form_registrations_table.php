<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddImageToFormRegistrationsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('form_registrations', function (Blueprint $table) {
            $table->longText('description')->nullable();
            $table->date('date')->nullable();
            $table->time('jam',0)->nullable();
            $table->string('image')->nullable();
            $table->string('price')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('form_registrations', function (Blueprint $table) {
            $table->dropColumn('description');
            $table->dropColumn('date');
            $table->dropColumn('jam');
            $table->dropColumn('image');
            $table->dropColumn('price');
        });
    }
}
