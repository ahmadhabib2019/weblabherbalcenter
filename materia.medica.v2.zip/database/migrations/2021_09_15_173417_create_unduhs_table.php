<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUnduhsTable extends Migration
{

    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('unduhs', function (Blueprint $table) {
            $table->id('id');
            $table->string('title');
            $table->longText('description');
            $table->string('url');
            $table->string('file');
            $table->string('image');
            $table->smallinteger('year');
            $table->string('category');
            $table->integer('download')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('unduhs');
    }
}
