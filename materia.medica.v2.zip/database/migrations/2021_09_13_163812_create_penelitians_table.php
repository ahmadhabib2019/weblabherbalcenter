<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePenelitiansTable extends Migration
{

    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('penelitians', function (Blueprint $table) {
            $table->id('id');
            $table->string('title');
            $table->string('category');
            $table->longText('description');
            $table->longText('publication_link');
            $table->string('file')->nullable();
            $table->string('images')->nullable();
            $table->integer('download')->nullable();
            $table->smallInteger('year');
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('penelitians');
    }
}
