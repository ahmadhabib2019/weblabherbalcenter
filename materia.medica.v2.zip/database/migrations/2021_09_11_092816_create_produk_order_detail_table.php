<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateProdukOrderDetailTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('produk_order_detail', function (Blueprint $table) {
            $table->id();
            $table->foreignId('order_id')->constrained('produk_orders');
            $table->foreignId('produk_id')->constrained('produks');
            $table->foreignId('kategori_id')->constrained('produk_kategoris');
            $table->string('qty');
            $table->string('total');

            $table->timestamps();
            $table->softDeletes();

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('produk_order_detail');
    }
}
