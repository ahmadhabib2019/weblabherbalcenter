<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddAnyColumnProduk extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('produk_details', function (Blueprint $table) {
            $table->longText('nama_daerah')->nullable();
            $table->longText('bagian_tanaman')->nullable();
            $table->longText('organoleptis')->nullable();
            $table->longText('manfaat')->nullable();
            $table->longText('cara_penggunaan')->nullable();
            $table->longText('famili')->nullable();
            $table->longText('kandungan')->nullable();
            $table->longText('morfologi')->nullable();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('produk_details', function (Blueprint $table) {
            $table->dropClolumn('nama_daerah');
            $table->dropClolumn('bagian_tanaman');
            $table->dropClolumn('organoleptis');
            $table->dropClolumn('manfaat');
            $table->dropClolumn('cara_penggunaan');
            $table->dropClolumn('famili');
            $table->dropClolumn('kandungan');
            $table->dropClolumn('morfologi');
        });
    }
}
