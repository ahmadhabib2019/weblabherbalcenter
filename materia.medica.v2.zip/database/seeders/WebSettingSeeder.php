<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\WebSetting;

class WebSettingSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        WebSetting::truncate();
        $webSet [] = ['name'=>'alamat_1','value'=>'Jalan Lahor No 87 Kota Batu','url'=>'https://goo.gl/maps/DLB8WM9MsYwbRNcw9'];
        $webSet [] = ['name'=>'alamat_2','value'=>'Jalan Kolonel Sugiono No 457 – 459 Gadang, Kota Malang','url'=>'https://goo.gl/maps/njoXBNvc62nFLF9'];
        $webSet [] = ['name'=>'alamat_3','value'=>'Jalan Raya No 228 Kejayan, Kabupaten Pasuruan','url'=>'https://goo.gl/maps/M6YvfkzwoKpgUqxN7'];
        $webSet [] = ['name'=>'jadwal_1','value'=>'07.00 – 15.30','url'=>''];
        $webSet [] = ['name'=>'jadwal_2','value'=>'07.00 – 14.30 ','url'=>''];
        $webSet [] = ['name'=>'phone','value'=>'(0341) 593396','url'=>''];
        $webSet [] = ['name'=>'email','value'=>'materiamedicabatu@jatimprov.go.id','url'=>''];
        $webSet [] = ['name'=>'facebook','value'=>'UPT Laboratorium Herbal Materia Medica Batu','url'=>'https://www.facebook.com/UPT-Laboratorium-Herbal-Materia-Medica-Batu-108986600926639'];
        $webSet [] = ['name'=>'instagram','value'=>'@materiamedicabatu','url'=>'https://www.instagram.com/materiamedicabatu'];
        $webSet [] = ['name'=>'youtube','value'=>'Materia Medica Batu','url'=>'https://www.youtube.com/channel/UCUKR3QYZBnwC1chad_c8i-g'];
        WebSetting::insert($webSet);
    }
}
