<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Service;
use Illuminate\Support\Facades\Schema;
class ServicesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Schema::disableForeignKeyConstraints();
        Service::truncate();
        $service[]=['title'=>'Wisata Edukasi Toga','slug'=>'wisata-edukasi-toga','description'=>'tes','facilities'=>'tes','requirements'=>'tes','time_period'=>'tes','price'=>'tes','guarantee'=>'tes','contact_person_id'=>1,'category'=>null];
        $service[]=['title'=>'Workshop Pengolahan Tanaman Obat','slug'=>'workshop-pengolahan-tanaman-obat','description'=>'tes','facilities'=>'tes','requirements'=>'tes','time_period'=>'tes','price'=>'tes','guarantee'=>'tes','contact_person_id'=>1,'category'=>'open'];
        $service[]=['title'=>'Workshop Pengolahan Tanaman Obat','slug'=>'workshop-pengolahan-tanaman-obat','description'=>'tes','facilities'=>'tes','requirements'=>'tes','time_period'=>'tes','price'=>'tes','guarantee'=>'tes','contact_person_id'=>1,'category'=>'offline'];
        $service[]=['title'=>'Workshop Pengolahan Tanaman Obat','slug'=>'workshop-pengolahan-tanaman-obat','description'=>'tes','facilities'=>'tes','requirements'=>'tes','time_period'=>'tes','price'=>'tes','guarantee'=>'tes','contact_person_id'=>1,'category'=>'online'];
        $service[]=['title'=>'Narasumber','slug'=>'narasumber','description'=>'tes','facilities'=>'tes','requirements'=>'tes','time_period'=>'tes','price'=>'tes','guarantee'=>'tes','contact_person_id'=>1,'category'=>null];
        $service[]=['title'=>'PKL Dan Magang','slug'=>'pkl-dan-magang','description'=>'tes','facilities'=>'tes','requirements'=>'tes','time_period'=>'tes','price'=>'tes','guarantee'=>'tes','contact_person_id'=>1,'category'=>null];
        $service[]=['title'=>'Identifikasi Tanaman Obat (Determinasi)','slug'=>'identifikasi-tanaman-obat-determinasi','description'=>'tes','facilities'=>'tes','requirements'=>'tes','time_period'=>'tes','price'=>'tes','guarantee'=>'tes','contact_person_id'=>1,'category'=>null];
        $service[]=['title'=>'Pengolahan Pasca Panen Tanaman Obat','slug'=>'pengolahan-pasca-panen-tanaman-obat','description'=>'tes','facilities'=>'tes','requirements'=>'tes','time_period'=>'tes','price'=>'tes','guarantee'=>'tes','contact_person_id'=>1,'category'=>null];
        $service[]=['title'=>'Ekstraksi Tanaman Obat','slug'=>'ekstraksi-tanaman-obat','description'=>'tes','facilities'=>'tes','requirements'=>'tes','time_period'=>'tes','price'=>'tes','guarantee'=>'tes','contact_person_id'=>1,'category'=>null];
        $service[]=['title'=>'Pengujian Kandungan Tanaman Obat','slug'=>'pengujian-kandungan-tanaman-obat','description'=>'tes','facilities'=>'tes','requirements'=>'tes','time_period'=>'tes','price'=>'tes','guarantee'=>'tes','contact_person_id'=>1,'category'=>null];
        $service[]=['title'=>'Pengujian Mikrobiologi','slug'=>'pengujian-mikrobiologi','description'=>'tes','facilities'=>'tes','requirements'=>'tes','time_period'=>'tes','price'=>'tes','guarantee'=>'tes','contact_person_id'=>1,'category'=>null];
        $service[]=['title'=>'Pelayanan Kesehatan Tradisional (Griya Sehat)','slug'=>'pelayanan-kesehatan-tradisional-griya-sehat','description'=>'tes','facilities'=>'tes','requirements'=>'tes','time_period'=>'tes','price'=>'tes','guarantee'=>'tes','contact_person_id'=>1,'category'=>null];
        $service[]=['title'=>'HerbalMart','slug'=>'herbalmart','description'=>'tes','facilities'=>'tes','requirements'=>'tes','time_period'=>'tes','price'=>'tes','guarantee'=>'tes','contact_person_id'=>1,'category'=>null];
        $service[]=['title'=>'Bibit Tanaman Obat','slug'=>'bibit-tanaman-obat','description'=>'tes','facilities'=>'tes','requirements'=>'tes','time_period'=>'tes','price'=>'tes','guarantee'=>'tes','contact_person_id'=>1,'category'=>null];
        $service[]=['title'=>'Sewa Fasilitas Gedung Dan Atau Alat','slug'=>'sewa-fasilitas-gedung-dan-atau-alat','description'=>'tes','facilities'=>'tes','requirements'=>'tes','time_period'=>'tes','price'=>'tes','guarantee'=>'tes','contact_person_id'=>1,'category'=>null];
        $service[]=['title'=>'Materia Medica Cafe (Cafe Jamu)','slug'=>'materia-medica-cafe-cafe-jamu','description'=>'tes','facilities'=>'tes','requirements'=>'tes','time_period'=>'tes','price'=>'tes','guarantee'=>'tes','contact_person_id'=>1,'category'=>null];
        $service[]=['title'=>'Homecare','slug'=>'homecare','description'=>'tes','facilities'=>'tes','requirements'=>'tes','time_period'=>'tes','price'=>'tes','guarantee'=>'tes','contact_person_id'=>1,'category'=>null];
        $service[]=['title'=>'Telemedisin Griya Sehat','slug'=>'telemedisin-griya-sehat','description'=>'tes','facilities'=>'tes','requirements'=>'tes','time_period'=>'tes','price'=>'tes','guarantee'=>'tes','contact_person_id'=>1,'category'=>null];
        $service[]=['title'=>'Repository Tanaman Obat','slug'=>'repository-tanaman-obat','description'=>'tes','facilities'=>'tes','requirements'=>'tes','time_period'=>'tes','price'=>'tes','guarantee'=>'tes','contact_person_id'=>1,'category'=>null];
        $service[]=['title'=>'Pemesanan Simplisia Tanaman Obat','slug'=>'pemesanan-simplisia-tanaman-obat','description'=>'tes','facilities'=>'tes','requirements'=>'tes','time_period'=>'tes','price'=>'tes','guarantee'=>'tes','contact_person_id'=>1,'category'=>null];
        $service[]=['title'=>'Uji Kandungan Antioksidan Tanaman Obat','slug'=>'uji-kandungan-antioksidan-tanaman-obat','description'=>'tes','facilities'=>'tes','requirements'=>'tes','time_period'=>'tes','price'=>'tes','guarantee'=>'tes','contact_person_id'=>1,'category'=>null];
        $service[]=['title'=>'Ekstraksi Tanaman Obat','slug'=>'ekstraksi-tanaman-obat-unggulan','description'=>'tes','facilities'=>'tes','requirements'=>'tes','time_period'=>'tes','price'=>'tes','guarantee'=>'tes','contact_person_id'=>1,'category'=>null];
        Service::insert($service);
        Schema::enableForeignKeyConstraints();

    }
}
