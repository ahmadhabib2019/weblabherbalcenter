<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Fasilitas;
use App\Models\FasilitasFile;
use Str;
use Illuminate\Support\Facades\Schema;

class KategoriFasilitasSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Schema::disableForeignKeyConstraints();
        FasilitasFile::truncate();
        Fasilitas::truncate();
        $fasilitas [] = ['title'=>'Gedung Kantor','description'=>'','slug'=>Str::slug('Gedung Kantor')];
        $fasilitas [] = ['title'=>'Perpustakaan','description'=>'','slug'=>Str::slug('Perpustakaan')];
        $fasilitas [] = ['title'=>'Aula','description'=>'','slug'=>Str::slug('Aula')];
        $fasilitas [] = ['title'=>'Mushola','description'=>'','slug'=>Str::slug('Mushola')];
        $fasilitas [] = ['title'=>'Kebun Tanaman Obat','description'=>'','slug'=>Str::slug('Kebun Tanaman Obat')];
        $fasilitas [] = ['title'=>'Green House','description'=>'','slug'=>Str::slug('Green House')];
        $fasilitas [] = ['title'=>'Unit Budidaya Tanaman Obat','description'=>'','slug'=>Str::slug('Unit Budidaya Tanaman Obat')];
        $fasilitas [] = ['title'=>'Laboratorium Kultur Jaringan','description'=>'','slug'=>Str::slug('Laboratorium Kultur Jaringan')];
        $fasilitas [] = ['title'=>'Unit Pengolahan Pasca Panen Tanaman Obat','description'=>'','slug'=>Str::slug('Unit Pengolahan Pasca Panen Tanaman Obat')];
        $fasilitas [] = ['title'=>'Laboratorium Diversifikasi Produk','description'=>'','slug'=>Str::slug('Laboratorium Diversifikasi Produk')];
        $fasilitas [] = ['title'=>'Laboratorium Fitokimia','description'=>'','slug'=>Str::slug('Laboratorium Fitokimia')];
        $fasilitas [] = ['title'=>'Laboratorium Instrumentasi','description'=>'','slug'=>Str::slug('Laboratorium Instrumentasi')];
        $fasilitas [] = ['title'=>'Laboratorium Mikrobiologi','description'=>'','slug'=>Str::slug('Laboratorium Mikrobiologi')];
        $fasilitas [] = ['title'=>'Griya Sehat','description'=>'','slug'=>Str::slug('Griya Sehat')];
        $fasilitas [] = ['title'=>'HerbalMart','description'=>'','slug'=>Str::slug('HerbalMart')];
        $fasilitas [] = ['title'=>'Materia Medica Cafe (Cafe Jamu)','description'=>'','slug'=>Str::slug('Materia Medica Cafe (Cafe Jamu)')];
        Fasilitas::insert($fasilitas);
        Schema::enableForeignKeyConstraints();
    }
}
