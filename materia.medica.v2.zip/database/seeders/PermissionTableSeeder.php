<?php
namespace Database\Seeders;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Spatie\Permission\Models\Permission;
class PermissionTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Schema::disableForeignKeyConstraints();
        Permission::truncate();
        $permissions = [
          'admin-list' ,
          'admin-create',
          'admin-edit',
          'admin-delete',
          'operator-list',
          'operator-create',
          'operator-edit',
          'operator-delete',
          'pengunjung',
        ];
     
        foreach ($permissions as $permission) {
             Permission::create(['name' => $permission]);
        }
        Schema::enableForeignKeyConstraints();

    }
}
