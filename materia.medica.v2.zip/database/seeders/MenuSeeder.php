<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Menu;
class MenuSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Menu::truncate();
        //parent menu
       $menu[] = ['title'=>'Beranda', 'url'=>'welcome','parent'=>0,'param'=>null];
       $menu[] = ['title'=>'Profile', 'url'=>'welcome','parent'=>0,'param'=>null];
       $menu[] = ['title'=>'Berita', 'url'=>'welcome','parent'=>0,'param'=>null];
       $menu[] = ['title'=>'Fasilitas', 'url'=>'welcome','parent'=>0,'param'=>null];
       $menu[] = ['title'=>'Layanan', 'url'=>'welcome','parent'=>0,'param'=>null];
       $menu[] = ['title'=>'Penelitian', 'url'=>'welcome','parent'=>0,'param'=>null];
       $menu[] = ['title'=>'Galeri', 'url'=>'welcome','parent'=>0,'param'=>null];
       $menu[] = ['title'=>'Unduh', 'url'=>'welcome','parent'=>0,'param'=>null];
       $menu[] = ['title'=>'PPID', 'url'=>'welcome','parent'=>0,'param'=>null];
       $menu[] = ['title'=>'Pengaduan', 'url'=>'frontend.pengaduan.index','parent'=>0,'param'=>null];
       $menu[] = ['title'=>'Survey Kepuasan Masyarakat', 'url'=>'welcome','parent'=>0,'param'=>null];
       //submenu profile
       $menu[] = ['title'=>'Sejarah', 'url'=>'frontend.blog','parent'=>2,'param'=>'sejarah'];
       $menu[] = ['title'=>'Milestone', 'url'=>'frontend.blog','parent'=>2,'param'=>'milestone'];
       $menu[] = ['title'=>'Struktur Organisasi', 'url'=>'frontend.blog','parent'=>2,'param'=>'struktur-organisasi'];
       $menu[] = ['title'=>'Tugas Dan Fungsi', 'url'=>'frontend.blog','parent'=>2,'param'=>'tugas-dan-fungsi'];
       $menu[] = ['title'=>'Sumber Daya Manusia', 'url'=>'frontend.blog','parent'=>2,'param'=>'sumber-daya-manusia'];
       $menu[] = ['title'=>'Master Plan', 'url'=>'frontend.blog','parent'=>2,'param'=>'master-plan'];

       //submenu berita
       $menu[] = ['title'=>'Berita Aktual', 'url'=>'frontend.post','parent'=>3,'param'=>'berita'];
       $menu[] = ['title'=>'Artikel Kesehatan', 'url'=>'frontend.post','parent'=>3,'param'=>'artikel'];
       $menu[] = ['title'=>'Kalender Kegiatan', 'url'=>'frontend.post','parent'=>3,'param'=>'kalender-kegiatan'];

       //submenu fasilitas
       $menu[] = ['title'=>'Gedung Kantor', 'url'=>'frontend.fasilitas','parent'=>4,'param'=>'gedung-kantor'];
       $menu[] = ['title'=>'Perpustakaan', 'url'=>'frontend.fasilitas','parent'=>4,'param'=>'perpustakaan'];
       $menu[] = ['title'=>'Aula', 'url'=>'frontend.fasilitas','parent'=>4,'param'=>'aula'];
       $menu[] = ['title'=>'Mushola', 'url'=>'frontend.fasilitas','parent'=>4,'param'=>'mushola'];
       $menu[] = ['title'=>'Kebun Tanaman Obat', 'url'=>'frontend.fasilitas','parent'=>4,'param'=>'kebun-tanaman-obat'];
       $menu[] = ['title'=>'Green House', 'url'=>'frontend.fasilitas','parent'=>4,'param'=>'green-house'];
       $menu[] = ['title'=>'Unit Budidaya Tanaman Obat', 'url'=>'frontend.fasilitas','parent'=>4,'param'=>'unit-budidaya-tanaman-obat'];
       $menu[] = ['title'=>'Laboratorium Kultur Jaringan', 'url'=>'frontend.fasilitas','parent'=>4,'param'=>'laboratorium-kultur-jaringan'];
       $menu[] = ['title'=>'Unit Pengolahan Pasca Panen Tanaman Obat', 'url'=>'frontend.fasilitas','parent'=>4,'param'=>'unit-pengolahan-pasca-panen-tanaman-obat'];
       $menu[] = ['title'=>'Laboratorium Diversifikasi Produk', 'url'=>'frontend.fasilitas','parent'=>4,'param'=>'laboratorium-diversifikasi-produk'];
       $menu[] = ['title'=>'Laboratorium Fitokimia', 'url'=>'frontend.fasilitas','parent'=>4,'param'=>'laboratorium-fitokimia'];
       $menu[] = ['title'=>'Laboratorium Instrumentasi', 'url'=>'frontend.fasilitas','parent'=>4,'param'=>'laboratorium-instrumentasi'];
       $menu[] = ['title'=>'Laboratorium Mikrobiologi', 'url'=>'frontend.fasilitas','parent'=>4,'param'=>'laboratorium-mikrobiologi'];
       $menu[] = ['title'=>'Griya Sehat', 'url'=>'frontend.fasilitas','parent'=>4,'param'=>'griya-sehat'];
       $menu[] = ['title'=>'HerbalMart', 'url'=>'frontend.fasilitas','parent'=>4,'param'=>'herbalmart'];
       $menu[] = ['title'=>'Materia Medica Cafe (Cafe Jamu)', 'url'=>'frontend.fasilitas','parent'=>4,'param'=>'materia-medica-cafe-cafe-jamu'];

        //submenu layanan
       $menu[] = ['title'=>'Wisata Edukasi Toga', 'url'=>'frontend.service','parent'=>5,'param'=>'wisata-edukasi-toga'];
       $menu[] = ['title'=>'Workshop Pengolahan Tanaman Obat', 'url'=>'frontend.service.index','parent'=>5,'param'=>'workshop-pengolahan-tanaman-obat'];
       $menu[] = ['title'=>'Narasumber', 'url'=>'frontend.service','parent'=>5,'param'=>'narasumber'];
       $menu[] = ['title'=>'PKL Dan Magang', 'url'=>'frontend.service','parent'=>5,'param'=>'pkl-dan-magang'];
       $menu[] = ['title'=>'Identifikasi Tanaman Obat (Determinasi)', 'url'=>'frontend.service','parent'=>5,'param'=>'identifikasi-tanaman-obat-determinasi'];
       $menu[] = ['title'=>'Pengolahan Pasca Panen Tanaman Obat', 'url'=>'frontend.service','parent'=>5,'param'=>'pengolahan-pasca-panen-tanaman-obat'];
       $menu[] = ['title'=>'Ekstraksi Tanaman Obat', 'url'=>'frontend.service','parent'=>5,'param'=>'ekstraksi-tanaman-obat'];
       $menu[] = ['title'=>'Pengujian Kandungan Tanaman Obat', 'url'=>'frontend.service','parent'=>5,'param'=>'pengujian-kandungan-tanaman-obat'];
       $menu[] = ['title'=>'Pengujian Mikrobiologi', 'url'=>'frontend.service','parent'=>5,'param'=>'pengujian-mikrobiologi'];
       $menu[] = ['title'=>'Pelayanan Kesehatan Tradisional (Griya Sehat)', 'url'=>'frontend.service','parent'=>5,'param'=>'pelayanan-kesehatan-tradisional-griya-sehat'];
       $menu[] = ['title'=>'HerbalMart', 'url'=>'frontend.service','parent'=>5,'param'=>'herbalmart'];
       $menu[] = ['title'=>'Bibit Tanaman Obat', 'url'=>'frontend.service','parent'=>5,'param'=>'bibit-tanaman-obat'];
       $menu[] = ['title'=>'Sewa Fasilitas Gedung Dan Atau Alat', 'url'=>'frontend.service','parent'=>5,'param'=>'sewa-fasilitas-gedung-dan-atau-alat'];
       $menu[] = ['title'=>'Materia Medica Cafe (Cafe Jamu)', 'url'=>'frontend.service','parent'=>5,'param'=>'materia-medica-cafe-cafe-jamu'];
       $menu[] = ['title'=>'Layanan Unggulan', 'url'=>'frontend.service','parent'=>5,'param'=>'layanan-unggulan'];
       $menu[] = ['title'=>'Homecare', 'url'=>'frontend.service','parent'=>51,'param'=>'homecare'];
       $menu[] = ['title'=>'Telemedisin Griya Sehat', 'url'=>'frontend.service','parent'=>51,'param'=>'telemedisin-griya-sehat'];
       $menu[] = ['title'=>'Statplanet', 'url'=>'statplanet.unduh','parent'=>51,'param'=>'statplanet'];
       $menu[] = ['title'=>'Repository Tanaman Obat', 'url'=>'frontend.service','parent'=>51,'param'=>'repository-tanaman-obat'];
       $menu[] = ['title'=>'Pemesanan Simplisia Tanaman Obat', 'url'=>'frontend.service','parent'=>51,'param'=>'pemesanan-simplisia-tanaman-obat'];
       $menu[] = ['title'=>'Ekstraksi Tanaman Obat', 'url'=>'frontend.service','parent'=>51,'param'=>'ekstraksi-tanaman-obat-unggulan'];
       $menu[] = ['title'=>'Uji Kandungan Antioksidan Tanaman Obat', 'url'=>'frontend.service','parent'=>51,'param'=>'uji-kandungan-antioksidan-tanaman-obat'];

        //submenu penelitian
       $menu[] = ['title'=>'Penelitian Tanaman Obat dan Obat Tradisional', 'url'=>'frontend.penelitians','parent'=>6,'param'=>'penelitian'];
       $menu[] = ['title'=>'Inovasi', 'url'=>'frontend.inovasi','parent'=>6,'param'=>'inovasi'];

       //submenu Galery
       $menu[] = ['title'=>'Gallery Kegiatan', 'url'=>'frontend.gallery','parent'=>7,'param'=>'kegiatan'];
       $menu[] = ['title'=>'Gallery Tanaman Obat', 'url'=>'frontend.gallery','parent'=>7,'param'=>'tanaman-obat'];

       //submenu Unduh
       $menu[] = ['title'=>'Bulletin', 'url'=>'frontend.unduh','parent'=>8,'param'=>'bulletin'];
       $menu[] = ['title'=>'E-Book', 'url'=>'frontend.unduh','parent'=>8,'param'=>'ebook'];
       $menu[] = ['title'=>'Peraturan', 'url'=>'frontend.unduh','parent'=>8,'param'=>'peraturan'];

       //submenu survey kepuasan masyarakat

       $menu[] = ['title'=>'Form SKM', 'url'=>'frontend.skm.form-service','parent'=>11,'param'=>null];
       $menu[] = ['title'=>'Form Saran Kritik', 'url'=>'frontend.sarankritik.index','parent'=>11,'param'=>null];
       $menu[] = ['title'=>'Publikasi SKM', 'url'=>'frontend.skm.show','parent'=>11,'param'=>null];
       $menu[] = ['title'=>'Publikasi Saran/Kritik', 'url'=>'frontend.sarankritik.show','parent'=>11,'param'=>null];
       Menu::insert($menu);
    }
}
