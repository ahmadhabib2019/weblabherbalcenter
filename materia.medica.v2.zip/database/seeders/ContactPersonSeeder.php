<?php

namespace Database\Seeders;

use App\Models\ContactPerson;
use Illuminate\Database\Seeder;

class ContactPersonSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        ContactPerson::truncate();
        $person[] = ['name' => 'UPT Materia Medica', 'email' => ' materiamedicabatu@jatimprov.go.id', 'phone' => ' (0341) 593396'];
        $person[] = ['name' => 'Sabrina', 'email' => 'sabrinamartha@ymail.com', 'phone' => '081391009243'];
        $person[] = ['name' => 'dr Ratna', 'email' => 'ryulianti25@gmail.com', 'phone' => '082139629090'];
        $person[] = ['name' => 'Siti', 'email' => 'mudaliana@gmail.com', 'phone' => '081280121028'];
        $person[] = ['name' => 'Selvy', 'email' => 'selvymmb@gmail.com', 'phone' => '087754044334'];
        $person[] = ['name' => 'Valen', 'email' => 'arwindorenata1189@gmail.com', 'phone' => '081249659871'];
        $person[] = ['name' => 'Febri', 'email' => 'febriyana19@gmail.com', 'phone' => '081331744070'];
        $person[] = ['name' => 'Palupi', 'email' => 'palupiningtijas@yahoo.com', 'phone' => '082257450859'];
        $person[] = ['name' => 'Yopi', 'email' => 'yopihermawan1304@gmail.com', 'phone' => '085747249772'];
        $person[] = ['name' => 'Ninta', 'email' => 'dyaninta28@gmail.com', 'phone' => '08113488854'];
        ContactPerson::insert($person);
    }
}
