<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\ProdukKategori;

class ProdukKategoriSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        ProdukKategori::truncate();
        $kategori [] = ['id'=>1,'name' => 'Simplisia'];
        $kategori [] = ['id'=>2,'name' => 'Serbuk'];
        $kategori [] = ['id'=>3,'name' => 'Starter Kit'];
        $kategori [] = ['id'=>4,'name' => 'Bibit Tanaman Obat'];

        ProdukKategori::insert($kategori);

    }
}
