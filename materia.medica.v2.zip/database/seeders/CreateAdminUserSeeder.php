<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use App\Models\UserData;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Schema;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;

class CreateAdminUserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Schema::disableForeignKeyConstraints();
        User::truncate();
        Role::truncate();
        UserData::truncate();
        $user = User::create([
            'username' => 'administrator',
            'name' => 'Administrator',
            'email' => 'admin@gmail.com',
            'password' => 'admin12345'
        ]);

        $role = Role::create(['name' => 'Administrator']);
        $permissions = Permission::pluck('id', 'id')->all();
        $role->syncPermissions($permissions);
        $user->assignRole([$role->id]);
        
        $operator = User::create([
            'username' => 'operator',
            'name' => 'Operator',
            'email' => 'operator@gmail.com',
            'password' => 'admin12345'
        ]);
        $role = Role::create(['name' => 'Operator']);
        $permissions = Permission::where('name', 'LIKE', 'operator-%')->pluck('id', 'id')->all();
        $role->syncPermissions($permissions);
        $operator->assignRole([$role->id]);

        $role = Role::create(['name' => 'Pengunjung']);
        $permissions = Permission::where('name', 'LIKE', 'pengunjung%')->pluck('id', 'id')->all();
        $role->syncPermissions($permissions);
        Schema::enableForeignKeyConstraints();
    }
}
